# BATCH B — Prompts 016–023
# Contracts, Migrations, Seed Data
# Paste each CONTEXT block directly into DeepSeek web chat.
# MAX RIGIDITY throughout — DeepSeek has no latitude on these files.
# ============================================================

# ============================================================
# PROMPT-016: Protobuf Contract — claim_scrubbing.proto
# ============================================================
# GOAL: The gRPC contract between rcm-core and rcm-rag
# DEPENDS ON: PROMPT-001 PROMPT-002
# OUTPUT: proto/rcm/v1/claim_scrubbing.proto
# ACCEPTANCE CRITERIA:
#   1. Proto3 syntax
#   2. ClaimScrubRequest contains all fields needed for scrubbing:
#      claim_id, tenant_id, payer_id, cpt_codes, icd10_codes,
#      modifiers, place_of_service, service_date, provider_npi,
#      total_charge_cents, claim_lines
#   3. ClaimScrubResponse contains: passed, issues list, warnings list,
#      retrieved_policy_count, llm_model_used, latency_ms
#   4. ScrubIssue has: code, severity (BLOCKING/WARNING), description,
#      policy_reference
#   5. Service has one RPC: ScrubClaim(ClaimScrubRequest) returns
#      (ClaimScrubResponse) — unary, not streaming
#   6. All fields have inline comments explaining purpose
#   7. buf.yaml lint rules satisfied (google style)
# COMMON FAILURE MODES:
#   - Missing tenant_id field (critical for multi-tenancy)
#   - No comments on fields
#   - Using proto2 syntax instead of proto3
# ============================================================

PROMPT-016 CONTEXT — paste this into DeepSeek:
==========================================
You are generating a Protocol Buffer (protobuf) contract file for a
production-grade RCM (Revenue Cycle Management) platform.

This proto file defines the gRPC contract for claim scrubbing between:
- CLIENT: rcm-core (Spring Boot Java 21) — the caller
- SERVER: rcm-rag (FastAPI Python 3.12) — the implementer

SYSTEM CONTEXT:
Claim scrubbing is a synchronous operation where rcm-core sends claim data
to rcm-rag, which retrieves relevant payer policies via RAG (pgvector),
calls an LLM to evaluate the claim against those policies, and returns
a structured scrub result. Latency budget: 3 seconds end-to-end.

REQUIREMENTS:
- Proto3 syntax
- Package: rcm.v1
- Java options: java_package="com.rcm.proto", java_outer_classname="ClaimScrubbingProto",
  java_multiple_files=true
- Python options: none needed (generated from grpcio-tools)
- Every field must have an inline comment explaining its purpose
- Follow Google proto style guide (buf lint compatible)
- Use snake_case for field names
- Use SCREAMING_SNAKE_CASE for enum values

MESSAGES TO DEFINE:

ClaimScrubRequest:
- claim_id (string): UUID of the claim being scrubbed
- tenant_id (string): UUID of the tenant (required for multi-tenant isolation)
- payer_id (string): UUID of the payer — used to filter policy retrieval
- claim_type (string): "837P" or "837I" (professional or institutional)
- cpt_codes (repeated string): list of CPT procedure codes on the claim
- icd10_codes (repeated string): list of ICD-10 diagnosis codes
- modifiers (repeated string): CPT modifiers (e.g. "25", "59", "GT")
- place_of_service (string): CMS place of service code (e.g. "11" = office)
- service_date (string): date of service in YYYY-MM-DD format
- rendering_provider_npi (string): 10-digit NPI of rendering provider
- billing_provider_npi (string): 10-digit NPI of billing provider
- total_charge_cents (int64): total claim charge in cents (never use float for money)
- claim_lines (repeated ClaimLine): individual claim line items
- trace_id (string): OpenTelemetry trace ID for distributed tracing
- request_id (string): unique request ID for idempotency and logging

ClaimLine:
- line_number (int32): sequential line number (1-based)
- cpt_code (string): CPT code for this line
- icd10_codes (repeated string): diagnosis codes for this line
- modifiers (repeated string): modifiers for this line
- units (int32): number of units billed
- charge_cents (int64): charge for this line in cents
- revenue_code (string): UB-04 revenue code (institutional claims only)

ClaimScrubResponse:
- claim_id (string): echo back the claim_id for correlation
- passed (bool): true if no blocking issues found
- issues (repeated ScrubIssue): list of issues found (blocking and warnings)
- retrieved_policy_count (int32): number of payer policy chunks retrieved via RAG
- llm_model_used (string): which LLM model was called (for audit/debugging)
- llm_called (bool): whether an LLM call was made (false if feature flag off or RAG found nothing)
- processing_time_ms (int64): total processing time in milliseconds
- rag_retrieval_time_ms (int64): time spent on pgvector retrieval
- llm_inference_time_ms (int64): time spent on LLM inference

ScrubIssue:
- issue_code (string): machine-readable code (e.g. "INVALID_CPT_CODE", "PAYER_POLICY_VIOLATION")
- severity (ScrubSeverity enum): BLOCKING or WARNING
- description (string): human-readable description of the issue
- affected_field (string): which field caused the issue (e.g. "cpt_codes[0]")
- policy_reference (string): citation of the payer policy that was violated (if applicable)
- suggested_fix (string): how to resolve this issue

ScrubSeverity enum:
- SCRUB_SEVERITY_UNSPECIFIED = 0
- SCRUB_SEVERITY_BLOCKING = 1  (claim cannot be submitted)
- SCRUB_SEVERITY_WARNING = 2   (claim can be submitted but may be denied)

ClaimScrubService:
- ScrubClaim(ClaimScrubRequest) returns (ClaimScrubResponse)
  Comment: Synchronous unary RPC. Client sets a 3-second deadline.
  Server implements PHI redaction before any LLM call.
  Resilience4j circuit breaker on the client side.

OUTPUT: Single file.
// FILE: proto/rcm/v1/claim_scrubbing.proto
[full proto file with syntax, package, options, all messages, enum, service]
// ===== END OF FILE =====

STYLE REQUIREMENTS:
- Every message field has an inline // comment
- Every enum value has an inline // comment
- File-level comment block explaining the contract
- Comments reference the system architecture where relevant
  (e.g. "// tenant_id is required — rcm-rag enforces tenant isolation on pgvector queries")
- No TODOs, no placeholder comments
==========================================

# ============================================================
# PROMPT-017: OpenAPI Spec — rcm-core REST API
# ============================================================
# GOAL: Complete OpenAPI 3.1 spec for the Spring Boot service
# DEPENDS ON: PROMPT-001 PROMPT-007
# OUTPUT: docs/rcm-core-openapi.yaml
# ACCEPTANCE CRITERIA:
#   1. OpenAPI 3.1.0
#   2. All 7 bounded contexts have endpoints:
#      registration, eligibility, charge-capture, claims,
#      payments, denials, ar
#   3. Every endpoint has: summary, description, request body schema,
#      response schemas (200, 400, 401, 403, 422, 500)
#   4. Security scheme defined: Bearer JWT (RS256, Keycloak)
#   5. All monetary amounts as integer (cents), never number/float
#   6. Pagination schema defined and reused across list endpoints
#   7. Error response schema defined and reused
#   8. tenant_id never in request body or URL — extracted from JWT
# ============================================================

PROMPT-017 CONTEXT — paste this into DeepSeek:
==========================================
You are generating a complete OpenAPI 3.1 specification for rcm-core,
the Spring Boot (Java 21) service in a production-grade RCM platform.

DESIGN PRINCIPLES:
- REST conventions: plural nouns, kebab-case paths
- No tenant_id in URLs or request bodies (extracted from JWT always)
- All monetary amounts as integer type (cents) with description clarifying unit
- Cursor-based pagination for all list endpoints
- Consistent error response format across all endpoints
- Bearer JWT authentication (RS256, issued by Keycloak)
- API versioning: all paths prefixed with /v1/

REUSABLE SCHEMAS (define in components/schemas):

ErrorResponse:
  type: object
  required: [code, message, traceId, timestamp]
  properties:
    code: string (machine-readable error code)
    message: string (human-readable)
    details: array of strings (field-level errors)
    traceId: string (OpenTelemetry trace ID)
    timestamp: string (ISO8601)

PageInfo:
  type: object
  properties:
    hasNextPage: boolean
    hasPreviousPage: boolean
    startCursor: string
    endCursor: string
    totalCount: integer

PaginatedResponse: (generic wrapper, used by all list endpoints)
  type: object
  properties:
    data: array (items type varies per endpoint)
    pageInfo: PageInfo

Money: (always an integer representing cents)
  type: integer
  description: "Amount in cents (USD). Divide by 100 for display."
  example: 15000

ENDPOINTS TO DEFINE:

REGISTRATION (/v1/patients):
POST /v1/patients — Create patient
  Request: firstName, lastName, dateOfBirth, gender, address, phone, email,
           mrn (optional), insuranceInfo (payerId, memberId, groupNumber, coverageType)
  Response 201: PatientResponse (id, mrn, firstName, lastName, dateOfBirth,
                gender, address, phone, email, insuranceInfo, createdAt)
  Response 422: ErrorResponse (validation failure)

GET /v1/patients — List patients (paginated, cursor-based)
  Query: cursor, limit (max 100), search (name/mrn)
  Response 200: PaginatedResponse<PatientSummary>

GET /v1/patients/{patientId} — Get patient by ID
  Response 200: PatientResponse
  Response 404: ErrorResponse

PUT /v1/patients/{patientId} — Update patient
  Request: same fields as POST (all optional)
  Response 200: PatientResponse

ELIGIBILITY (/v1/eligibility):
POST /v1/eligibility/verify — Verify eligibility
  Request: patientId, payerId, serviceDate
  Response 200: EligibilityResponse (coverageActive, coverageStart, coverageEnd,
                deductibleCents, deductibleMetCents, outOfPocketMaxCents,
                outOfPocketMetCents, copayCents, coinsurancePct,
                cachedAt (if from Redis cache), checkedAt)
  Response 202: (if async check initiated)

GET /v1/eligibility/{patientId}/history — Eligibility check history
  Response 200: PaginatedResponse<EligibilityResponse>

CHARGE CAPTURE (/v1/encounters):
POST /v1/encounters — Create encounter
  Request: patientId, renderingProviderNpi, billingProviderNpi, facilityNpi,
           serviceDate, dischargeDate, placeOfService, encounterType, notes,
           chargeItems (array of: cptCode, icd10Codes, modifiers, units, chargeCents)
  Response 201: EncounterResponse (id, patientId, status, chargeItems, totalChargeCents)

GET /v1/encounters/{encounterId} — Get encounter
  Response 200: EncounterResponse

POST /v1/encounters/{encounterId}/charges — Add charge item
  Request: cptCode, icd10Codes, modifiers, units, chargeCents
  Response 200: EncounterResponse

CLAIMS (/v1/claims):
POST /v1/claims — Create claim from encounter
  Request: encounterId, payerId, claimType (837P/837I)
  Response 201: ClaimResponse (id, status, encounterId, payerId, totalChargeCents,
                createdAt, summary — Spring AI generated summary)

GET /v1/claims — List claims (paginated)
  Query: cursor, limit, status, payerId, dateFrom, dateTo
  Response 200: PaginatedResponse<ClaimSummary>

GET /v1/claims/{claimId} — Get claim with full detail
  Response 200: ClaimResponse (includes scrubResult if scrubbed)

POST /v1/claims/{claimId}/scrub — Trigger claim scrubbing
  Request: (empty — scrub uses claim data on file)
  Response 200: ScrubResultResponse (passed, issues, warnings, processingTimeMs)
  Response 503: ErrorResponse (if rcm-rag circuit breaker open)

POST /v1/claims/{claimId}/submit — Submit claim to clearinghouse
  Request: (empty — uses existing scrubbed claim data)
  Response 202: (accepted for async submission)
  Response 409: ErrorResponse (claim not in SCRUBBED status)

PAYMENTS (/v1/payments):
POST /v1/payments/eras — Process ERA (835 file)
  Request: ediContent (raw 835 EDI string), payerId
  Response 201: EraResponse (id, payerId, eraDate, totalAmountCents, lineCount)

GET /v1/payments/eras — List ERAs (paginated)
  Response 200: PaginatedResponse<EraSummary>

GET /v1/payments — List payments (paginated)
  Query: claimId, dateFrom, dateTo
  Response 200: PaginatedResponse<PaymentResponse>

DENIALS (/v1/denials):
GET /v1/denials — List denials (paginated)
  Query: cursor, limit, status, payerId, carcCode, dateFrom, dateTo
  Response 200: PaginatedResponse<DenialSummary>

GET /v1/denials/{denialId} — Get denial with appeal draft
  Response 200: DenialResponse (id, claimId, carcCode, rarcCode, status,
                denialDate, explanation, appealDraft if exists)

POST /v1/denials/{denialId}/approve — Approve appeal draft
  Request: approvedText (biller-edited appeal text)
  Response 200: DenialResponse (status updated to APPEAL_SUBMITTED)
  Response 409: ErrorResponse (denial not in HUMAN_REVIEW status)

POST /v1/agent/resume/{runId} — Resume agent after human approval
  Request: (called internally by rcm-core after appeal approval)
  Response 200: {status: "resumed"}

AR (/v1/ar):
GET /v1/ar/aging — AR aging report
  Query: asOf date (default today), payerId
  Response 200: ArAgingReport (buckets: 0-30, 31-60, 61-90, 90+, each with count and totalCents)

GET /v1/ar/balances — List AR balances (paginated)
  Query: agingBucket, minAmountCents, patientId
  Response 200: PaginatedResponse<ArBalance>

SECURITY SCHEME:
BearerAuth: type=http, scheme=bearer, bearerFormat=JWT
  description: RS256 JWT issued by Keycloak. Contains claims: sub (userId),
               tenant_id, roles. Validated against Keycloak JWKS endpoint.

OUTPUT: Single file.
// FILE: docs/rcm-core-openapi.yaml
[complete OpenAPI 3.1 YAML]
// ===== END OF FILE =====

STYLE: Valid OpenAPI 3.1.0 YAML. Use $ref for all reusable schemas.
Inline examples on every schema. Descriptions explain business meaning,
not just data types. Comments (#) where helpful.
==========================================

# ============================================================
# PROMPT-018: OpenAPI Spec — rcm-rag REST API + GraphQL Schema
# ============================================================
# GOAL: rcm-rag OpenAPI spec + all 6 GraphQL type definition files
# DEPENDS ON: PROMPT-001 PROMPT-006
# OUTPUT: docs/rcm-rag-openapi.yaml
#         rcm-bff/src/schema/typeDefs/patient.graphql
#         rcm-bff/src/schema/typeDefs/claim.graphql
#         rcm-bff/src/schema/typeDefs/denial.graphql
#         rcm-bff/src/schema/typeDefs/payment.graphql
#         rcm-bff/src/schema/typeDefs/ar.graphql
#         rcm-bff/src/schema/typeDefs/agent.graphql
# ACCEPTANCE CRITERIA:
#   1. rcm-rag OpenAPI covers: health, ingestion, retrieval (debug),
#      denial status, eval trigger, agent resume
#   2. GraphQL schema uses Relay cursor connections for lists
#   3. Mutation for approveAppeal defined with input type
#   4. Subscription or SSE for denial explanation progress defined
#   5. All monetary amounts as Int (cents) in GraphQL
# ============================================================

PROMPT-018 CONTEXT — paste this into DeepSeek:
==========================================
You are generating API contracts for a production-grade RCM platform.
Two outputs: the rcm-rag service OpenAPI spec and the GraphQL schema
for the rcm-bff BFF service.

PART 1: rcm-rag OpenAPI 3.1 Specification

rcm-rag (FastAPI Python 3.12) exposes these REST endpoints:
(Note: the primary interface to rcm-rag from rcm-core is gRPC for claim scrubbing.
These REST endpoints are for: management, debugging, async status, and UI polling.)

GET /health — Health check
  Response 200: {status: "healthy", version: string, uptime_seconds: int,
                 faiss_index_loaded: bool, pgvector_connected: bool}

POST /v1/ingestion/ingest — Ingest documents into RAG corpus
  Request: documents array (sourceType, sourceName, payerId, effectiveDate, content, metadata)
  Response 202: {jobId: string, documentCount: int, estimatedTimeSeconds: int}
  Called by: rcm-core admin endpoints, seed data scripts

GET /v1/ingestion/status/{jobId} — Check ingestion job status
  Response 200: {jobId, status, documentsProcessed, chunksCreated, embeddingsGenerated}

POST /v1/retrieval/search — Debug retrieval endpoint (admin use)
  Request: queryText, payerId, topK, includeScores
  Response 200: {chunks: array, retrievalLatencyMs, faissUsed: bool}

GET /v1/denial/{denialId}/status — Get agent execution status for a denial
  Response 200: {denialId, agentRunId, currentNode, interrupted, interruptedAt,
                 stepsCompleted: array of node names, estimatedNextStep}
  Used by rcm-bff SSE endpoint to stream progress to UI

POST /v1/agent/resume/{runId} — Resume agent after human approval
  Request: {approvedText, reviewerId, feedback (optional)}
  Response 200: {runId, status: "resumed", resumedAt}

POST /v1/eval/run — Trigger eval harness run (CI/CD and manual)
  Request: {evalSet: "claim_scrubbing"|"denial_explanation", promptId (optional)}
  Response 202: {jobId, evalSet, promptsEvaluated: int}

GET /v1/eval/results/{jobId} — Get eval run results
  Response 200: {jobId, status, results: {faithfulness, recallAt5, bleu4, ...},
                 passedThresholds: bool, failedMetrics: array}

GET /metrics — Prometheus metrics endpoint (scraped by Prometheus)
  Response 200: text/plain Prometheus format

PART 2: GraphQL Schema for rcm-bff

Design principles:
- Relay cursor connections for all paginated lists
- camelCase fields, PascalCase types
- Int type for all monetary amounts (cents)
- Non-null (!) where field is always present
- Interfaces for shared fields (Node interface with id field)

Define these type definition files:

patient.graphql:
- Node interface: id: ID!
- Patient type: implements Node, all demographic fields,
  insuranceInfo: InsuranceInfo, encounters: EncounterConnection,
  eligibilityHistory: EligibilityConnection
- InsuranceInfo type: payerId, memberId, groupNumber, coverageType
- EligibilityCheck type: coverageActive, coverageStart, coverageEnd,
  deductibleCents: Int, deductibleMetCents: Int, copayCents: Int,
  coinsurancePct: Float, checkedAt
- PatientConnection, PatientEdge, PageInfo types (Relay)
- Query fields: patient(id: ID!): Patient, patients(first: Int, after: String,
  search: String): PatientConnection
- Mutation fields: createPatient(input: CreatePatientInput!): Patient,
  updatePatient(id: ID!, input: UpdatePatientInput!): Patient

claim.graphql:
- Claim type: id, status: ClaimStatus!, claimType, totalChargeCents: Int!,
  allowedAmountCents: Int, paidAmountCents: Int, patientResponsibilityCents: Int,
  encounter: Encounter!, payer: Payer!, lines: [ClaimLine!]!,
  scrubResult: ScrubResult, summary: String, createdAt, submittedAt
- ClaimStatus enum: DRAFT, SCRUBBING, SCRUB_FAILED, SCRUBBED, SUBMITTED,
  ACKNOWLEDGED, ADJUDICATED, PAID, DENIED, APPEALED, CLOSED
- ScrubResult type: passed: Boolean!, issues: [ScrubIssue!]!, processingTimeMs: Int
- ScrubIssue type: issueCode, severity: ScrubSeverity!, description, suggestedFix
- ScrubSeverity enum: BLOCKING, WARNING
- ClaimLine type: lineNumber, cptCode, icd10Codes, modifiers, units, chargeCents: Int
- Encounter type: id, serviceDate, placeOfService, encounterType
- Payer type: id, name, payerType
- ClaimConnection, ClaimEdge (Relay)
- Query: claim(id: ID!): Claim, claims(first: Int, after: String,
  status: ClaimStatus, payerId: ID, dateFrom: String, dateTo: String): ClaimConnection
- Mutation: createClaim(encounterId: ID!, payerId: ID!, claimType: String!): Claim,
  scrubClaim(claimId: ID!): ScrubResult,
  submitClaim(claimId: ID!): Claim

denial.graphql:
- Denial type: id, claim: Claim!, carcCode: CarcCode!, rarcCode: RarcCode,
  status: DenialStatus!, denialDate, explanation: String, appealDraft: AppealDraft,
  agentRunId: String, agentStatus: AgentStatus, createdAt
- DenialStatus enum: RECEIVED, TRIAGED, AGENT_ANALYZING, APPEAL_DRAFTED,
  HUMAN_REVIEW, APPEAL_SUBMITTED, RESOLVED, ESCALATED, CLOSED
- CarcCode type: code, description
- RarcCode type: code, description
- AppealDraft type: draftText, approvedText, approvedBy, approvedAt, usefulnessScore: Int
- AgentStatus type: currentNode, stepsCompleted: [String!]!, interrupted, interruptedAt
- DenialConnection, DenialEdge (Relay)
- Query: denial(id: ID!): Denial, denials(first: Int, after: String,
  status: DenialStatus, payerId: ID, carcCode: String): DenialConnection
- Mutation: approveAppeal(denialId: ID!, approvedText: String!): Denial

payment.graphql:
- Payment type: id, claim: Claim!, era: Era, paymentType, amountCents: Int!,
  paymentDate, checkNumber, createdAt
- Era type: id, payer: Payer!, eraDate, totalAmountCents: Int!, lineCount: Int,
  processedAt
- PaymentConnection, EraConnection (Relay)
- Query: payments(first: Int, after: String, claimId: ID): PaymentConnection,
  eras(first: Int, after: String, payerId: ID): EraConnection

ar.graphql:
- ArAgingReport type: asOf, buckets: [AgingBucket!]!
- AgingBucket type: label (0-30, 31-60, 61-90, 90+), claimCount: Int!,
  totalCents: Int!, percentage: Float!
- ArBalance type: id, patient: Patient!, claim: Claim!, balanceCents: Int!,
  agingBucket: String!, lastFollowUpAt
- ArConnection (Relay)
- Query: arAgingReport(asOf: String, payerId: ID): ArAgingReport,
  arBalances(first: Int, after: String, agingBucket: String): ArConnection

agent.graphql:
- AgentExecution type: runId, denialId: ID!, currentNode, status: AgentExecutionStatus!,
  stepsCompleted: [AgentStep!]!, interrupted, interruptedAt, completedAt
- AgentStep type: nodeName, startedAt, completedAt, success: Boolean!,
  toolsCalled: [String!]!, outputSummary: String
- AgentExecutionStatus enum: RUNNING, INTERRUPTED, COMPLETED, FAILED, ESCALATED
- Query: agentExecution(runId: ID!): AgentExecution
- Mutation: resumeAgent(runId: ID!, approvedText: String!, feedback: String): AgentExecution

OUTPUT: 7 files total.
// FILE: docs/rcm-rag-openapi.yaml  then  // ===== END OF FILE =====
// FILE: rcm-bff/src/schema/typeDefs/patient.graphql  then  // ===== END OF FILE =====
[repeat for each .graphql file]

Style: Valid OpenAPI 3.1 YAML. Valid GraphQL SDL.
Inline descriptions everywhere. Examples on request/response schemas.
==========================================

# ============================================================
# PROMPT-019: Flyway Migrations Batch 1 — V001 through V006
# ============================================================
# GOAL: First 6 SQL migration files
# DEPENDS ON: PROMPT-007 PROMPT-017
# OUTPUT: V001__create_extensions.sql through V006__create_claim_lines.sql
# ACCEPTANCE CRITERIA:
#   1. V001 enables pgvector, pgcrypto, uuid-ossp, pg_cron extensions
#   2. Every table has id UUID DEFAULT gen_random_uuid() PK
#   3. Every table has tenant_id UUID NOT NULL with FK to tenants
#   4. Every table has created_at + updated_at TIMESTAMPTZ
#   5. All monetary amounts as INTEGER (cents), not DECIMAL
#   6. Indexes created for all FK columns and common query patterns
#   7. CHECK constraints on enum-like columns
#   8. Comments on every table and key columns
# ============================================================

PROMPT-019 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Flyway SQL migration files for a production-grade
PostgreSQL 16 database for an RCM platform.

CONVENTIONS (apply to every migration):
- Postgres 16, pgvector 0.7, pgcrypto, uuid-ossp extensions
- Schema name: rcm (for transactional tables), rag (for AI tables)
- All PKs: id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY
- All tables: tenant_id UUID NOT NULL REFERENCES rcm.tenants(id)
- All tables: created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
- All tables: updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
- Soft delete where applicable: deleted_at TIMESTAMPTZ
- Monetary amounts: INTEGER (cents), column names ending in _cents
- Enums: VARCHAR with CHECK constraint listing allowed values
- Every table has a COMMENT ON TABLE explaining its purpose
- Every index named: idx_{table}_{column(s)}
- Every FK named: fk_{table}_{referenced_table}
- Updated_at maintained by a trigger (define once, reuse)

MIGRATION FILES:

V001__create_extensions.sql:
- CREATE SCHEMA IF NOT EXISTS rcm
- CREATE SCHEMA IF NOT EXISTS rag
- CREATE EXTENSION IF NOT EXISTS "uuid-ossp"
- CREATE EXTENSION IF NOT EXISTS "pgcrypto"
- CREATE EXTENSION IF NOT EXISTS "vector" (pgvector)
- CREATE EXTENSION IF NOT EXISTS "pg_cron"
- CREATE OR REPLACE FUNCTION update_updated_at_column() trigger function
  (sets NEW.updated_at = NOW(), used by all tables with updated_at)
- Comment explaining each extension's purpose

V002__create_tenants.sql:
Table: rcm.tenants
Columns: id, name VARCHAR(255) NOT NULL, subdomain VARCHAR(100) UNIQUE NOT NULL,
status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK(status IN ('active','suspended','inactive')),
config JSONB NOT NULL DEFAULT '{}',
created_at, updated_at
Indexes: idx_tenants_subdomain, idx_tenants_status
Note: tenants table does NOT have tenant_id FK (it IS the tenant root)

V003__create_patients.sql:
Table: rcm.patients
Columns: id, tenant_id FK→tenants,
mrn VARCHAR(50) NOT NULL,
first_name VARCHAR(100) NOT NULL,
last_name VARCHAR(100) NOT NULL,
date_of_birth DATE NOT NULL,
ssn_encrypted BYTEA (pgcrypto encrypted — comment explaining this),
gender VARCHAR(20) CHECK(gender IN ('male','female','other','unknown')),
address JSONB NOT NULL DEFAULT '{}' (structure: street, city, state, zip, country),
phone VARCHAR(20),
email VARCHAR(255),
insurance_info JSONB NOT NULL DEFAULT '[]' (array of insurance records),
created_at, updated_at, deleted_at
Constraints: UNIQUE(tenant_id, mrn)
Indexes: idx_patients_tenant_id, idx_patients_mrn,
idx_patients_last_name (for search), idx_patients_deleted_at

V004__create_encounters.sql:
Table: rcm.encounters
Columns: id, tenant_id FK→tenants,
patient_id UUID NOT NULL REFERENCES rcm.patients(id),
rendering_provider_npi VARCHAR(10) NOT NULL,
billing_provider_npi VARCHAR(10) NOT NULL,
facility_npi VARCHAR(10),
service_date DATE NOT NULL,
discharge_date DATE,
place_of_service VARCHAR(5) NOT NULL,
encounter_type VARCHAR(30) NOT NULL CHECK(encounter_type IN
  ('office_visit','emergency','inpatient','outpatient','telehealth','other')),
status VARCHAR(20) NOT NULL DEFAULT 'open'
  CHECK(status IN ('open','billed','closed','void')),
notes TEXT,
created_at, updated_at, deleted_at
Constraints: CHECK(discharge_date IS NULL OR discharge_date >= service_date)
Indexes: idx_encounters_tenant_id, idx_encounters_patient_id,
idx_encounters_service_date, idx_encounters_status

V005__create_claims.sql:
Table: rcm.claims
Columns: id, tenant_id FK→tenants,
encounter_id UUID NOT NULL REFERENCES rcm.encounters(id),
patient_id UUID NOT NULL REFERENCES rcm.patients(id),
payer_id UUID NOT NULL REFERENCES rcm.payers(id),
claim_type VARCHAR(10) NOT NULL CHECK(claim_type IN ('837P','837I')),
status VARCHAR(30) NOT NULL DEFAULT 'DRAFT' CHECK(status IN
  ('DRAFT','SCRUBBING','SCRUB_FAILED','SCRUBBED','SUBMITTED',
   'ACKNOWLEDGED','ADJUDICATED','PAID','DENIED','APPEALED','CLOSED')),
total_charge_cents INTEGER NOT NULL CHECK(total_charge_cents > 0),
allowed_amount_cents INTEGER CHECK(allowed_amount_cents >= 0),
paid_amount_cents INTEGER CHECK(paid_amount_cents >= 0),
patient_responsibility_cents INTEGER CHECK(patient_responsibility_cents >= 0),
scrub_result JSONB,
edi_837_raw TEXT,
claim_summary TEXT (Spring AI generated),
submitted_at TIMESTAMPTZ,
adjudicated_at TIMESTAMPTZ,
created_at, updated_at, deleted_at
Indexes: idx_claims_tenant_id, idx_claims_encounter_id, idx_claims_patient_id,
idx_claims_payer_id, idx_claims_status, idx_claims_submitted_at
Note: payers table created in V007 — add FK constraint in V007 via ALTER TABLE

V006__create_claim_lines.sql:
Table: rcm.claim_lines
Columns: id, tenant_id FK→tenants,
claim_id UUID NOT NULL REFERENCES rcm.claims(id) ON DELETE CASCADE,
line_number INTEGER NOT NULL CHECK(line_number > 0),
cpt_code VARCHAR(10) NOT NULL,
icd10_codes VARCHAR(10)[] NOT NULL DEFAULT '{}',
modifiers VARCHAR(5)[] DEFAULT '{}',
units INTEGER NOT NULL DEFAULT 1 CHECK(units > 0),
charge_cents INTEGER NOT NULL CHECK(charge_cents > 0),
allowed_cents INTEGER CHECK(allowed_cents >= 0),
paid_cents INTEGER CHECK(paid_cents >= 0),
revenue_code VARCHAR(4),
service_date DATE,
created_at, updated_at
Constraints: UNIQUE(claim_id, line_number)
Indexes: idx_claim_lines_claim_id, idx_claim_lines_cpt_code

OUTPUT: 6 files.
// FILE: rcm-core/app/src/main/resources/db/migration/V001__create_extensions.sql
[SQL]
// ===== END OF FILE =====
[repeat for V002-V006]

STYLE: Production-quality SQL. Every table and column has a COMMENT.
Explain the business reason for constraints in comments.
Include the trigger attachment (CREATE TRIGGER update_XX_updated_at...)
for every table that has updated_at.
==========================================

# ============================================================
# PROMPT-020: Flyway Migrations Batch 2 — V007 through V013
# ============================================================
# GOAL: Migrations for payers, payments, eras, denials, appeals, ar, feature_flags
# DEPENDS ON: PROMPT-019
# OUTPUT: V007__create_payers.sql through V013__create_feature_flags.sql
# ACCEPTANCE CRITERIA:
#   1. V007 adds the FK from claims to payers (deferred from V005)
#   2. Denials table has both carc_code and rarc_code columns
#   3. Appeals table has usefulness_score INTEGER CHECK(1-5) for biller ratings
#   4. Feature flags table supports per-tenant flags with JSONB metadata
# ============================================================

PROMPT-020 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Flyway SQL migration files V007 through V013.
Apply the same conventions as V001-V006 (same comment style, same
naming conventions, same trigger pattern for updated_at).

V007__create_payers.sql:
Table: rcm.payers
Columns: id, tenant_id FK→tenants,
name VARCHAR(255) NOT NULL,
payer_id_external VARCHAR(50) NOT NULL (payer's own ID used in EDI),
payer_type VARCHAR(30) NOT NULL CHECK(payer_type IN
  ('commercial','medicare','medicaid','tricare','self_pay','other')),
eligibility_endpoint VARCHAR(500),
claim_submission_endpoint VARCHAR(500),
config JSONB NOT NULL DEFAULT '{}',
created_at, updated_at
Constraints: UNIQUE(tenant_id, payer_id_external)
Indexes: idx_payers_tenant_id, idx_payers_payer_id_external

After creating payers table, add the deferred FK:
ALTER TABLE rcm.claims ADD CONSTRAINT fk_claims_payers
  FOREIGN KEY (payer_id) REFERENCES rcm.payers(id);

V008__create_payments.sql:
Table: rcm.payments
Columns: id, tenant_id FK→tenants,
claim_id UUID NOT NULL REFERENCES rcm.claims(id),
era_id UUID REFERENCES rcm.eras(id),
payment_type VARCHAR(20) NOT NULL CHECK(payment_type IN
  ('eft','check','credit_card','adjustment','write_off')),
amount_cents INTEGER NOT NULL,
payment_date DATE NOT NULL,
check_number VARCHAR(50),
eft_trace_number VARCHAR(50),
created_at, updated_at
Note: eras table created in V009 — FK to eras added in V009

V009__create_eras.sql:
Table: rcm.eras (Electronic Remittance Advice — 835 transactions)
Columns: id, tenant_id FK→tenants,
payer_id UUID NOT NULL REFERENCES rcm.payers(id),
era_date DATE NOT NULL,
total_amount_cents INTEGER NOT NULL,
check_number VARCHAR(50),
eft_trace_number VARCHAR(50),
raw_835_response TEXT (the raw EDI 835 string — stored for audit),
processed_at TIMESTAMPTZ,
created_at, updated_at
Indexes: idx_eras_tenant_id, idx_eras_payer_id, idx_eras_era_date

After creating eras, add FK from payments to eras:
ALTER TABLE rcm.payments ADD CONSTRAINT fk_payments_eras
  FOREIGN KEY (era_id) REFERENCES rcm.eras(id);

V010__create_denials.sql:
Table: rcm.denials
Columns: id, tenant_id FK→tenants,
claim_id UUID NOT NULL REFERENCES rcm.claims(id),
denial_date DATE NOT NULL,
carc_code VARCHAR(10) NOT NULL (Claim Adjustment Reason Code),
rarc_code VARCHAR(10) (Remittance Advice Remark Code — optional),
denial_reason TEXT,
status VARCHAR(30) NOT NULL DEFAULT 'RECEIVED' CHECK(status IN
  ('RECEIVED','TRIAGED','AGENT_ANALYZING','APPEAL_DRAFTED',
   'HUMAN_REVIEW','APPEAL_SUBMITTED','RESOLVED','ESCALATED','CLOSED')),
agent_run_id UUID (LangGraph run ID — null until agent triggered),
explanation TEXT (AI-generated explanation — null until agent completes),
created_at, updated_at
Indexes: idx_denials_tenant_id, idx_denials_claim_id,
idx_denials_status, idx_denials_carc_code, idx_denials_agent_run_id

V011__create_appeals.sql:
Table: rcm.appeals
Columns: id, tenant_id FK→tenants,
denial_id UUID NOT NULL REFERENCES rcm.denials(id),
draft_text TEXT (AI-drafted appeal letter),
approved_text TEXT (biller-edited and approved version),
approved_by UUID (userId of approving biller),
approved_at TIMESTAMPTZ,
submitted_at TIMESTAMPTZ,
outcome VARCHAR(20) CHECK(outcome IN ('accepted','denied','partial','pending')),
outcome_date DATE,
usefulness_score INTEGER CHECK(usefulness_score BETWEEN 1 AND 5)
  COMMENT: biller rates the AI draft quality 1-5 after resolution,
created_at, updated_at
Indexes: idx_appeals_denial_id, idx_appeals_approved_by, idx_appeals_submitted_at

V012__create_ar_balances.sql:
Table: rcm.ar_balances (Accounts Receivable tracking)
Columns: id, tenant_id FK→tenants,
patient_id UUID NOT NULL REFERENCES rcm.patients(id),
claim_id UUID NOT NULL REFERENCES rcm.claims(id),
balance_cents INTEGER NOT NULL DEFAULT 0,
aging_bucket VARCHAR(10) NOT NULL CHECK(aging_bucket IN
  ('0-30','31-60','61-90','91-120','121-180','180+')),
last_follow_up_at TIMESTAMPTZ,
created_at, updated_at
Constraints: UNIQUE(tenant_id, claim_id) (one AR balance per claim)
Indexes: idx_ar_balances_tenant_id, idx_ar_balances_patient_id,
idx_ar_balances_claim_id, idx_ar_balances_aging_bucket

V013__create_feature_flags.sql:
Table: rcm.feature_flags
Columns: id, tenant_id UUID REFERENCES rcm.tenants(id)
  (nullable — null means global flag applying to all tenants),
flag_name VARCHAR(100) NOT NULL,
enabled BOOLEAN NOT NULL DEFAULT false,
metadata JSONB NOT NULL DEFAULT '{}'
  (stores: description, owner, created_reason, rollout_percentage),
created_at, updated_at
Constraints: UNIQUE(tenant_id, flag_name),
  UNIQUE(flag_name) WHERE tenant_id IS NULL (one global flag per name)
Indexes: idx_feature_flags_flag_name, idx_feature_flags_tenant_id

Insert default flags:
INSERT INTO rcm.feature_flags (flag_name, enabled, metadata) VALUES
  ('rag.claim-scrubbing', false, '{"description": "Enable LLM-based claim scrubbing via rcm-rag"}'),
  ('rag.denial-explanation', false, '{"description": "Enable LangGraph denial resolution agent"}'),
  ('rag.appeal-drafting', false, '{"description": "Enable LLM-drafted appeal letters"}'),
  ('ai.claim-summarization', false, '{"description": "Enable Spring AI claim narrative summarization"}');

OUTPUT: 7 files (V007 through V013).
// FILE: rcm-core/app/src/main/resources/db/migration/V007__create_payers.sql
[SQL]
// ===== END OF FILE =====
[repeat for V008-V013]
==========================================

# ============================================================
# PROMPT-021: Flyway Migrations Batch 3 — V014 through V016
# ============================================================
# GOAL: RAG schema, pgvector indexes, materialized views
# DEPENDS ON: PROMPT-019 PROMPT-020
# OUTPUT: V014__create_rag_schema.sql
#         V015__create_vector_indexes.sql
#         V016__create_materialized_views.sql
# ACCEPTANCE CRITERIA:
#   1. V014 creates all RAG tables in the rag schema
#   2. V015 creates HNSW indexes (not IVFFlat) on embedding columns
#      with cosine distance operator class
#   3. V016 creates all 4 materialized views with pg_cron refresh jobs
#   4. HNSW index parameters explained in comments (m, ef_construction)
# ============================================================

PROMPT-021 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Flyway SQL migration files V014-V016 for the RAG
(Retrieval-Augmented Generation) schema and analytics views.

V014__create_rag_schema.sql:
All tables in schema: rag

Table: rag.rag_documents
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
tenant_id UUID NOT NULL REFERENCES rcm.tenants(id),
source_type VARCHAR(50) NOT NULL CHECK(source_type IN
  ('payer_policy','appeal_template','medical_necessity','carc_definition','other')),
source_name VARCHAR(500) NOT NULL,
payer_id UUID REFERENCES rcm.payers(id) (null = applies to all payers),
effective_date DATE,
expiry_date DATE,
content TEXT NOT NULL,
metadata JSONB NOT NULL DEFAULT '{}',
ingested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
embedding_model VARCHAR(100) NOT NULL
  (tracks which model version produced embeddings for this document),
created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
Indexes: idx_rag_documents_tenant_id, idx_rag_documents_payer_id,
idx_rag_documents_source_type, idx_rag_documents_effective_date

Table: rag.rag_chunks
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
tenant_id UUID NOT NULL REFERENCES rcm.tenants(id),
document_id UUID NOT NULL REFERENCES rag.rag_documents(id) ON DELETE CASCADE,
chunk_index INTEGER NOT NULL CHECK(chunk_index >= 0),
content TEXT NOT NULL,
token_count INTEGER NOT NULL CHECK(token_count > 0),
metadata JSONB NOT NULL DEFAULT '{}',
created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
Constraints: UNIQUE(document_id, chunk_index)
Indexes: idx_rag_chunks_tenant_id, idx_rag_chunks_document_id

Table: rag.rag_embeddings
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
tenant_id UUID NOT NULL REFERENCES rcm.tenants(id),
chunk_id UUID NOT NULL REFERENCES rag.rag_chunks(id) ON DELETE CASCADE,
embedding vector(1536) NOT NULL
  COMMENT: dimension 1536 = Azure OpenAI text-embedding-3-small.
           Dev uses bge-small-en-v1.5 (384 dims) — separate migration for dev profile,
model_version VARCHAR(100) NOT NULL
  COMMENT: e.g. text-embedding-3-small-2024-02 — NEVER mix dimensionalities,
created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
Constraints: UNIQUE(chunk_id)

Table: rag.cached_llm_responses (semantic cache)
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
tenant_id UUID NOT NULL REFERENCES rcm.tenants(id),
query_hash VARCHAR(64) NOT NULL (SHA-256 of query text, for exact match),
prompt_version_id VARCHAR(100) NOT NULL,
chunk_ids UUID[] NOT NULL (which chunks were used),
query_embedding vector(1536) (for semantic similarity lookup),
response_text TEXT NOT NULL,
response_metadata JSONB NOT NULL DEFAULT '{}',
hit_count INTEGER NOT NULL DEFAULT 0,
created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
last_hit_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
Indexes: idx_cached_responses_tenant_id,
idx_cached_responses_query_hash (for exact match lookup)

Table: rag.eval_results
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
prompt_id VARCHAR(100) NOT NULL,
prompt_version VARCHAR(20) NOT NULL,
eval_set VARCHAR(100) NOT NULL,
run_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
faithfulness DECIMAL(5,4), answer_relevance DECIMAL(5,4),
context_relevance DECIMAL(5,4),
recall_at_1 DECIMAL(5,4), recall_at_3 DECIMAL(5,4),
recall_at_5 DECIMAL(5,4), recall_at_10 DECIMAL(5,4),
precision_at_5 DECIMAL(5,4), mrr DECIMAL(5,4), ndcg_at_5 DECIMAL(5,4),
hit_rate_at_5 DECIMAL(5,4),
bleu4 DECIMAL(5,4), rouge_l DECIMAL(5,4),
cosine_similarity DECIMAL(5,4), bert_score DECIMAL(5,4),
carc_accuracy DECIMAL(5,4),
passed_thresholds BOOLEAN NOT NULL DEFAULT false,
metadata JSONB NOT NULL DEFAULT '{}'
Indexes: idx_eval_results_prompt_id, idx_eval_results_run_at

Table: rag.agent_states (durable LangGraph state)
Columns: id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
tenant_id UUID NOT NULL REFERENCES rcm.tenants(id),
denial_id UUID NOT NULL REFERENCES rcm.denials(id),
run_id UUID NOT NULL UNIQUE,
current_node VARCHAR(50) NOT NULL,
state JSONB NOT NULL (full LangGraph state — all node outputs accumulated),
interrupted_at TIMESTAMPTZ,
resumed_at TIMESTAMPTZ,
completed_at TIMESTAMPTZ,
created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
Indexes: idx_agent_states_denial_id, idx_agent_states_run_id

V015__create_vector_indexes.sql:
Create HNSW indexes on embedding columns.

COMMENT explaining HNSW vs IVFFlat:
-- HNSW (Hierarchical Navigable Small World) index chosen over IVFFlat because:
-- 1. Better query performance (no need to set probes parameter)
-- 2. No training step required (IVFFlat requires CREATE INDEX to run after data load)
-- 3. Better recall at same query speed for our corpus size (<10M vectors)
-- Trade-off: HNSW uses more memory and is slower to build initially
-- m=16: number of connections per layer (higher = better recall, more memory)
-- ef_construction=64: search depth during index build (higher = better quality index, slower build)

CREATE INDEX CONCURRENTLY idx_rag_embeddings_hnsw
  ON rag.rag_embeddings
  USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);

CREATE INDEX CONCURRENTLY idx_cached_responses_embedding_hnsw
  ON rag.cached_llm_responses
  USING hnsw (query_embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);

COMMENT ON INDEX idx_rag_embeddings_hnsw IS
  'HNSW index for cosine similarity search. Used by pgvector hybrid retrieval.
   Query pattern: WHERE tenant_id = ? AND payer_id = ? ORDER BY embedding <=> ? LIMIT ?';

V016__create_materialized_views.sql:
Create 4 materialized views and pg_cron refresh jobs.

1. rcm.mv_ar_aging_buckets — AR aging report
   SELECT tenant_id, aging_bucket,
     COUNT(*) as claim_count,
     SUM(balance_cents) as total_balance_cents,
     AVG(balance_cents)::INTEGER as avg_balance_cents
   FROM rcm.ar_balances
   WHERE deleted_at IS NULL
   GROUP BY tenant_id, aging_bucket

2. rcm.mv_denial_rate_by_payer — denial analytics
   SELECT c.tenant_id, c.payer_id, p.name as payer_name,
     COUNT(*) as total_claims,
     COUNT(d.id) as denied_claims,
     ROUND(COUNT(d.id)::DECIMAL / COUNT(*) * 100, 2) as denial_rate_pct,
     DATE_TRUNC('month', c.created_at) as month
   FROM rcm.claims c
   LEFT JOIN rcm.denials d ON d.claim_id = c.id
   JOIN rcm.payers p ON c.payer_id = p.id
   GROUP BY c.tenant_id, c.payer_id, p.name, DATE_TRUNC('month', c.created_at)

3. rcm.mv_claim_throughput_by_day — operational metrics
   SELECT tenant_id,
     DATE_TRUNC('day', created_at) as day,
     COUNT(*) as claims_created,
     COUNT(*) FILTER (WHERE status = 'PAID') as claims_paid,
     COUNT(*) FILTER (WHERE status = 'DENIED') as claims_denied,
     SUM(total_charge_cents) as total_charged_cents,
     SUM(paid_amount_cents) as total_paid_cents
   FROM rcm.claims
   GROUP BY tenant_id, DATE_TRUNC('day', created_at)

4. rcm.mv_feature_flag_summary — flag status across tenants
   SELECT flag_name, enabled,
     COUNT(tenant_id) as tenant_count
   FROM rcm.feature_flags
   GROUP BY flag_name, enabled

pg_cron refresh jobs (run at 2am UTC daily):
SELECT cron.schedule('refresh-ar-aging', '0 2 * * *',
  'REFRESH MATERIALIZED VIEW CONCURRENTLY rcm.mv_ar_aging_buckets');
[repeat for each view]

Create unique indexes on materialized views to support CONCURRENTLY refresh:
CREATE UNIQUE INDEX ON rcm.mv_ar_aging_buckets(tenant_id, aging_bucket);
[etc.]

OUTPUT: 3 files (V014, V015, V016).
Each: // FILE: path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-022: Kafka Topic Definitions + Event Schemas
# ============================================================
# GOAL: Kafka topic config + JSON schemas for all 4 event types
# DEPENDS ON: PROMPT-001 PROMPT-009 PROMPT-010
# OUTPUT: infrastructure/kafka/topics.yml
#         infrastructure/kafka/schemas/claim-submitted.json
#         infrastructure/kafka/schemas/denial-received.json
#         infrastructure/kafka/schemas/denial-explained.json
#         infrastructure/kafka/schemas/notification-requested.json
# ACCEPTANCE CRITERIA:
#   1. topics.yml lists all 4 topics with partitions, replication,
#      retention, and cleanup policy
#   2. Each JSON schema is JSON Schema draft-07
#   3. Every schema has tenantId as required field
#   4. Schemas include metadata envelope (eventId, eventType, timestamp,
#      schemaVersion, traceId)
# ============================================================

PROMPT-022 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Kafka configuration and event schemas for a
production-grade RCM platform using Apache Kafka 3.7.

KAFKA TOPICS (4 total):

claim.submitted:
- Purpose: Published by rcm-core when a claim is submitted to clearinghouse
- Producers: rcm-core ClaimEventPublisher
- Consumers: rcm-notify (sends submission confirmation email)
- Partitions: 6 (partition by tenantId hash for ordering per tenant)
- Replication factor: 3 (prod), 1 (dev)
- Retention: 7 days
- Cleanup policy: delete

denial.received:
- Purpose: Published by rcm-core when an ERA is processed and denials found
- Producers: rcm-core DenialReceivedConsumer (confusingly named — it publishes here)
- Consumers: rcm-rag (triggers denial resolution agent), rcm-notify (sends denial alert)
- Partitions: 6
- Replication factor: 3 (prod), 1 (dev)
- Retention: 30 days (longer — agent may take time to process)
- Cleanup policy: delete

denial.explained:
- Purpose: Published by rcm-rag when agent completes (appeal drafted, interrupted for review, or escalated)
- Producers: rcm-rag DenialExplanationFlow
- Consumers: rcm-core DenialExplainedConsumer (updates denial status)
- Partitions: 6
- Replication factor: 3 (prod), 1 (dev)
- Retention: 30 days
- Cleanup policy: delete

notification.requested:
- Purpose: Published by rcm-core to request notifications without coupling to delivery
- Producers: rcm-core (various services)
- Consumers: rcm-notify
- Partitions: 3
- Replication factor: 3 (prod), 1 (dev)
- Retention: 3 days
- Cleanup policy: delete

topics.yml format:
topics:
  - name: claim.submitted
    partitions: 6
    replicationFactor: 3
    config:
      retention.ms: [value]
      cleanup.policy: delete
      compression.type: lz4
    description: [purpose]
    producers: [list]
    consumers: [list]
[repeat for each topic]

JSON EVENT SCHEMAS (JSON Schema draft-07):

All schemas share a metadata envelope:
{
  "$schema": "...",
  "type": "object",
  "required": ["eventId", "eventType", "schemaVersion", "timestamp", "tenantId", ...],
  "properties": {
    "eventId": {"type": "string", "format": "uuid"},
    "eventType": {"type": "string", "const": "..."},
    "schemaVersion": {"type": "string", "const": "1.0.0"},
    "timestamp": {"type": "string", "format": "date-time"},
    "tenantId": {"type": "string", "format": "uuid"},
    "traceId": {"type": "string", "description": "W3C Trace Context trace ID"},
    ... payload fields ...
  }
}

claim-submitted.json payload fields:
claimId (uuid), encounterId (uuid), patientId (uuid), payerId (uuid),
claimType ("837P"|"837I"), totalChargeCents (integer),
edi837Snippet (string, first 500 chars of EDI for logging — NOT full PHI),
submittedAt (date-time), clearinghouseEndpoint (string)

denial-received.json payload fields:
denialId (uuid), claimId (uuid), patientId (uuid), payerId (uuid),
eraId (uuid), carcCode (string), rarcCode (string, nullable),
denialDate (date), denialReasonSummary (string, no PHI),
totalDeniedCents (integer)

denial-explained.json payload fields:
denialId (uuid), agentRunId (uuid), outcomeType
("appeal_drafted"|"escalated"|"interrupted_for_review"),
currentNode (string), stepsCompleted (array of strings),
appealDraftLength (integer, char count — not the text itself),
processingTimeMs (integer), modelUsed (string)
Note: NO appeal text in Kafka — text stays in Postgres

notification-requested.json payload fields:
notificationId (uuid), notificationType
("claim_submitted"|"denial_received"|"appeal_ready"|"appeal_submitted"),
recipientType ("biller"|"provider"|"admin"),
recipientId (uuid), channel ("email"|"sms"|"webhook"),
templateId (string), templateData (object, template-specific fields),
priority ("high"|"normal"|"low")
Note: templateData must NOT contain PHI — use references (patientId) not values

OUTPUT: 5 files.
// FILE: infrastructure/kafka/topics.yml
// FILE: infrastructure/kafka/schemas/claim-submitted.json
// FILE: infrastructure/kafka/schemas/denial-received.json
// FILE: infrastructure/kafka/schemas/denial-explained.json
// FILE: infrastructure/kafka/schemas/notification-requested.json
Each ends with // ===== END OF FILE =====

Include comments in YAML explaining design decisions.
Include $comment fields in JSON schemas explaining field-level decisions.
==========================================

# ============================================================
# PROMPT-023: Seed Data Batch 1 — Patients, Payers, CARC/RARC Codes
# ============================================================
# GOAL: Realistic synthetic seed data for dev/testing
# DEPENDS ON: PROMPT-019 PROMPT-020
# OUTPUT: infrastructure/seed-data/synthetic-patients.sql
#         infrastructure/seed-data/synthetic-payers.sql
#         infrastructure/seed-data/carc-codes.sql
#         infrastructure/seed-data/rarc-codes.sql
# ACCEPTANCE CRITERIA:
#   1. Patients: 20 synthetic patients, realistic demographics,
#      NO real SSNs (use fake format 000-XX-XXXX), 2 tenant IDs used
#   2. Payers: 8 synthetic payers covering all payer types
#   3. CARC codes: top 30 most common denial codes with descriptions
#   4. RARC codes: top 20 most common remark codes with descriptions
#   5. All IDs are valid UUIDs (hardcoded so seed is idempotent)
#   6. INSERT ... ON CONFLICT DO NOTHING for idempotency
# ============================================================

PROMPT-023 CONTEXT — paste this into DeepSeek:
==========================================
You are generating synthetic seed data SQL for a development/testing
environment of an RCM platform. All patient data is SYNTHETIC — no real PHI.

TENANTS (already seeded by application bootstrap, referenced here):
tenant_id_1 = 'a0000000-0000-0000-0000-000000000001' (Sunrise Medical Group)
tenant_id_2 = 'a0000000-0000-0000-0000-000000000002' (Riverside Health Partners)

synthetic-patients.sql:
- 10 patients for tenant_1, 10 patients for tenant_2
- Realistic but clearly fake names (e.g. John Testpatient, Jane Sampleson)
- DOBs spread across age ranges: 1960s, 1970s, 1980s, 1990s, 2000s
- SSN format: 000-00-XXXX (clearly fake per IRS guidelines)
- Mix of genders: male, female, other
- Addresses: use fictional street names in real cities
- Insurance info JSONB: include memberId, groupNumber for each patient
- MRNs: format MRN-XXXXX (sequential per tenant)
- All patient_ids hardcoded as valid UUIDs (format b0000000-...)
- Use INSERT INTO rcm.patients (...) VALUES (...) ON CONFLICT (id) DO NOTHING

synthetic-payers.sql:
8 payers:
1. Aetna Health Insurance (commercial) — payer_id_external: AETNA001
2. Blue Cross Blue Shield (commercial) — payer_id_external: BCBS001
3. UnitedHealthcare (commercial) — payer_id_external: UHC001
4. Cigna Healthcare (commercial) — payer_id_external: CIGNA001
5. Medicare Part B (medicare) — payer_id_external: MEDICARE_B
6. Medicaid (medicaid) — payer_id_external: MEDICAID_STATE
7. TRICARE (tricare) — payer_id_external: TRICARE001
8. Self Pay (self_pay) — payer_id_external: SELF_PAY
All payers created for both tenants (16 total rows)
Payer IDs: format c0000000-...

carc-codes.sql:
Reference data table — NOT tenant-specific.
CREATE TABLE IF NOT EXISTS rcm.carc_codes (
  code VARCHAR(10) PRIMARY KEY,
  description TEXT NOT NULL,
  category VARCHAR(50),
  is_denial BOOLEAN NOT NULL DEFAULT true
);

Insert top 30 CARC codes with accurate descriptions (these are public data):
- CARC 1: Deductible Amount
- CARC 2: Coinsurance Amount
- CARC 3: Co-payment Amount
- CARC 4: The service/equipment/drug is not covered by the plan
- CARC 16: Claim/service lacks information or has submission/billing error(s)
- CARC 18: Exact duplicate claim/service
- CARC 22: This care may be covered by another payer
- CARC 27: Expenses incurred after coverage terminated
- CARC 29: The time limit for filing has expired
- CARC 45: Charge exceeds fee schedule/maximum allowable or contracted/legislated fee arrangement
- CARC 50: These are non-covered services because this is not deemed a medical necessity
- CARC 55: Procedure/treatment/drug is deemed experimental/investigational
- CARC 56: Procedure/treatment has not been deemed proven to be effective by the payer
- CARC 57: Prior authorization/pre-certification absent
- CARC 58: Treatment was deemed by the payer to have been rendered in an inappropriate or invalid place of service
- CARC 59: Processed based on multiple or concurrent procedure rules
- CARC 60: Charges for outpatient services with this proximity to inpatient services are not covered
- CARC 97: The benefit for this service is included in the payment/allowance for another service/procedure
- CARC 109: Claim/service not covered by this payer/contractor
- CARC 119: Benefit maximum for this time period or occurrence has been reached
- CARC 151: Payment adjusted because the payer deems the information submitted does not support this many/frequency of services
- CARC 170: Payment is denied when performed/billed by this type of provider
- CARC 177: Patient has not met the required eligibility requirements
- CARC 192: Non standard adjustment code from paper remittance
- CARC 197: Precertification/authorization/notification/pre-treatment absent
- CARC 199: Revenue code and Procedure code do not match
- CARC 234: This procedure is not paid separately
- CARC 236: This procedure or procedure/modifier combination is not compatible with another procedure or procedure/modifier combination provided on the same day according to the National Correct Coding Initiative or workers compensation state regulations
- CARC 242: Services not provided by network/primary care providers
- CARC 243: Services not authorized by network/primary care providers

rarc-codes.sql:
CREATE TABLE IF NOT EXISTS rcm.rarc_codes (
  code VARCHAR(10) PRIMARY KEY,
  description TEXT NOT NULL,
  category VARCHAR(50)
);

Insert top 20 RARC codes:
- N1: Alert: This is a telephone number
- N10: Payment based on the findings of a review organization
- N15: Services for a newborn must be billed separately
- N19: Procedure code incidental to primary procedure
- N30: Patient ineligible for this service
- N56: Procedure code billed is not correct/valid for the services billed or the date of service billed
- N95: This provider type/specialty may not bill this service
- N96: Patient must be reimbursed for overpayment
- N97: The subscriber must be reimbursed for overpayment
- N104: This claim/service is not payable under our claims jurisdiction area
- N115: This decision was based on a local coverage determination
- N130: Consult plan benefit documents/guidelines for information about restrictions for this service
- N179: Additional information has been requested from the member
- N180: This item or service does not meet the criteria for the category under which it was billed
- N181: Additional information is required from the injured party
- N182: This claim is denied as you did not certify to the accuracy of the submitted information
- N362: The number of Days or Units of Service exceeds our acceptable maximum
- N422: Payment is included in the allowance for a previous service/claim
- N479: Resubmit with the corrected code for this service
- N519: Invalid combination of HCPCS modifiers

OUTPUT: 4 files. Each: // FILE: path // ===== END OF FILE =====
Mark all synthetic patient data with comments: -- SYNTHETIC DATA: Not real PHI
==========================================
