# BATCH B — Prompts 024–030
# Seed Data cont., Docker Compose, Observability, Terraform, CI, Makefile
# MAX RIGIDITY throughout.
# ============================================================

# ============================================================
# PROMPT-024: Seed Data Batch 2 — CPT, ICD10, Payer Policies, Appeal Templates
# ============================================================
# GOAL: Reference code data + RAG corpus seed content
# DEPENDS ON: PROMPT-019
# OUTPUT: infrastructure/seed-data/cpt-codes.sql
#         infrastructure/seed-data/icd10-codes.sql
#         infrastructure/seed-data/synthetic-payer-policies/aetna-policy-001.txt
#         infrastructure/seed-data/synthetic-payer-policies/cigna-policy-001.txt
#         infrastructure/seed-data/synthetic-payer-policies/uhc-policy-001.txt
#         infrastructure/seed-data/synthetic-payer-policies/bcbs-policy-001.txt
#         infrastructure/seed-data/synthetic-appeal-templates/medical-necessity-appeal.txt
#         infrastructure/seed-data/synthetic-appeal-templates/coding-error-appeal.txt
#         infrastructure/seed-data/synthetic-appeal-templates/timely-filing-appeal.txt
# ACCEPTANCE CRITERIA:
#   1. CPT: 50 common outpatient codes with descriptions
#   2. ICD10: 50 common diagnosis codes with descriptions
#   3. Payer policies: realistic 300-500 word policy documents per payer
#      covering medical necessity criteria for common procedures
#   4. Appeal templates: 400-600 word template with {placeholder} variables
# ============================================================

PROMPT-024 CONTEXT — paste this into DeepSeek:
==========================================
You are generating seed data for the RAG corpus and reference code tables
of an RCM platform. This data will be ingested into pgvector for
retrieval-augmented generation.

cpt-codes.sql:
CREATE TABLE IF NOT EXISTS rcm.cpt_codes (
  code VARCHAR(10) PRIMARY KEY,
  description TEXT NOT NULL,
  category VARCHAR(100),
  typical_place_of_service VARCHAR(5),
  requires_modifier BOOLEAN DEFAULT false
);

Insert 50 common outpatient CPT codes covering:
Office visits (99202-99215), Preventive (99381-99397),
Common procedures: 20610 (joint injection), 27447 (knee replacement),
43239 (upper endoscopy with biopsy), 43239, 45378 (colonoscopy),
64483 (epidural injection), 70553 (MRI brain with contrast),
71046 (chest X-ray 2 views), 80053 (comprehensive metabolic panel),
81001 (urinalysis), 85025 (CBC with differential),
86803 (hepatitis C antibody), 87491 (chlamydia test),
90837 (psychotherapy 60 min), 90847 (family therapy),
92012 (ophthalmology intermediate), 93000 (ECG routine),
93306 (echo with doppler), 96372 (therapeutic injection),
99213 (office visit established moderate), 99214 (office visit established mod-high),
99215 (office visit established high complexity),
and 25 more realistic codes.

icd10-codes.sql:
CREATE TABLE IF NOT EXISTS rcm.icd10_codes (
  code VARCHAR(10) PRIMARY KEY,
  description TEXT NOT NULL,
  category VARCHAR(100),
  is_billable BOOLEAN DEFAULT true
);

Insert 50 common ICD-10 diagnosis codes:
E11.9 (Type 2 diabetes without complications),
E78.5 (Hyperlipidemia unspecified),
F32.9 (Major depressive disorder single episode unspecified),
G43.909 (Migraine unspecified not intractable),
I10 (Essential hypertension),
I25.10 (Atherosclerotic heart disease of native coronary artery),
J06.9 (Acute upper respiratory infection unspecified),
J18.9 (Pneumonia unspecified organism),
K21.0 (GERD with esophagitis),
K57.30 (Diverticulosis of large intestine without perforation),
L40.0 (Psoriasis vulgaris),
M17.11 (Primary osteoarthritis right knee),
M54.5 (Low back pain),
N18.3 (Chronic kidney disease stage 3),
R05.9 (Cough unspecified),
R51.9 (Headache unspecified),
Z00.00 (Encounter for general adult medical exam without abnormal findings),
Z12.11 (Encounter for screening for malignant neoplasm of colon),
Z23 (Encounter for immunization),
and 31 more realistic common codes.

PAYER POLICY DOCUMENTS (synthetic but realistic):
These will be ingested as RAG corpus documents.
Each should be 300-500 words, realistic medical necessity policy language.

aetna-policy-001.txt — Aetna Medical Necessity Policy for Knee Replacement (27447):
Include: covered indications (severe osteoarthritis, failed conservative treatment 6+ months,
X-ray evidence of joint space narrowing, functional limitation documentation),
non-covered indications (mild arthritis, no conservative treatment attempted),
prior authorization requirements, documentation requirements,
appeal rights statement.
Header: "AETNA HEALTH INSURANCE — CLINICAL POLICY BULLETIN"
"CPT Code: 27447 — Total Knee Arthroplasty"
"Policy Number: CP.MP.117 | Effective Date: January 1, 2024"

cigna-policy-001.txt — Cigna Policy for Colonoscopy (45378):
Include: screening indications (age 45+ average risk, age 40+ high risk with family history),
diagnostic indications (symptoms warranting evaluation),
frequency limitations (every 10 years for normal screening),
documentation requirements, modifier requirements.
Header: "CIGNA HEALTHCARE — COVERAGE POLICY"
"CPT Code: 45378 — Diagnostic Colonoscopy"

uhc-policy-001.txt — UnitedHealthcare Policy for MRI Brain (70553):
Include: covered indications (headache with red flags, neurological symptoms,
trauma, suspected mass), non-covered (routine headache without red flags,
screening without symptoms), prior auth requirements for outpatient,
documentation: ordering provider notes, symptom duration, failed conservative management.
Header: "UNITEDHEALTHCARE — COVERAGE DETERMINATION GUIDELINE"
"CPT Code: 70553 — MRI Brain with Contrast"

bcbs-policy-001.txt — BCBS Policy for Epidural Steroid Injection (64483):
Include: covered indications (radicular pain, failed 6 weeks conservative therapy,
imaging evidence of disc pathology), frequency limits (3 per region per year),
documentation requirements, modifier requirements, prior auth thresholds.
Header: "BLUE CROSS BLUE SHIELD — MEDICAL POLICY"
"CPT Code: 64483 — Epidural Steroid Injection"

APPEAL TEMPLATES:
These are letter templates with {placeholder} variables for agent use.

medical-necessity-appeal.txt:
Full appeal letter template, ~500 words.
Placeholders: {patient_name}, {date_of_birth}, {member_id}, {claim_number},
{date_of_service}, {procedure_code}, {procedure_description}, {diagnosis_code},
{denial_reason}, {carc_code}, {provider_name}, {provider_npi},
{clinical_justification}, {supporting_documentation_list}, {appeal_date}

Structure:
- Header: provider info, date, payer address
- Re: line with claim details
- Opening: state we are appealing denial of claim
- Section 1: Summary of services provided
- Section 2: Medical necessity justification
  "{clinical_justification}" placeholder — agent fills this
- Section 3: Supporting documentation
- Section 4: Request for expedited review
- Closing with signature block

coding-error-appeal.txt:
Appeal for coding-related denials (CARC 16, 236, 199).
Placeholders: same as above plus {original_code}, {corrected_code}, {correction_explanation}
Structure:
- Acknowledgment that a coding discrepancy was identified
- Explanation of the coding correction
- Reference to coding guidelines (AMA CPT guidelines, NCCI edits)
- Request for reprocessing with corrected codes

timely-filing-appeal.txt:
Appeal for timely filing denials (CARC 29).
Placeholders: same as above plus {original_submission_date},
{proof_of_timely_filing_description}, {system_error_description}
Structure:
- Assertion that claim was timely filed
- Evidence of original submission (date, method, confirmation number)
- If system error: description of error and its resolution
- Request for reprocessing

OUTPUT: 9 files total.
// FILE: path
[content]
// ===== END OF FILE =====
Policy documents and templates should be realistic enough that an LLM
can reason about them in the context of a specific denial.
==========================================

# ============================================================
# PROMPT-025: docker-compose.yml — Full Local Stack
# ============================================================
# GOAL: Complete docker-compose for all infrastructure + app services
# DEPENDS ON: PROMPT-001 through PROMPT-024
# OUTPUT: infrastructure/docker-compose.yml
#         infrastructure/.env.example
# ACCEPTANCE CRITERIA:
#   1. All 15 infrastructure containers defined with correct versions
#      from 03_PINNED_TECH_STACK.md
#   2. All 5 app service containers defined (build from Dockerfile)
#   3. Health checks on every container
#   4. Correct startup order via depends_on with condition: service_healthy
#   5. Named volumes for all stateful services
#   6. Single bridge network: rcm-network
#   7. .env.example documents every environment variable with description
#   8. Cosmos emulator uses correct Azure Cosmos DB Linux Emulator image
# ============================================================

PROMPT-025 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the docker-compose.yml for a production-grade RCM
platform local development environment.

PINNED VERSIONS (use exactly these):
postgres: 16.4-alpine
pgvector: use postgres:16-alpine with pgvector installed via init script
  OR use ankane/pgvector:v0.7.4 if simpler
mongo: 7.0.14
redis: 7.2.5-alpine
kafka: confluentinc/cp-kafka:7.7.1
zookeeper: confluentinc/cp-zookeeper:7.7.1
keycloak: quay.io/keycloak/keycloak:25.0.6
cosmos-emulator: mcr.microsoft.com/cosmosdb/linux/azure-cosmos-emulator:latest
prometheus: prom/prometheus:v2.54.1
grafana: grafana/grafana:11.2.0
loki: grafana/loki:3.1.1
tempo: grafana/tempo:2.5.0
mimir: grafana/mimir:2.13.0
ollama: ollama/ollama:0.3.10

NETWORK: rcm-network (bridge driver)

VOLUMES (named):
postgres-data, mongo-data, redis-data, cosmos-data,
kafka-data, zookeeper-data, grafana-data, loki-data,
tempo-data, mimir-data, ollama-data

INFRASTRUCTURE SERVICES:

postgres:
  image: postgres:16.4-alpine
  environment: POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD (from .env)
  ports: "5432:5432"
  volumes: postgres-data:/var/lib/postgresql/data
    + ./seed-data/:/docker-entrypoint-initdb.d/ (for init scripts)
  command: postgres -c shared_preload_libraries=pg_cron,pg_stat_statements
    -c pg_cron.database=rcm -c log_statement=all
  healthcheck: pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}

mongo:
  image: mongo:7.0.14
  environment: MONGO_INITDB_ROOT_USERNAME, MONGO_INITDB_ROOT_PASSWORD
  ports: "27017:27017"
  volumes: mongo-data:/data/db
  healthcheck: mongosh --eval "db.adminCommand('ping')"

redis:
  image: redis:7.2.5-alpine
  command: redis-server --requirepass ${REDIS_PASSWORD} --maxmemory 512mb
    --maxmemory-policy allkeys-lru
  ports: "6379:6379"
  volumes: redis-data:/data
  healthcheck: redis-cli -a ${REDIS_PASSWORD} ping

zookeeper:
  image: confluentinc/cp-zookeeper:7.7.1
  environment: ZOOKEEPER_CLIENT_PORT=2181, ZOOKEEPER_TICK_TIME=2000
  volumes: zookeeper-data:/var/lib/zookeeper
  healthcheck: echo ruok | nc localhost 2181

kafka:
  image: confluentinc/cp-kafka:7.7.1
  depends_on: zookeeper (service_healthy)
  environment:
    KAFKA_BROKER_ID: 1
    KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
    KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:9092,PLAINTEXT_HOST://localhost:9093
    KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
    KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    KAFKA_AUTO_CREATE_TOPICS_ENABLE: false
  ports: "9093:9093" (host access port)
  volumes: kafka-data:/var/lib/kafka
  healthcheck: kafka-broker-api-versions --bootstrap-server localhost:9092

kafka-init: (one-shot service to create topics)
  image: confluentinc/cp-kafka:7.7.1
  depends_on: kafka (service_healthy)
  command: |
    bash -c "
    kafka-topics --create --if-not-exists --topic claim.submitted --partitions 6 ...
    kafka-topics --create --if-not-exists --topic denial.received --partitions 6 ...
    kafka-topics --create --if-not-exists --topic denial.explained --partitions 6 ...
    kafka-topics --create --if-not-exists --topic notification.requested --partitions 3 ...
    "
  restart: on-failure

keycloak:
  image: quay.io/keycloak/keycloak:25.0.6
  command: start-dev --import-realm
  environment: KEYCLOAK_ADMIN, KEYCLOAK_ADMIN_PASSWORD, KC_DB=dev-mem
  ports: "8080:8080"
  volumes: ./keycloak/realm-export.json:/opt/keycloak/data/import/realm-export.json
  healthcheck: curl -f http://localhost:8080/health/ready

cosmos-emulator:
  image: mcr.microsoft.com/cosmosdb/linux/azure-cosmos-emulator:latest
  environment:
    AZURE_COSMOS_EMULATOR_PARTITION_COUNT: 10
    AZURE_COSMOS_EMULATOR_ENABLE_DATA_PERSISTENCE: true
    AZURE_COSMOS_EMULATOR_IP_ADDRESS_OVERRIDE: cosmos-emulator
  ports: "8081:8081", "10251:10251", "10252:10252", "10253:10253", "10254:10254"
  volumes: cosmos-data:/tmp/cosmos/appdata
  healthcheck: curl -k -f https://localhost:8081/_explorer/emulator.pem

prometheus:
  image: prom/prometheus:v2.54.1
  command: --config.file=/etc/prometheus/prometheus.yml --storage.tsdb.retention.time=15d
  ports: "9090:9090"
  volumes:
    ./observability/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml:ro

grafana:
  image: grafana/grafana:11.2.0
  environment: GF_SECURITY_ADMIN_PASSWORD, GF_AUTH_ANONYMOUS_ENABLED=false
  ports: "3001:3000"
  volumes:
    grafana-data:/var/lib/grafana
    ./observability/grafana/provisioning:/etc/grafana/provisioning:ro
    ./observability/grafana/dashboards:/var/lib/grafana/dashboards:ro
  depends_on: prometheus, loki, tempo

loki:
  image: grafana/loki:3.1.1
  ports: "3100:3100"
  volumes:
    ./observability/loki/loki-config.yml:/etc/loki/config.yml:ro
    loki-data:/loki

tempo:
  image: grafana/tempo:2.5.0
  command: -config.file=/etc/tempo/config.yml
  ports: "3200:3200", "4317:4317" (OTLP gRPC), "4318:4318" (OTLP HTTP)
  volumes:
    ./observability/tempo/tempo-config.yml:/etc/tempo/config.yml:ro
    tempo-data:/tmp/tempo

mimir:
  image: grafana/mimir:2.13.0
  ports: "9009:9009"
  volumes: mimir-data:/data

ollama:
  image: ollama/ollama:0.3.10
  ports: "11434:11434"
  volumes: ollama-data:/root/.ollama
  healthcheck: curl -f http://localhost:11434/api/version

APP SERVICES (build from Dockerfile in each service directory):

rcm-core:
  build: ../rcm-core
  ports: "8090:8090"
  environment: (all from .env — database URLs, Kafka, Redis, Keycloak, Azure OpenAI, etc.)
  depends_on:
    postgres: service_healthy
    kafka: service_healthy
    redis: service_healthy
    mongo: service_healthy
    cosmos-emulator: service_healthy
    keycloak: service_healthy
  healthcheck: curl -f http://localhost:8090/actuator/health

rcm-rag:
  build: ../rcm-rag
  ports: "8091:8091" (HTTP), "50051:50051" (gRPC)
  environment: (from .env)
  depends_on: postgres: service_healthy, kafka: service_healthy,
    redis: service_healthy, mongo: service_healthy, ollama: service_healthy
  healthcheck: curl -f http://localhost:8091/health

rcm-notify:
  build: ../rcm-notify
  ports: "8092:8092"
  depends_on: kafka: service_healthy
  healthcheck: curl -f http://localhost:8092/health

rcm-bff:
  build: ../rcm-bff
  ports: "8093:8093"
  depends_on: rcm-core: service_healthy, rcm-rag: service_healthy,
    postgres: service_healthy, keycloak: service_healthy
  healthcheck: curl -f http://localhost:8093/health

rcm-ui:
  build: ../rcm-ui
  ports: "3000:3000"
  depends_on: rcm-bff: service_healthy, keycloak: service_healthy
  healthcheck: curl -f http://localhost:3000/api/health

.env.example — document ALL environment variables used across all services:
Sections: # PostgreSQL, # MongoDB, # Redis, # Kafka, # CosmosDB, # Keycloak,
# Azure OpenAI, # Ollama, # Grafana, # Application (feature flags, log level, etc.)
Each variable: NAME=example_value # Description of what this is used for

OUTPUT: 2 files.
// FILE: infrastructure/docker-compose.yml
[complete YAML]
// ===== END OF FILE =====

// FILE: infrastructure/.env.example
[complete env example with comments]
// ===== END OF FILE =====

The docker-compose.yml must be valid YAML. Use ${VARIABLE} syntax for all
env values that come from .env. Include comment blocks explaining service groups.
==========================================

# ============================================================
# PROMPT-026: Observability Configs — Prometheus + Loki + Tempo + Mimir
# ============================================================
# GOAL: All observability stack configuration files
# DEPENDS ON: PROMPT-025
# OUTPUT: infrastructure/observability/prometheus/prometheus.yml
#         infrastructure/observability/loki/loki-config.yml
#         infrastructure/observability/tempo/tempo-config.yml
#         infrastructure/observability/mimir/mimir-config.yml
#         infrastructure/observability/grafana/provisioning/datasources/datasources.yml
#         infrastructure/observability/grafana/provisioning/dashboards/dashboards.yml
# ACCEPTANCE CRITERIA:
#   1. Prometheus scrapes all 5 app services + infrastructure services
#   2. Loki configured for log retention matching HIPAA (7 years prod,
#      7 days dev — use dev settings)
#   3. Tempo configured to receive OTel traces on ports 4317 and 4318
#   4. Grafana datasources point to correct local addresses
#   5. All 5 dashboard JSON files referenced in dashboards.yml
# ============================================================

PROMPT-026 CONTEXT — paste this into DeepSeek:
==========================================
You are generating observability stack configuration files for a
production-grade RCM platform running locally via docker-compose.

prometheus.yml:
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  # App services
  - job_name: rcm-core
    static_configs: targets: ['rcm-core:8090']
    metrics_path: /actuator/prometheus

  - job_name: rcm-rag
    static_configs: targets: ['rcm-rag:8091']
    metrics_path: /metrics

  - job_name: rcm-notify
    static_configs: targets: ['rcm-notify:8092']
    metrics_path: /metrics

  - job_name: rcm-bff
    static_configs: targets: ['rcm-bff:8093']
    metrics_path: /metrics

  # Infrastructure
  - job_name: postgres
    static_configs: targets: ['postgres-exporter:9187']
    (note: postgres-exporter is a future addition — comment this out but document it)

  - job_name: redis
    static_configs: targets: ['redis:6379']
    (note: redis_exporter future addition — comment and document)

  - job_name: kafka
    static_configs: targets: ['kafka:9092']
    (kafka JMX metrics — comment and document)

  # Self-monitoring
  - job_name: prometheus
    static_configs: targets: ['localhost:9090']

  - job_name: grafana
    static_configs: targets: ['grafana:3000']

remote_write: (for Mimir long-term storage)
  - url: http://mimir:9009/api/v1/push

KEY METRICS to document in comments (these are what the dashboards use):
From rcm-core (Micrometer):
- http_server_requests_seconds (histogram) — RED metrics per endpoint
- jvm_memory_used_bytes, jvm_gc_pause_seconds
- resilience4j_circuitbreaker_state — circuit breaker status
- cache_gets_total{result="hit"|"miss"} — L1 cache hit rates
- kafka_producer_record_send_total — Kafka publish rates

From rcm-rag (prometheus-client):
- llm_tokens_used_total{tenant,model,prompt} — token usage
- llm_latency_seconds{endpoint} — LLM latency histogram
- rag_retrieval_latency_seconds — pgvector query time
- semantic_cache_hits_total, semantic_cache_misses_total
- agent_steps_total{node_name} — agent step counts
- llm_budget_remaining{tenant} — budget gauge
- eval_faithfulness_score{prompt_id} — eval metric gauges

From rcm-notify and rcm-bff (prom-client):
- notification_sent_total{channel,type} — notification counts
- graphql_request_duration_seconds — GraphQL latency
- sse_connections_active — active SSE connections

loki-config.yml:
auth_enabled: false
server: http_listen_port: 3100
common:
  path_prefix: /loki
  storage: filesystem: chunks_directory, rules_directory
  replication_factor: 1
  ring: instance_addr: 127.0.0.1, kvstore: store: inmemory
schema_config:
  configs: (current schema with boltdb-shipper or tsdb)
limits_config:
  retention_period: 168h (7 days for dev)
  ingestion_rate_mb: 10
  max_query_lookback: 168h

tempo-config.yml:
server: http_listen_port: 3200
distributor:
  receivers:
    otlp:
      protocols:
        grpc: endpoint: 0.0.0.0:4317
        http: endpoint: 0.0.0.0:4318
storage:
  trace:
    backend: local
    local: path: /tmp/tempo
    wal: path: /tmp/tempo/wal
compactor:
  compaction:
    block_retention: 48h (dev — 7 days prod)

mimir-config.yml:
(minimal single-process config for dev)
target: all
server: http_listen_port: 9009
blocks_storage:
  backend: filesystem
  filesystem: dir: /data/mimir/blocks
ruler_storage:
  backend: filesystem
  filesystem: dir: /data/mimir/rules
common:
  storage:
    backend: filesystem

datasources.yml (Grafana provisioning):
apiVersion: 1
datasources:
  - name: Prometheus, type: prometheus, url: http://prometheus:9090, isDefault: true
  - name: Loki, type: loki, url: http://loki:3100
  - name: Tempo, type: tempo, url: http://tempo:3200
    jsonData: tracesToLogsV2 enabled, linking to Loki
  - name: Mimir, type: prometheus, url: http://mimir:9009/prometheus

dashboards.yml (Grafana provisioning):
apiVersion: 1
providers:
  - name: RCM Dashboards
    folder: RCM Platform
    type: file
    options: path: /var/lib/grafana/dashboards
    updateIntervalSeconds: 30
    allowUiUpdates: false

OUTPUT: 6 config files.
// FILE: path // ===== END OF FILE =====
All configs must be valid YAML. Include comments explaining key settings
and especially why certain limits are set the way they are.
==========================================

# ============================================================
# PROMPT-027: Grafana Dashboards — All 5 JSON Dashboard Files
# ============================================================
# GOAL: Pre-built Grafana dashboard JSON files
# DEPENDS ON: PROMPT-026
# OUTPUT: infrastructure/observability/grafana/dashboards/service-overview.json
#         infrastructure/observability/grafana/dashboards/llm-cost.json
#         infrastructure/observability/grafana/dashboards/rag-quality.json
#         infrastructure/observability/grafana/dashboards/claim-throughput.json
#         infrastructure/observability/grafana/dashboards/agent-execution.json
# ACCEPTANCE CRITERIA:
#   1. Each file is valid Grafana dashboard JSON (version 1)
#   2. Panels use the metric names from PROMPT-026
#   3. llm-cost dashboard has: tokens used per tenant (bar chart),
#      cost estimate (table), budget remaining (gauge)
#   4. rag-quality dashboard has: faithfulness, recall@5, carc_accuracy gauges
#   5. All dashboards have time range variable and refresh interval
# ============================================================

PROMPT-027 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Grafana dashboard JSON files for a production-grade
RCM platform. Each dashboard must be valid Grafana JSON importable directly.

GRAFANA VERSION: 11.2.0
DATASOURCE: "Prometheus" (use ${datasource} variable)

DASHBOARD 1: service-overview.json
Title: "RCM Platform — Service Overview"
Variables: datasource (Prometheus), refresh: 30s

Panels (use RED metrics: Rate, Errors, Duration):
Row 1 "Request Rate":
  - Stat panels: HTTP requests/sec for each of 5 services
  - Query: rate(http_server_requests_seconds_count{job="rcm-core"}[5m])

Row 2 "Error Rate":
  - Stat panels with threshold coloring (green <1%, yellow <5%, red >5%)
  - Query: rate(http_server_requests_seconds_count{status=~"5.."}[5m])
    / rate(http_server_requests_seconds_count[5m])

Row 3 "Latency (p95)":
  - Time series panels for each service
  - Query: histogram_quantile(0.95, rate(http_server_requests_seconds_bucket[5m]))

Row 4 "Infrastructure":
  - Circuit breaker state: resilience4j_circuitbreaker_state
  - Kafka lag: kafka_consumer_group_lag (if available)
  - Redis connected clients

DASHBOARD 2: llm-cost.json
Title: "RCM Platform — LLM Cost Monitor"

Panels:
- Tokens Used Today (by tenant): bar chart
  Query: sum by (tenant) (increase(llm_tokens_used_total[1d]))
- Estimated Cost Today: table (tokens * $0.000002 for gpt-4o-mini estimate)
- Budget Remaining by Tenant: gauge panel per tenant
  Query: llm_budget_remaining
- Token Usage Over Time: time series, stacked by model
- LLM Latency p50/p95/p99: time series
  Query: histogram_quantile(0.5, rate(llm_latency_seconds_bucket[5m]))
- Cache Hit Rate: stat panel
  Query: semantic_cache_hits_total / (semantic_cache_hits_total + semantic_cache_misses_total)
- Rate Limit Events: stat panel (how often we hit provider limits)
  Query: increase(llm_rate_limit_rejected_total[1h])

DASHBOARD 3: rag-quality.json
Title: "RCM Platform — RAG Quality Metrics"

Panels:
- Faithfulness Score: gauge (threshold: green >0.85, yellow >0.70, red <0.70)
  Query: eval_faithfulness_score (latest value per prompt_id)
- Recall@5: gauge (threshold: green >0.80)
- CARC Accuracy: gauge (threshold: green >0.80, yellow >0.65)
- Retrieval Latency p95: stat panel
  Query: histogram_quantile(0.95, rate(rag_retrieval_latency_seconds_bucket[5m]))
- FAISS vs pgvector retrieval split: pie chart
  Query: rag_retrieval_source_total (if metric exists) or stat showing FAISS usage %
- Eval Score History: time series showing faithfulness trend over last 30 days
- Top Failing Prompts: table showing prompt_id + lowest metric score

DASHBOARD 4: claim-throughput.json
Title: "RCM Platform — Claim Throughput"

Panels (data from Postgres materialized views via Prometheus where possible,
or annotate that these read from rcm-core business metrics):
- Claims Created Today: stat
- Claims Submitted Today: stat
- Scrub Pass Rate: gauge (green >95%)
- Denial Rate: gauge (red >15%, yellow >10%)
- Claim Status Distribution: pie chart (by status)
- Claims by Payer: bar chart
- Throughput Over Time: time series (claims created vs submitted vs paid per day)
- Average Time to Payment (days): stat

DASHBOARD 5: agent-execution.json
Title: "RCM Platform — Denial Resolution Agent"

Panels:
- Active Agent Runs: stat (agent_states where completed_at IS NULL)
- Denials Awaiting Human Review: stat
- Average Agent Steps per Resolution: gauge
  Query: rate(agent_steps_total[1h]) / rate(agent_completions_total[1h])
- Node Execution Breakdown: bar chart (agent_steps_total by node_name)
- Human Review Wait Time: histogram (time from interrupted_at to resumed_at)
- Agent Success Rate: gauge (completed vs failed)
- Appeal Acceptance Rate: stat (from rcm-core business metrics)
- Usefulness Score Distribution: bar chart (scores 1-5)

OUTPUT: 5 JSON files.
// FILE: infrastructure/observability/grafana/dashboards/service-overview.json
[complete valid Grafana dashboard JSON]
// ===== END OF FILE =====
[repeat for each dashboard]

Generate complete valid JSON that can be imported into Grafana 11.2.0 directly.
Include at minimum 5 panels per dashboard. Use realistic panel types
(stat, gauge, timeseries, barchart, table, piechart).
==========================================

# ============================================================
# PROMPT-028: Terraform Stubs — AWS Deployment Infrastructure
# ============================================================
# GOAL: Terraform module stubs documenting the prod AWS target
# DEPENDS ON: PROMPT-025
# OUTPUT: All files under infrastructure/terraform/
# ACCEPTANCE CRITERIA:
#   1. Valid Terraform HCL 1.9 syntax
#   2. Each module has clear variable declarations with descriptions
#   3. ECS task definitions reference the correct Docker images
#   4. RDS instance has pgvector extension enabled via parameter group
#   5. All sensitive values use variables (never hardcoded)
#   6. README comment at top of each file explaining it's a stub (not applied)
# ============================================================

PROMPT-028 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Terraform stub files documenting the AWS production
deployment target for an RCM platform. These files are NOT applied —
they document the intended production architecture for review.

Add this comment to every .tf file:
# STUB: This file is not applied in the current deployment.
# It documents the intended production infrastructure on AWS.
# Review and modify before applying to any environment.
# Last reviewed: 2025-01-15

TARGET ARCHITECTURE:
- AWS Region: us-east-1 (with us-west-2 for DR)
- VPC: 3 AZs, /16 CIDR
- Public subnets: ALB only
- Private subnets: ECS Fargate, RDS, ElastiCache, MSK
- CosmosDB: Azure (cross-cloud, accessed via internet with private endpoint)

main.tf (root):
- terraform block: required_version = "~> 1.9", required_providers (aws, azurerm)
- provider "aws": region = var.aws_region
- provider "azurerm": (for CosmosDB)
- module blocks calling each sub-module:
  module "networking", module "ecs", module "rds", module "elasticache",
  module "msk", module "cosmosdb"
- locals block: common tags (project, environment, team)

variables.tf (root):
- aws_region, environment, project_name
- vpc_cidr, availability_zones
- postgres_instance_class, postgres_db_name, postgres_username
- redis_node_type, redis_num_cache_nodes
- kafka_broker_count, kafka_broker_instance_type
- ecs_task_cpu, ecs_task_memory (per service)
- image_tag (Docker image tag for all services)
- cosmos_account_name, cosmos_location

outputs.tf (root):
- alb_dns_name, ecs_cluster_arn, rds_endpoint
- redis_endpoint, kafka_bootstrap_servers
- cosmos_endpoint

modules/networking/main.tf:
- aws_vpc: cidr_block, enable_dns_hostnames=true
- aws_subnet: 3 public (ALB), 3 private app (ECS), 3 private data (RDS/Cache/Kafka)
- aws_internet_gateway, aws_nat_gateway (one per AZ for HA)
- aws_route_table + associations
- aws_security_group: alb-sg, app-sg, data-sg
  alb-sg: ingress 443 from 0.0.0.0/0, egress to app-sg
  app-sg: ingress 8090-8093 from alb-sg, gRPC 50051 between app services
  data-sg: ingress 5432 (postgres), 6379 (redis), 9092 (kafka) from app-sg only

modules/ecs/main.tf:
- aws_ecs_cluster: name = rcm-platform-${var.environment}
- aws_ecs_task_definition for each of 5 services:
  rcm-core: cpu=1024, memory=2048, image=${ECR_URL}/rcm-core:${var.image_tag}
  rcm-rag: cpu=2048, memory=4096 (more memory for FAISS index)
  rcm-notify: cpu=512, memory=1024
  rcm-bff: cpu=1024, memory=2048
  rcm-ui: cpu=512, memory=1024
- aws_ecs_service for each: desired_count=2, launch_type=FARGATE
- aws_lb (ALB): internet-facing, security_group=alb-sg
- aws_lb_listener: HTTPS 443, certificate from ACM
- aws_lb_target_group for each service
- aws_lb_listener_rule: path-based routing
  /api/* → rcm-core, /rag/* → rcm-rag, /graphql → rcm-bff, /* → rcm-ui
- aws_appautoscaling_target + policy for each service (scale on CPU 70%)

modules/rds/main.tf:
- aws_db_parameter_group: postgres16 family
  parameters: shared_preload_libraries = 'pg_cron,pg_stat_statements,vector'
  (pgvector extension enabled via parameter group)
- aws_db_subnet_group: private data subnets
- aws_db_instance:
  engine=postgres, engine_version=16.4
  instance_class=var.postgres_instance_class (default: db.t3.large)
  multi_az=true, storage_encrypted=true
  backup_retention_period=7, deletion_protection=true
  parameter_group_name = aws_db_parameter_group above
- aws_secretsmanager_secret: postgres credentials
- aws_secretsmanager_secret_version: random password

modules/elasticache/main.tf:
- aws_elasticache_subnet_group: private data subnets
- aws_elasticache_replication_group:
  description = Redis for RCM platform
  node_type = var.redis_node_type (default: cache.t3.micro)
  num_cache_clusters = var.redis_num_cache_nodes (default: 2)
  automatic_failover_enabled = true
  at_rest_encryption_enabled = true
  transit_encryption_enabled = true

modules/msk/main.tf:
- aws_msk_cluster:
  kafka_version = 3.7.0
  number_of_broker_nodes = var.kafka_broker_count (default: 3)
  broker_node_group_info: instance_type=kafka.m5.large
  encryption_info: encryption_in_transit (TLS), at_rest (KMS key)
  client_authentication: sasl/scram
- aws_msk_configuration: auto.create.topics.enable=false

modules/cosmosdb/main.tf:
- azurerm_resource_group: rcm-cosmosdb
- azurerm_cosmosdb_account:
  offer_type = Standard
  kind = GlobalDocumentDB (NoSQL API)
  consistency_policy: session consistency
  geo_location: primary + failover
  is_virtual_network_filter_enabled = true
- azurerm_cosmosdb_sql_database: rcm-events
- azurerm_cosmosdb_sql_container: claim-events
  partition_key_path = /claimId
  default_ttl = 63072000 (2 years in seconds)
  indexing_policy: include eventType, tenantId, timestamp

environments/dev.tfvars:
postgres_instance_class = "db.t3.micro"
redis_node_type = "cache.t3.micro"
kafka_broker_count = 1
ecs_task_cpu = 256 (smaller for dev)

environments/prod.tfvars:
postgres_instance_class = "db.r6g.large"
redis_node_type = "cache.r6g.large"
kafka_broker_count = 3
ecs_task_cpu = 1024

OUTPUT: All terraform files.
// FILE: infrastructure/terraform/main.tf
// FILE: infrastructure/terraform/variables.tf
// FILE: infrastructure/terraform/outputs.tf
// FILE: infrastructure/terraform/modules/networking/main.tf
// FILE: infrastructure/terraform/modules/networking/variables.tf
// FILE: infrastructure/terraform/modules/ecs/main.tf
// FILE: infrastructure/terraform/modules/ecs/variables.tf
// FILE: infrastructure/terraform/modules/rds/main.tf
// FILE: infrastructure/terraform/modules/rds/variables.tf
// FILE: infrastructure/terraform/modules/elasticache/main.tf
// FILE: infrastructure/terraform/modules/elasticache/variables.tf
// FILE: infrastructure/terraform/modules/msk/main.tf
// FILE: infrastructure/terraform/modules/msk/variables.tf
// FILE: infrastructure/terraform/modules/cosmosdb/main.tf
// FILE: infrastructure/terraform/modules/cosmosdb/variables.tf
// FILE: infrastructure/terraform/environments/dev.tfvars
// FILE: infrastructure/terraform/environments/prod.tfvars
Each ends with // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-029: GitHub Actions CI Workflows — All 6 Workflow Files
# ============================================================
# GOAL: Complete CI/CD pipeline configuration for all 5 services + contracts
# DEPENDS ON: PROMPT-025
# OUTPUT: All .github/workflows/*.yml files
# ACCEPTANCE CRITERIA:
#   1. Each workflow triggers on push to main and PRs touching that service's directory
#   2. All workflows push to GHCR on success
#   3. rcm-rag-ci.yml includes eval harness gate
#   4. contract-tests.yml runs Pact verification
#   5. No secrets hardcoded — all use GitHub Secrets
# ============================================================

PROMPT-029 CONTEXT — paste this into DeepSeek:
==========================================
You are generating GitHub Actions CI workflow files for a production-grade
RCM platform monorepo.

REGISTRY: ghcr.io (GitHub Container Registry)
IMAGE PREFIX: ghcr.io/${{ github.repository_owner }}/rcm-

WORKFLOW 1: rcm-core-ci.yml
Trigger: push/PR touching rcm-core/** or proto/**
Jobs:
  test:
    runs-on: ubuntu-latest
    services: postgres:16-alpine (with pgvector), redis:7-alpine, mongo:7
    steps:
      - checkout
      - setup Java 21 (temurin)
      - cache Gradle
      - generate protobuf: ./gradlew generateProto
      - run tests: ./gradlew :app:test :common:test :claims:test ... (all modules)
      - run integration tests: ./gradlew integrationTest (Testcontainers)
      - generate Pact: ./gradlew pactPublish (consumer pacts)
      - upload test results + Jacoco coverage
      - fail if coverage < 70%

  build:
    needs: test
    steps:
      - build JAR: ./gradlew :app:bootJar
      - build Docker image: docker build
      - push to GHCR: ghcr.io/.../rcm-core:${{ github.sha }}
      - also tag as latest on main branch

WORKFLOW 2: rcm-rag-ci.yml
Trigger: push/PR touching rcm-rag/** or proto/**
Jobs:
  lint:
    steps: ruff check rcm-rag/, mypy rcm-rag/

  test:
    runs-on: ubuntu-latest
    services: postgres:16 (with pgvector extension setup), redis:7, mongo:7, kafka
    steps:
      - checkout
      - setup Python 3.12
      - cache pip
      - generate protobuf: python -m grpc_tools.protoc ...
      - install deps: pip install -e ".[dev]"
      - run unit tests: pytest rcm-rag/tests/unit/ -v
      - run integration tests: pytest rcm-rag/tests/integration/ -v
      - run eval harness: python rcm-rag/evals/runner.py --ci-mode
        (fails if any metric below threshold in thresholds.yaml)
      - verify Pact: pytest rcm-rag/tests/pact/

  build:
    needs: [lint, test]
    steps: docker build, push to GHCR

WORKFLOW 3: rcm-notify-ci.yml
Trigger: push/PR touching rcm-notify/**
Jobs:
  test:
    steps:
      - setup Node.js 20
      - npm ci
      - npm run lint
      - npm test (vitest)
      - integration tests (Testcontainers Kafka)

  build: docker build + push GHCR

WORKFLOW 4: rcm-bff-ci.yml
Trigger: push/PR touching rcm-bff/**
Jobs:
  test:
    steps:
      - setup Node.js 20
      - npm ci
      - npm run lint
      - npm test
      - generate Pact (consumer test against rcm-core)
      - integration tests

  build: docker build + push GHCR

WORKFLOW 5: rcm-ui-ci.yml
Trigger: push/PR touching rcm-ui/**
Jobs:
  test:
    steps:
      - setup Node.js 20
      - npm ci
      - npm run lint
      - npm test (vitest + @testing-library)
      - npm run build (Next.js production build)
      - Playwright E2E (against local docker-compose)

  build: docker build + push GHCR

WORKFLOW 6: contract-tests.yml
Trigger: after any service CI passes (workflow_run trigger)
         also: manual trigger (workflow_dispatch)
Jobs:
  verify-contracts:
    steps:
      - checkout
      - setup Java 21 + Python 3.12 + Node.js 20
      - run rcm-core Pact provider verification
        (verifies pacts generated by rcm-bff consumer tests)
      - run rcm-rag Pact provider verification
      - report: all contracts verified or specific failures listed
      - fail PR if any contract fails

SHARED ELEMENTS across all workflows:
- permissions: contents: read, packages: write
- concurrency: cancel-in-progress for PR runs
- GITHUB_TOKEN for GHCR login
- Secrets referenced: AZURE_OPENAI_KEY (for eval harness in rcm-rag),
  KEYCLOAK_CLIENT_SECRET, etc.
- Artifacts: upload test results, coverage reports
- Step summaries: GitHub Actions job summary with test counts and coverage

OUTPUT: 6 files.
// FILE: .github/workflows/rcm-core-ci.yml
[complete YAML]
// ===== END OF FILE =====
[repeat for each]

All workflow YAML must be valid GitHub Actions syntax.
Include comments explaining non-obvious steps.
==========================================

# ============================================================
# PROMPT-030: Makefile + Root Config Files
# ============================================================
# GOAL: Makefile + all root config files (.gitignore, .editorconfig, etc.)
# DEPENDS ON: PROMPT-025
# OUTPUT: Makefile
#         .gitignore
#         .gitattributes
#         .editorconfig
#         .pre-commit-config.yaml
#         commitlint.config.js
#         buf.yaml (protobuf linting)
# ACCEPTANCE CRITERIA:
#   1. Makefile targets work on Windows (pwsh), macOS, and Linux
#   2. .gitignore covers all 5 language ecosystems (Java, Python, Node, Next.js, Terraform)
#   3. pre-commit hooks include gitleaks, ruff, spotless, eslint, commitlint
#   4. buf.yaml enforces google proto style + breaking change detection
#   5. All Makefile targets have help text
# ============================================================

PROMPT-030 CONTEXT — paste this into DeepSeek:
==========================================
You are generating root configuration files for a polyglot monorepo
containing Java, Python, Node.js, Next.js, and Terraform code.

Makefile:
Use .PHONY for all non-file targets.
Include a help target (default) that lists all targets with descriptions.
Format: ## Description comment before each target parsed by help target.

Targets to implement:
## Start all services locally
up: docker compose -f infrastructure/docker-compose.yml up --build -d

## Stop all services
down: docker compose -f infrastructure/docker-compose.yml down

## View logs for all services
logs: docker compose -f infrastructure/docker-compose.yml logs -f

## Run all tests (Java + Python + Node)
test: test-java test-python test-node

## Run Java tests
test-java: (cd rcm-core && ./gradlew test integrationTest)

## Run Python tests
test-python: (cd rcm-rag && pytest tests/ -v --cov)

## Run Node tests (notify + bff + ui)
test-node: (cd rcm-notify && npm test) && (cd rcm-bff && npm test) && (cd rcm-ui && npm test)

## Run contract tests (Pact)
test-contracts: (run pact consumer + provider tests for all service pairs)

## Run RAG eval harness
eval: (cd rcm-rag && python evals/runner.py)

## Run Flyway migrations
migrate: (./gradlew :app:flywayMigrate)

## Ingest RAG corpus seed data
ingest: (cd rcm-rag && python scripts/ingest_corpus.py)

## Build all Docker images
build: docker compose -f infrastructure/docker-compose.yml build

## Format all code
fmt: fmt-java fmt-python fmt-node

## Lint all code
lint: lint-java lint-python lint-node

## Generate protobuf code for all services
proto-gen: (buf generate from proto/ directory)

## Check protobuf for breaking changes
proto-breaking: (buf breaking --against ...)

## Install pre-commit hooks
hooks: pre-commit install

## Show service health
health: (curl each service health endpoint and display status)

## Scaffold (run once after clone)
scaffold: pwsh scaffold.ps1 (Windows) or bash scaffold.sh (Unix)

.gitignore:
Sections with comments:
# Java / Gradle
.gradle/, build/, *.class, *.jar (not gradlew.jar), .idea/, *.iml, out/

# Python
__pycache__/, *.pyc, *.pyo, .venv/, venv/, dist/, *.egg-info/,
.mypy_cache/, .ruff_cache/, .pytest_cache/, htmlcov/, .coverage

# Node.js
node_modules/, dist/ (in Node projects), .next/, .nuxt/,
npm-debug.log, yarn-error.log, .env.local

# Environment and secrets
.env, .env.local, .env.*.local, *.pem, *.key, *.p12, secrets/

# Docker
.dockerignore (don't ignore this), docker-compose.override.yml

# Terraform
.terraform/, *.tfstate, *.tfstate.backup, .terraform.lock.hcl,
terraform.tfvars (but NOT *.tfvars.example)

# IDE
.vscode/, .idea/, *.swp, *.swo, .DS_Store, Thumbs.db

# Generated
proto/**/*_pb2.py, proto/**/*_pb2_grpc.py, proto/**/*.java (generated)
rcm-rag/evals/reports/, CHANGELOG.md (generated by git-cliff)

.gitattributes:
* text=auto eol=lf
*.java text eol=lf
*.py text eol=lf
*.ts text eol=lf
*.tsx text eol=lf
*.json text eol=lf
*.yml text eol=lf
*.yaml text eol=lf
*.sql text eol=lf
*.md text eol=lf
*.sh text eol=lf
*.ps1 text eol=crlf (PowerShell on Windows)
*.jar binary
*.class binary
gradlew text eol=lf

.editorconfig:
root = true
[*]: indent_style=space, indent_size=2, charset=utf-8, trim_trailing_whitespace=true,
     insert_final_newline=true, end_of_line=lf
[*.java]: indent_size=4
[*.py]: indent_size=4
[Makefile]: indent_style=tab
[*.md]: trim_trailing_whitespace=false
[*.ps1]: end_of_line=crlf

.pre-commit-config.yaml:
repos:
  - repo: https://github.com/gitleaks/gitleaks, rev: v8.18.4
    hooks: [gitleaks] (detect secrets before commit)

  - repo: https://github.com/astral-sh/ruff-pre-commit, rev: v0.6.5
    hooks: [ruff (lint), ruff-format] (Python lint + format)

  - repo: local
    hooks:
      - id: spotless-java
        name: Spotless Java format check
        language: system
        entry: bash -c 'cd rcm-core && ./gradlew spotlessCheck'
        pass_filenames: false
        types: [java]

      - id: eslint-notify
        name: ESLint rcm-notify
        language: system
        entry: bash -c 'cd rcm-notify && npm run lint'
        pass_filenames: false
        types: [ts]

      - id: eslint-bff
        name: ESLint rcm-bff
        language: system
        entry: bash -c 'cd rcm-bff && npm run lint'
        pass_filenames: false

  - repo: https://github.com/alessandrojcm/commitlint-pre-commit-hook
    rev: v9.18.0
    hooks: [commitlint] (enforce conventional commits)

  - repo: https://github.com/bufbuild/buf, rev: v1.39.0
    hooks:
      - id: buf-lint (proto style)
      - id: buf-breaking (breaking change detection)

commitlint.config.js:
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'scope-enum': [2, 'always', [
      'rcm-core', 'rcm-rag', 'rcm-notify', 'rcm-bff', 'rcm-ui',
      'proto', 'infra', 'docs', 'deps', 'ci', 'eval'
    ]],
    'subject-max-length': [2, 'always', 100],
  }
}

buf.yaml:
version: v2
modules:
  - path: proto
lint:
  use: [STANDARD, COMMENTS]
  except: [PACKAGE_VERSION_SUFFIX]
breaking:
  use: [PACKAGE]
  ignore_unstable_packages: true

OUTPUT: 7 files.
// FILE: Makefile
// FILE: .gitignore
// FILE: .gitattributes
// FILE: .editorconfig
// FILE: .pre-commit-config.yaml
// FILE: commitlint.config.js
// FILE: buf.yaml
Each ends with // ===== END OF FILE =====

Makefile must use tab indentation for recipe lines.
All files must be complete and production-quality.
==========================================
