# BATCH C1 — Prompts 031–038
# rcm-core Spring Boot: scaffold + common module + first 4 bounded contexts
# GUIDED LATITUDE: DeepSeek implements against contracts, chooses implementation details.
# Every non-trivial line must have an inline comment explaining intent.
# ============================================================

# ============================================================
# PROMPT-031: rcm-core Gradle Build Files + Application Entry Point
# ============================================================
# GOAL: All Gradle build files + Spring Boot application class + all yml configs
# DEPENDS ON: PROMPT-003 PROMPT-017 PROMPT-019-021
# OUTPUT: rcm-core/build.gradle (root)
#         rcm-core/settings.gradle
#         rcm-core/common/build.gradle
#         rcm-core/registration/build.gradle
#         rcm-core/eligibility/build.gradle
#         rcm-core/charge-capture/build.gradle
#         rcm-core/claims/build.gradle
#         rcm-core/payments/build.gradle
#         rcm-core/denials/build.gradle
#         rcm-core/ar/build.gradle
#         rcm-core/app/build.gradle
#         rcm-core/app/src/main/java/com/rcm/RcmCoreApplication.java
#         rcm-core/app/src/main/resources/application.yml
#         rcm-core/app/src/main/resources/application-dev.yml
#         rcm-core/app/src/main/resources/application-test.yml
#         rcm-core/app/src/main/resources/application-prod.yml
# ACCEPTANCE CRITERIA:
#   1. All dependency versions match 03_PINNED_TECH_STACK.md EXACTLY
#   2. Root build.gradle defines all dependencies in one place via
#      subprojects block — no version repetition in subproject build files
#   3. application.yml has NO secrets — all sensitive values use
#      ${ENV_VAR:default} syntax
#   4. application-test.yml configures Testcontainers and disables
#      Kafka/Redis/Mongo/Cosmos for unit tests
#   5. RcmCoreApplication uses virtual threads (Java 21)
#      Tomcat configured with virtual thread executor
# ============================================================

PROMPT-031 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Gradle build configuration and Spring Boot application
bootstrap files for rcm-core, the Java 21 Spring Boot service in a
production-grade RCM platform.

ARCHITECTURE CONTEXT:
rcm-core is a modular monolith with 8 Gradle subprojects:
common, registration, eligibility, charge-capture, claims, payments, denials, ar, app.
The app module is the Spring Boot application entry point that includes all other modules.

PINNED VERSIONS (use exactly these — no deviations):
Java: 21
Spring Boot: 3.3.5
Spring AI: 1.0.0-M3
MapStruct: 1.6.2
Resilience4j: 2.2.0
Caffeine: 3.1.8
grpc-java: 1.65.1
protobuf-java: 4.27.3
net.devh grpc-spring-boot-starter: 3.1.0
JJWT: 0.12.6
opentelemetry-spring-boot-starter: 2.6.0
logstash-logback-encoder: 8.0
Pact JVM: 4.6.14
Testcontainers: 1.20.1
Spotless: 6.25.0
Checkstyle: 10.17.0
Azure SDK Cosmos: 4.62.0
MongoDB driver: 5.1.4
Gradle: 8.9

ROOT build.gradle must include:
- plugins block: spring-boot, dependency-management, spotless, checkstyle,
  protobuf plugin, jacoco
- allprojects block: group='com.rcm', version='0.1.0-SNAPSHOT'
- subprojects block: apply java, apply jacoco
  repositories: mavenCentral(), spring milestones (for Spring AI)
  ALL dependency versions declared here using constants
  (e.g., def resilience4jVersion = '2.2.0')
- dependencies section showing which deps belong to which module
  (not all deps in every module — each module only gets what it needs)
- spotless config: googleJavaFormat
- checkstyle config: version 10.17.0
- protobuf config: generate Java stubs from proto/rcm/v1/claim_scrubbing.proto

settings.gradle:
rootProject.name = 'rcm-core'
include 'common', 'registration', 'eligibility', 'charge-capture',
        'claims', 'payments', 'denials', 'ar', 'app'

Each subproject build.gradle (minimal — version-free, inherits from root):
common/build.gradle:
  dependencies:
    implementation: spring-boot-starter-web, spring-boot-starter-data-jpa,
    spring-boot-starter-security, spring-boot-starter-data-redis,
    spring-boot-starter-kafka, spring-boot-starter-actuator,
    spring-boot-starter-aop, spring-boot-starter-validation,
    flyway-core, flyway-database-postgresql,
    caffeine, jjwt-api, jjwt-impl, jjwt-jackson,
    opentelemetry-spring-boot-starter,
    logstash-logback-encoder,
    mongodb-driver-sync, azure-cosmos,
    micrometer-registry-prometheus,
    lombok (optional, for @Slf4j)
  testImplementation: spring-boot-starter-test, testcontainers (bom)

claims/build.gradle:
  dependencies:
    implementation: project(':common'), grpc-stub, grpc-netty-shaded,
    protobuf-java, net.devh:grpc-spring-boot-starter,
    spring-ai-openai-spring-boot-starter, resilience4j-spring-boot3,
    resilience4j-circuitbreaker, resilience4j-retry, resilience4j-timelimiter
  testImplementation: pact-jvm-consumer

Other subprojects: implementation project(':common') + minimal extras

app/build.gradle:
  apply plugin: 'org.springframework.boot'
  mainClassName = 'com.rcm.RcmCoreApplication'
  dependencies:
    implementation: all subprojects (project(':common'), project(':registration'), etc.)
    runtimeOnly: postgresql driver
  bootJar: enabled = true
  jar: enabled = false

RcmCoreApplication.java:
package com.rcm;

// Java 21 virtual threads configuration for Tomcat
// Virtual threads allow handling thousands of concurrent requests
// without thread pool exhaustion — critical for I/O-heavy RCM workloads
@SpringBootApplication
@EnableScheduling  // for Caffeine cache refresh
@EnableAsync       // for async operations (claim summarization)
public class RcmCoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(RcmCoreApplication.class, args);
    }

    // Configure Tomcat to use virtual threads (Java 21 feature)
    // Eliminates thread pool bottleneck for I/O-bound HTTP handling
    @Bean
    public TomcatProtocolHandlerCustomizer<?> protocolHandlerVirtualThreadExecutorCustomizer() {
        return protocolHandler -> {
            protocolHandler.setExecutor(Executors.newVirtualThreadPerTaskExecutor());
        };
    }
}

application.yml (comprehensive — all configuration):
Sections:
spring:
  application.name: rcm-core
  datasource: url, username, password from env vars
  jpa:
    hibernate.ddl-auto: validate (Flyway manages schema)
    properties.hibernate:
      dialect: PostgreSQLDialect
      format_sql: false (true in dev)
      filter.registration: TenantFilter (reference to Hibernate filter)
  flyway: enabled=true, locations=classpath:db/migration, baseline-on-migrate=true
  kafka:
    bootstrap-servers: from env
    producer: key/value serializer, acks=all, retries=3
    consumer: group-id, auto-offset-reset=earliest, enable-auto-commit=false
  data.redis:
    host, port, password from env
    lettuce.pool: max-active=10, max-idle=5
  ai:
    openai: api-key from env, base-url (Azure OpenAI endpoint)
    chat.options: model=gpt-4o-mini, temperature=0.1

server:
  port: 8090
  shutdown: graceful

management:
  endpoints.web.exposure.include: health,info,prometheus,metrics
  metrics.tags: application=${spring.application.name}
  tracing.sampling.probability: 1.0 (dev) / 0.1 (prod)

resilience4j:
  circuitbreaker.instances:
    ragScrubbing:
      failure-rate-threshold: 50
      slow-call-duration-threshold: 3s
      permitted-number-of-calls-in-half-open-state: 5
      sliding-window-size: 10
  timelimiter.instances:
    ragScrubbing: timeout-duration: 3s
  retry.instances:
    ragScrubbing: max-attempts: 2, wait-duration: 100ms, exponential-backoff-multiplier: 2

rcm:
  security:
    keycloak-jwks-uri: from env
    internal-signing-key: from env (for X-Internal-Context header)
  features:
    cache-ttl-eligibility: 86400  # 24h in seconds
    cache-ttl-llm-response: 604800  # 7d in seconds
  cosmos:
    endpoint: from env
    key: from env
    database-name: rcm-events
    container-name: claim-events

application-dev.yml:
Overrides for local development:
- spring.jpa.properties.hibernate.format_sql: true
- logging.level.com.rcm: DEBUG
- logging.level.org.hibernate.SQL: DEBUG
- management.tracing.sampling.probability: 1.0
- rcm.cosmos.endpoint: https://localhost:8081 (emulator)

application-test.yml:
Overrides for unit tests:
- spring.autoconfigure.exclude:
    KafkaAutoConfiguration, RedisAutoConfiguration,
    MongoAutoConfiguration, CosmosAutoConfiguration
- spring.datasource.url: (Testcontainers will override this)
- spring.flyway.enabled: false (Testcontainers integration tests handle this)
- spring.ai.openai.enabled: false

application-prod.yml:
- server.tomcat.threads: (not needed — virtual threads)
- logging.level.root: WARN
- management.tracing.sampling.probability: 0.05
- spring.jpa.properties.hibernate.format_sql: false

OUTPUT: 16 files.
// FILE: rcm-core/build.gradle
// FILE: rcm-core/settings.gradle
// FILE: rcm-core/common/build.gradle
[continue for each subproject]
// FILE: rcm-core/app/src/main/java/com/rcm/RcmCoreApplication.java
// FILE: rcm-core/app/src/main/resources/application.yml
[continue for each yml]
Each ends with // ===== END OF FILE =====

COMMENTING STANDARD (applies to ALL Java files in ALL prompts):
Every non-trivial line or block must have an inline comment explaining:
1. WHAT it does (if not obvious from naming)
2. WHY it's done this way (the architectural reason)
3. Any trade-offs or alternatives rejected

Example of expected comment density:
// Configure Kafka producer to wait for all ISR replicas to acknowledge writes
// (acks=all). This prevents data loss at the cost of slightly higher latency.
// Alternative: acks=1 (only leader) is faster but risks losing messages if
// the leader fails before replication completes.
producer.setAcks("all");
==========================================

# ============================================================
# PROMPT-032: rcm-core common — Configuration Classes
# ============================================================
# GOAL: All 7 Spring configuration classes in the common module
# DEPENDS ON: PROMPT-031
# OUTPUT: 7 Java config files in rcm-core/common/src/main/java/com/rcm/common/config/
# ACCEPTANCE CRITERIA:
#   1. SecurityConfig sets up JWT filter chain with stateless sessions
#   2. KafkaConfig defines separate producer and consumer factories
#      for each topic with typed serializers
#   3. GrpcClientConfig wires Resilience4j around the gRPC channel
#   4. RedisConfig sets up Lettuce connection factory with connection pooling
#   5. SpringAiConfig configures Azure OpenAI with retry and timeout
#   6. ObservabilityConfig registers custom Micrometer meters for
#      RCM-specific business metrics
# ============================================================

PROMPT-032 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Spring configuration classes for the common module
of rcm-core. These classes wire together all the cross-cutting infrastructure.

PACKAGE: com.rcm.common.config

COMMENT STANDARD: Every non-trivial line has an inline comment explaining
WHAT it does and WHY. See PROMPT-031 for the expected comment density.

SecurityConfig.java:
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
Configure:
- SecurityFilterChain: stateless sessions (SESSIONCREATIONPOLICY.STATELESS),
  JWT filter before UsernamePasswordAuthenticationFilter,
  permit /actuator/health and /actuator/info without auth,
  require auth for all other endpoints
- JwtAuthFilter bean (defined in security package — just reference it here)
- CORS configuration: allow configured origins from env var
  Comment: "CORS restricted to configured origins — never use * in production
  as it would allow any website to make authenticated requests to our API"
- CSRF disabled: explain WHY in comment
  "CSRF disabled because we use stateless JWT auth, not session cookies.
   CSRF attacks require the browser to send session credentials automatically,
   which doesn't apply to Bearer token authentication."

JwtConfig.java:
@Configuration
Configure:
- JwtDecoder bean: NimbusJwtDecoder with JWK Set URI from Keycloak
  Comment: "RS256 asymmetric verification — we only need the public key.
  Keycloak publishes JWKS at /protocol/openid-connect/certs.
  We validate locally without a network call on every request (key is cached)."
- JwtAuthenticationConverter: extract roles from 'realm_access.roles' claim
  AND tenant_id from custom claim
  Comment: "Keycloak stores roles in realm_access.roles, not the standard
  Spring Security location. This converter maps them to GrantedAuthority objects."

RedisConfig.java:
@Configuration
Configure:
- LettuceConnectionFactory: pool with max-active=10, max-idle=5, min-idle=2
  Comment: "Connection pooling is critical for Redis performance.
  Without pooling, each Redis operation opens a new TCP connection (expensive).
  Lettuce uses Netty under the hood and supports pool configuration."
- RedisTemplate<String, Object>: Jackson2JsonRedisSerializer for values
  StringRedisSerializer for keys (human-readable keys for debugging)
  Comment: "Keys use String serializer so they're readable in Redis CLI.
  Values use JSON serialization for type safety. Alternative: Kryo (faster
  serialization, smaller size) but JSON is more debuggable."
- CacheManager: RedisCacheManager with default TTL from config

KafkaConfig.java:
@Configuration
Configure:
- KafkaTemplate for producing: with ProducerFactory using StringSerializer
  for keys, JsonSerializer for values
  Comment: "acks=all ensures durability — message is only acknowledged after
  all in-sync replicas have written it. This matches our HIPAA audit requirements."
- ConsumerFactory for denial.received topic: with JsonDeserializer
  configured to trust com.rcm.** packages
  Comment: "Kafka deserialization can be a security risk if arbitrary classes
  are trusted. We whitelist only our own package to prevent deserialization attacks."
- ConcurrentKafkaListenerContainerFactory: MANUAL_IMMEDIATE ack mode
  Comment: "Manual acknowledgment means we control exactly when the offset
  is committed. This prevents message loss if processing fails after consumption
  but before completion — critical for denial management idempotency."

GrpcClientConfig.java:
@Configuration
Configure:
- ManagedChannel to rcm-rag gRPC server (host/port from config)
  Comment: "Keep-alive settings prevent the TCP connection from timing out
  during periods of low activity. Without this, load balancers may close
  idle connections, causing the next gRPC call to fail."
- ClaimScrubbingGrpc.ClaimScrubbingStub: non-blocking stub
  Comment: "Non-blocking stub returns ListenableFuture, allowing us to
  integrate with Resilience4j's async execution without blocking a thread
  while waiting for the gRPC response."
- Resilience4j CircuitBreaker and TimeLimiter beans named 'ragScrubbing'
  matching the config in application.yml

SpringAiConfig.java:
@Configuration
Configure:
- ChatClient bean using Azure OpenAI (from Spring AI auto-configuration)
  with custom default options: temperature=0.1, maxTokens=500
  Comment: "Low temperature (0.1) for claim summarization — we want
  consistent, factual summaries, not creative variation. A temperature of 0
  would be deterministic but may produce repetitive outputs."
- RetryTemplate for Spring AI calls: 2 retries, exponential backoff
  Comment: "Azure OpenAI occasionally returns 429 (rate limit) or 503.
  Retry with exponential backoff handles transient failures gracefully.
  We cap at 2 retries to stay within the claim creation latency budget."

ObservabilityConfig.java:
@Configuration
Configure:
- MeterRegistry customization: add common tags (application, environment)
- Custom Counter beans:
  claimsCreatedCounter, claimsSubmittedCounter, claimsDeniedCounter,
  eligibilityCacheHitCounter, eligibilityCacheMissCounter,
  appealsDraftedCounter, appealsApprovedCounter
  Comment: "Business metric counters are separate from HTTP metrics.
  They track domain events that matter for RCM reporting, not just
  technical performance. These feed the claim-throughput Grafana dashboard."
- Custom Gauge: arBalanceTotalGauge (total AR balance in cents, updated on balance change)

OUTPUT: 7 files.
Each file: // FILE: full/path/ClassName.java  // ===== END OF FILE =====
Full production-quality code with comprehensive inline comments.
No placeholder methods — every method fully implemented.
==========================================

# ============================================================
# PROMPT-033: rcm-core common — Multi-tenancy + Security Cross-cutting
# ============================================================
# GOAL: TenantContext, TenantFilter, HibernateFilter, JwtAuthFilter,
#       InternalContextFilter, PhiAccess annotation
# DEPENDS ON: PROMPT-031 PROMPT-032
# OUTPUT: 6 Java files in common/src/main/java/com/rcm/common/
# ACCEPTANCE CRITERIA:
#   1. TenantContext uses ThreadLocal — explain thread safety in comments
#   2. TenantFilter validates tenant_id from JWT before every request
#   3. HibernateFilter implements Hibernate @Filter interface
#      to inject tenant_id into every SQL WHERE clause
#   4. JwtAuthFilter handles both user tokens and service tokens differently
#   5. InternalContextFilter validates X-Internal-Context signed header
#   6. PhiAccess is a custom annotation used by AuditAspect in next prompt
# ============================================================

PROMPT-033 CONTEXT — paste this into DeepSeek:
==========================================
You are generating multi-tenancy and security cross-cutting classes for
the common module of rcm-core.

PACKAGE BASE: com.rcm.common

PACKAGE: com.rcm.common.multitenancy

TenantContext.java:
// Thread-local storage for the current tenant ID.
// ThreadLocal is used because each HTTP request is processed on its own thread
// (or virtual thread in Java 21). The tenant_id must be available anywhere
// in the call stack without passing it as a parameter everywhere.
// IMPORTANT: TenantContext.clear() MUST be called after request processing
// to prevent tenant ID leaking to the next request reusing the thread.
// This is handled by TenantFilter's finally block.
public class TenantContext {
    private static final ThreadLocal<String> TENANT_ID = new ThreadLocal<>();
    // static methods: set(String tenantId), get(), clear()
    // Include null check in get() with clear error message:
    // "Tenant context not set — this indicates a request reached this code
    //  path without going through TenantFilter, which should never happen.
    //  Check the Spring Security filter chain configuration."
}

TenantFilter.java:
// Servlet filter that extracts tenant_id from the JWT claims and stores
// it in TenantContext for the duration of the request.
// Registered AFTER JwtAuthFilter so the JWT is already validated.
@Component
@Order(2)  // explain what Order means here
public class TenantFilter extends OncePerRequestFilter {
    // doFilterInternal:
    // 1. Get authentication from SecurityContext (already validated by JwtAuthFilter)
    // 2. Extract tenant_id claim from JWT
    // 3. Validate tenant_id is not null (throw 400 if missing)
    // 4. Set in TenantContext
    // 5. try { filterChain.doFilter } finally { TenantContext.clear() }
    // Comments explaining each step and WHY it's ordered this way
}

TenantHibernateFilter.java:
// Hibernate @Filter configuration that appends WHERE tenant_id = :tenantId
// to every query on entities annotated with @Filter(name = "tenantFilter").
// This is our primary defense against tenant data leakage — it's enforced
// at the ORM layer, not the application layer, so developers cannot
// accidentally bypass it by forgetting a WHERE clause.
@Component
public class TenantHibernateFilter {
    @PersistenceContext private EntityManager entityManager;

    // enableTenantFilter(): called from TenantFilter after setting TenantContext
    // Gets the Hibernate Session from EntityManager and enables the filter:
    // session.enableFilter("tenantFilter").setParameter("tenantId", TenantContext.get())
    // Comment: "The filter name 'tenantFilter' must match the @FilterDef
    // declared on BaseEntity. If they don't match, no error is thrown —
    // the filter simply doesn't apply, which is a silent security failure."
}

PACKAGE: com.rcm.common.security

JwtAuthFilter.java:
// JWT authentication filter that validates Bearer tokens on every request.
// Handles two types of tokens:
// 1. User tokens: issued by Keycloak via OIDC Authorization Code flow
// 2. Service tokens: issued by Keycloak via Client Credentials grant
//    (used for service-to-service calls, e.g. rcm-bff calling rcm-core)
//
// Both token types are RS256 JWT validated against Keycloak's JWKS endpoint.
// The JWKS is cached locally — Keycloak's public key rotates rarely (yearly).
@Component
@Order(1)
public class JwtAuthFilter extends OncePerRequestFilter {
    // doFilterInternal:
    // 1. Extract Bearer token from Authorization header
    //    Comment: "Null check is important — actuator health endpoints are
    //    permitted without auth, so some requests legitimately have no token"
    // 2. Decode and validate JWT using Spring Security's JwtDecoder
    // 3. Build UsernamePasswordAuthenticationToken with claims as principal
    // 4. Set in SecurityContextHolder
    //    Comment: "SecurityContextHolder is ThreadLocal-based. We use
    //    MODE_INHERITABLETHREADLOCAL to propagate auth context to async threads
    //    spawned by @Async methods (e.g., claim summarization)"
    // 5. Handle JwtException: return 401 with WWW-Authenticate header
}

InternalContextFilter.java:
// Validates the X-Internal-Context header on service-to-service calls.
// When rcm-bff calls rcm-core, it includes this signed header containing:
// { "userId": "uuid", "tenantId": "uuid", "requestId": "uuid", "issuedAt": epoch }
// Signed with HMAC-SHA256 using the shared internal signing key.
//
// This separates user identity (who is the end user) from service identity
// (which service is making the call). The Bearer token identifies the SERVICE.
// The X-Internal-Context header identifies the USER on behalf of whom
// the service is acting.
@Component
@Order(3)
public class InternalContextFilter extends OncePerRequestFilter {
    // doFilterInternal:
    // 1. Check if X-Internal-Context header is present
    //    If absent and caller is a service token: request proceeds without user context
    //    (some service-to-service calls are system-level, not user-triggered)
    // 2. If present: verify HMAC-SHA256 signature
    // 3. Parse JSON payload: extract userId, tenantId, requestId
    // 4. Validate tenantId matches TenantContext (must be same tenant!)
    //    Comment: "This cross-check prevents a compromised service from
    //    impersonating a user in a different tenant by crafting a header
    //    with a different tenantId than their service token's tenantId"
    // 5. Store userId and requestId in request attributes for downstream use
}

PACKAGE: com.rcm.common.security (annotation)

PhiAccess.java:
// Method annotation that marks methods which access Protected Health Information (PHI).
// Used by AuditAspect to automatically generate HIPAA audit log entries.
//
// Usage:
// @PhiAccess(entityType = "Patient", action = PhiAction.READ)
// public Patient getPatient(UUID patientId) { ... }
//
// The annotation drives automatic audit logging — developers declare that
// a method touches PHI, and the framework handles the audit event creation.
// This prevents developers from accidentally forgetting to log PHI access.
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface PhiAccess {
    String entityType();                          // e.g. "Patient", "Claim"
    PhiAction action() default PhiAction.READ;    // READ, WRITE, DELETE
    boolean includeEntityId() default true;       // whether to log entity ID
}

// PhiAction enum in same file:
public enum PhiAction { READ, WRITE, DELETE }

OUTPUT: 6 files.
// FILE: rcm-core/common/src/main/java/com/rcm/common/multitenancy/TenantContext.java
[etc.]
Each ends with // ===== END OF FILE =====
Full production-quality code. No stubs. All methods complete.
Comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-034: rcm-core common — Audit + Feature Flags + Domain Events
# ============================================================
# GOAL: AuditEvent, AuditService, AuditAspect (AOP),
#       FeatureFlag enum, FeatureFlagService, FeatureFlagEntity,
#       DomainEvent base, DomainEventPublisher
# DEPENDS ON: PROMPT-031 PROMPT-033
# OUTPUT: 9 Java files across audit/, featureflags/, events/ packages
# ACCEPTANCE CRITERIA:
#   1. AuditAspect uses @Around with @PhiAccess annotation interception
#   2. AuditService writes to MongoDB asynchronously (non-blocking)
#   3. FeatureFlagService checks L1 Caffeine cache first, then DB
#   4. FeatureFlagService listens to Redis pub/sub for invalidation
#   5. DomainEventPublisher uses Spring ApplicationEventPublisher
#      for in-process events between bounded contexts
# ============================================================

PROMPT-034 CONTEXT — paste this into DeepSeek:
==========================================
You are generating audit logging, feature flag, and domain event classes
for the common module of rcm-core.

PACKAGE BASE: com.rcm.common

PACKAGE: com.rcm.common.audit

AuditEvent.java:
// Immutable record representing a HIPAA audit log entry.
// Written to MongoDB audit_events collection for 7-year retention.
// Fields match the MongoDB schema defined in the architecture:
// tenantId, actorId, actorType, action, entityType, entityId,
// timestamp, ipAddress, requestId, traceId, outcome, llmCallId
//
// Use Java record for immutability — audit events should never be modified.
// Records provide equals/hashCode/toString automatically.
public record AuditEvent(
    String tenantId,
    String actorId,
    ActorType actorType,    // USER, SERVICE, AGENT
    String action,          // READ, WRITE, DELETE
    String entityType,      // Patient, Claim, Denial, etc.
    String entityId,
    Instant timestamp,
    String ipAddress,
    String requestId,
    String traceId,         // OpenTelemetry trace ID for correlation
    AuditOutcome outcome,   // SUCCESS, FAILURE
    String llmCallId        // nullable — present when PHI was accessed via LLM call
) {}

AuditService.java:
@Service
public class AuditService {
    // MongoCollection<Document> for direct MongoDB driver writes
    // (faster than Spring Data MongoDB for high-volume audit appends)

    // writeAuditEvent(AuditEvent event): @Async annotated
    // Converts AuditEvent record to MongoDB Document and inserts
    // Comment: "Async write ensures audit logging doesn't add latency to
    // the main request path. The trade-off: if the application crashes
    // immediately after the PHI access but before the async write completes,
    // the audit entry may be lost. This is an acceptable risk — we prioritize
    // request performance over perfect audit completeness in rare crash scenarios.
    // For stricter requirements, consider synchronous writes or a write-ahead log."

    // buildDocument(AuditEvent): converts record to BSON Document
    // Include traceId from OpenTelemetry current span context
    // Comment: "Including the traceId links the audit entry to the full
    // distributed trace in Tempo, enabling complete request reconstruction
    // for incident investigation — critical for HIPAA breach response."
}

AuditAspect.java:
@Aspect
@Component
public class AuditAspect {
    // @Around("@annotation(phiAccess)")
    // pointcut intercepts all methods annotated with @PhiAccess

    // around advice:
    // 1. Extract entityId from method return value (after execution)
    //    OR from method parameters (before, for READ operations)
    //    Comment: "We try to get entityId from the return value for WRITE
    //    operations (the saved entity has the generated ID). For READ
    //    operations, we get it from the parameter."
    // 2. Build AuditEvent with:
    //    - tenantId from TenantContext
    //    - actorId from SecurityContext (userId claim)
    //    - actorType: USER (from JWT sub) or SERVICE (from client_id claim)
    //    - entityType, action from @PhiAccess annotation values
    //    - ipAddress from HttpServletRequest (from RequestContextHolder)
    //    - requestId from InternalContextFilter stored attribute
    //    - traceId from OpenTelemetry span context
    // 3. Call AuditService.writeAuditEvent() (async)
    // 4. Proceed with method execution
    // 5. If exception: write FAILURE audit event then rethrow
    //    Comment: "Audit failed operations — a failed attempt to read PHI
    //    is as important to record as a successful one for security forensics."
}

PACKAGE: com.rcm.common.featureflags

FeatureFlag.java:
// Enum of all feature flags in the system.
// Adding a new flag requires: 1) adding to this enum, 2) inserting into DB.
// This enum is the single source of truth for flag names.
// Prevents typos from causing silent flag misses.
public enum FeatureFlag {
    RAG_CLAIM_SCRUBBING("rag.claim-scrubbing"),
    RAG_DENIAL_EXPLANATION("rag.denial-explanation"),
    RAG_APPEAL_DRAFTING("rag.appeal-drafting"),
    AI_CLAIM_SUMMARIZATION("ai.claim-summarization");

    private final String flagName; // DB column value — must match feature_flags table
    // constructor, getter
}

FeatureFlagEntity.java:
@Entity @Table(name = "feature_flags", schema = "rcm")
@FilterDef(name = "tenantFilter", parameters = @ParamDef(name = "tenantId", type = String.class))
@Filter(name = "tenantFilter", condition = "tenant_id = :tenantId OR tenant_id IS NULL")
// Comment: "tenant_id IS NULL means global flag — applies to all tenants.
// tenant-specific flag takes precedence if both exist."
public class FeatureFlagEntity {
    // id, tenantId (nullable for global flags), flagName, enabled, metadata (JSONB as String)
}

FeatureFlagService.java:
@Service
public class FeatureFlagService {
    // Caffeine cache: LoadingCache<String, Boolean>
    // Key: "{tenantId}:{flagName}" or "global:{flagName}"
    // Comment: "L1 Caffeine cache avoids a DB query on every feature flag check.
    // Flags are checked on every request for gated features (e.g., every claim
    // scrub checks rag.claim-scrubbing). Without caching this would be a DB
    // query on every claim submission — unacceptable."

    // isEnabled(FeatureFlag flag, String tenantId): boolean
    // 1. Check Caffeine cache for "{tenantId}:{flagName}"
    // 2. Cache miss: query DB for tenant-specific flag, fall back to global flag
    // 3. Store result in cache (TTL 60 seconds — allows fast propagation of changes)

    // Redis pub/sub listener for "feature-flags-invalidated" channel
    // When received: invalidate cache entry for that flag
    // Comment: "Redis pub/sub allows near-instant flag propagation across
    // all service instances without waiting for cache TTL expiry.
    // Use case: emergency disable of a misbehaving AI feature in production."

    // updateFlag(FeatureFlag flag, String tenantId, boolean enabled):
    // Update DB, then publish Redis invalidation message
}

PACKAGE: com.rcm.common.events

DomainEvent.java:
// Abstract base class for all domain events published within rcm-core.
// Domain events are in-process Spring ApplicationEvents used for
// communication between bounded contexts without direct dependencies.
//
// Example: ClaimService publishes ClaimSubmittedEvent after submission.
// DenialReceivedConsumer listens for ClaimPaidEvent to update AR balances.
// This decouples bounded contexts — Claims doesn't need to know about AR.
public abstract class DomainEvent extends ApplicationEvent {
    private final String tenantId;
    private final String requestId;
    private final Instant occurredAt;
    // constructor, getters
}

DomainEventPublisher.java:
@Component
public class DomainEventPublisher {
    // Wraps ApplicationEventPublisher with logging and tracing
    // publish(DomainEvent event):
    // 1. Log the event (including tenantId, type, occurredAt)
    // 2. Add trace span (OpenTelemetry) for the event publication
    // 3. applicationEventPublisher.publishEvent(event)
    // Comment: "We wrap the Spring event publisher to ensure consistent
    // logging and tracing for all domain events. This makes it easy to
    // find all domain events in a trace and debug cross-context interactions."
}

OUTPUT: 9 files.
// FILE: rcm-core/common/src/main/java/com/rcm/common/audit/AuditEvent.java
[etc.]
Each ends with // ===== END OF FILE =====
Full implementation. All methods complete. Comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-035: rcm-core common — Exception Handling + Observability + Cache
# ============================================================
# GOAL: Exception classes, GlobalExceptionHandler, MetricsConfig,
#       TraceConfig, L1CacheConfig, CacheInvalidationListener,
#       TenantIsolationTest, AuditAspectTest
# DEPENDS ON: PROMPT-031 PROMPT-034
# OUTPUT: 7 Java files + 2 test files
# ACCEPTANCE CRITERIA:
#   1. GlobalExceptionHandler returns consistent ErrorResponse format
#      matching the OpenAPI spec from PROMPT-017
#   2. TraceConfig propagates W3C Trace Context across async boundaries
#   3. L1CacheConfig builds Caffeine caches for CPT, ICD10, CARC/RARC,
#      payer metadata, and prompt templates
#   4. TenantIsolationTest verifies a query without Hibernate filter
#      active returns 0 rows from a multi-tenant seeded dataset
#   5. All tests use JUnit 5 + Mockito (no Spring context in unit tests)
# ============================================================

PROMPT-035 CONTEXT — paste this into DeepSeek:
==========================================
You are generating exception handling, observability, and cache configuration
classes for the common module of rcm-core, plus two critical tests.

PACKAGE BASE: com.rcm.common

PACKAGE: com.rcm.common.exception

RcmException.java:
// Base exception for all RCM business exceptions.
// Carries an error code (machine-readable), HTTP status, and message.
// All service-level exceptions extend this.
public class RcmException extends RuntimeException {
    private final String errorCode;     // e.g. "CLAIM_NOT_FOUND"
    private final HttpStatus httpStatus;
    // static factory methods for common cases:
    // notFound(String entityType, String entityId)
    // validationFailed(String message)
    // conflict(String message)
    // serviceUnavailable(String message, Throwable cause)
}

TenantIsolationException.java:
// Thrown when a tenant isolation violation is detected.
// This is a security exception — log at ERROR level and alert.
// Should never occur in production if Hibernate filter is correctly configured.
public class TenantIsolationException extends RcmException {
    // constructor that logs the violation details before creating the exception
    // Comment: "We log before creating the exception so the log entry
    // is guaranteed even if the exception is swallowed somewhere upstream.
    // A tenant isolation violation is a security incident, not just an error."
}

GlobalExceptionHandler.java:
@RestControllerAdvice
public class GlobalExceptionHandler {
    // Handle RcmException: return appropriate HTTP status + ErrorResponse body
    // Handle ConstraintViolationException (Bean Validation): 422 + field errors
    // Handle MethodArgumentNotValidException: 422 + field errors
    // Handle AccessDeniedException: 403
    // Handle JwtException: 401
    // Handle generic Exception: 500 (log stack trace, return generic message)
    //   Comment: "Never return exception details to the caller for 500 errors —
    //   it leaks internal implementation details. Log the full stack trace
    //   internally and return only a traceId the caller can use for support."

    // buildErrorResponse(HttpStatus, String code, String message, String traceId, List<String> details)
    // Returns ErrorResponse matching OpenAPI spec:
    // { code, message, details, traceId, timestamp }

    // getTraceId(): extract from OpenTelemetry current span
    //   Comment: "Including the traceId in error responses allows callers
    //   to correlate their error with the full distributed trace in Tempo,
    //   dramatically reducing time-to-diagnosis for production incidents."
}

PACKAGE: com.rcm.common.observability

MetricsConfig.java:
@Configuration
public class MetricsConfig {
    // MeterRegistryCustomizer: add common tags to all metrics
    //   application=${spring.application.name}, environment=${spring.profiles.active}
    //   Comment: "Common tags ensure every metric is filterable by service and
    //   environment in Grafana — critical when multiple environments share a
    //   Prometheus instance."

    // Custom MeterBinder for RCM business metrics:
    // Register counters: claims.created, claims.submitted, claims.paid,
    //   claims.denied, eligibility.cache.hit, eligibility.cache.miss,
    //   appeals.drafted, appeals.approved
    // Register gauge: ar.balance.total (reads from AR service — lazy supplier)
    //   Comment: "Gauge uses a lazy supplier to avoid circular dependencies.
    //   The value is fetched from ArService when Prometheus scrapes /actuator/prometheus,
    //   not on every state change."
}

TraceConfig.java:
@Configuration
public class TraceConfig {
    // OpenTelemetry configuration for distributed tracing
    // Comment: "Auto-instrumentation via opentelemetry-spring-boot-starter handles
    // most cases. We only need manual configuration for:
    // 1. Propagating trace context across async @Async boundaries
    // 2. Adding custom span attributes (tenantId, claimId) to traces
    // 3. Configuring the OTLP exporter to ship traces to Tempo"

    // AsyncConfigurer bean: configure async executor to propagate SecurityContext
    // AND OpenTelemetry context to async threads
    // Comment: "By default, @Async methods run in a new thread that doesn't
    // inherit SecurityContext or trace context. We must explicitly propagate both
    // to ensure tenant isolation and trace continuity in async operations."

    // Custom SpanFilter: add tenantId and requestId as span attributes
    // to every incoming HTTP request span
}

PACKAGE: com.rcm.common.cache

L1CacheConfig.java:
@Configuration
public class L1CacheConfig {
    // Build Caffeine caches for hot reference data loaded at startup

    // cptCodeCache: LoadingCache<String, CptCodeDto>
    //   maximumSize=15000, stats enabled
    //   CacheLoader: queries DB via CptCodeRepository
    //   Comment: "15,000 entries covers all active CPT codes (~10,000)
    //   with room for growth. At ~200 bytes per entry = ~3MB. Acceptable
    //   heap usage for the benefit of microsecond CPT code lookups
    //   on every claim line validation."

    // icd10CodeCache: LoadingCache<String, Icd10CodeDto>
    //   maximumSize=100000 (ICD-10 has 70,000+ codes)

    // carcCodeCache: LoadingCache<String, CarcCodeDto>
    //   maximumSize=500 (only ~900 CARC codes exist)

    // rarcCodeCache: LoadingCache<String, RarcCodeDto>
    //   maximumSize=1000

    // payerMetadataCache: LoadingCache<String, PayerDto>
    //   maximumSize=10000, expireAfterWrite=1h
    //   Comment: "Payer metadata changes infrequently but does change.
    //   1-hour TTL balances freshness with cache efficiency.
    //   CARC/CPT/ICD10 codes are stable — no TTL needed (only eviction on size)."

    // Cache stats logging: log hit rates every 15 minutes
    // Comment: "Cache hit rate monitoring helps right-size the cache.
    // A low hit rate means the cache is too small or the access pattern
    // is too random to benefit from caching."
}

CacheInvalidationListener.java:
@Component
public class CacheInvalidationListener {
    // Redis pub/sub MessageListener for 'feature-flags-invalidated' channel
    // AND 'reference-data-invalidated' channel (for CPT/payer updates)

    // onMessage(Message message, byte[] pattern):
    // Parse the invalidation message (contains: cacheType, key)
    // Invalidate the appropriate Caffeine cache entry
    // Comment: "Redis pub/sub message delivery is at-most-once — if a service
    // instance is down when the message is published, it misses it. This is
    // acceptable because: 1) the caches have TTLs as a fallback,
    // 2) reference data changes are rare, 3) serving slightly stale reference
    // data for minutes is not a safety issue for CPT/ICD10 lookups."
}

TESTS:

TenantIsolationTest.java:
@SpringBootTest
@Testcontainers
// This test verifies that the Hibernate tenant filter actually works.
// It seeds data for two tenants, then queries with one tenant's filter active
// and verifies the other tenant's data is NOT returned.
// This test must pass on every PR — it's a security regression test.
public class TenantIsolationTest {
    // @Container: PostgreSQLContainer with flyway migrations applied

    // @Test verifyPatientIsolation():
    // 1. Insert patient for tenant-A and patient for tenant-B
    // 2. Activate Hibernate filter with tenant-A's ID
    // 3. Query ALL patients (no WHERE tenant_id clause in query)
    // 4. Assert: only tenant-A's patient returned (tenant-B's is filtered out)
    // 5. Assert: count = 1 (not 2)
    // Comment: "This test catches the most dangerous regression possible:
    // a Hibernate filter accidentally disabled or misconfigured would cause
    // all queries to return data across all tenants — a HIPAA violation."

    // @Test verifyNoFilterMeansNoData():
    // Disable the filter entirely, query, assert 0 rows returned
    // Comment: "Without the filter, we WANT zero rows (fail closed).
    // This verifies our ORM configuration returns nothing rather than
    // everything when the filter is misconfigured."
}

AuditAspectTest.java:
@ExtendWith(MockitoExtension.class)
public class AuditAspectTest {
    // Test that @PhiAccess annotation triggers audit event creation
    // Mock: AuditService, SecurityContext, TenantContext, HttpServletRequest
    // Verify: auditService.writeAuditEvent() called with correct fields
    // Verify: FAILURE audit event written when method throws exception
    // Verify: entityType and action from annotation are captured correctly
}

OUTPUT: 9 files (7 production + 2 test).
Each: // FILE: full/path // ===== END OF FILE =====
Full implementation. Comprehensive inline comments. Complete tests.
==========================================

# ============================================================
# PROMPT-036: rcm-core registration bounded context
# ============================================================
# GOAL: Complete registration bounded context — all domain, repo, service, API
# DEPENDS ON: PROMPT-031 PROMPT-035
# OUTPUT: ~12 Java files in rcm-core/registration/
# ACCEPTANCE CRITERIA:
#   1. Patient is an aggregate root with business methods (not just getters)
#   2. PatientService validates MRN uniqueness per tenant before creating
#   3. PatientController uses @PhiAccess on all PHI-returning methods
#   4. SSN is stored encrypted (pass through pgcrypto function via JPA)
#   5. PatientMapper uses MapStruct — no manual mapping code
#   6. PatientControllerIntegrationTest uses Testcontainers + real Postgres
# ============================================================

PROMPT-036 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the registration bounded context for rcm-core.
This handles patient registration and demographic management.

PACKAGE: com.rcm.registration

ARCHITECTURE RULES:
- Patient is the aggregate root — all state changes via business methods
- No public setters — use business method names (register(), updateDemographics())
- @PhiAccess annotation on any service method that returns patient data
- SSN encrypted via pgcrypto at DB level — use @ColumnTransformer in JPA
- tenant_id set from TenantContext, never from request body
- Multi-tenancy enforced via Hibernate @Filter ("tenantFilter")

Patient.java (domain/):
@Entity @Table(name = "patients", schema = "rcm")
@FilterDef + @Filter for tenant isolation
@EntityListeners(AuditingEntityListener.class) for createdAt/updatedAt

// Aggregate root — all state changes via business methods.
// Never expose setters. Domain logic lives here, not in PatientService.
public class Patient {
    @Id UUID id;
    @Column UUID tenantId; // set from TenantContext on creation
    String mrn;
    String firstName, lastName;
    LocalDate dateOfBirth;

    // SSN stored encrypted via pgcrypto pgp_sym_encrypt/pgp_sym_decrypt
    // @ColumnTransformer annotation handles the encryption transparently
    // Comment: "pgcrypto encryption happens in the database, not the application.
    // The encryption key never exists in application memory as a Java String —
    // it's passed as a DB parameter. This means a heap dump can't reveal the key."
    @ColumnTransformer(
        read = "pgp_sym_decrypt(ssn_encrypted, current_setting('app.encryption_key'))",
        write = "pgp_sym_encrypt(?, current_setting('app.encryption_key'))"
    )
    String ssn;

    @Enumerated(EnumType.STRING) Gender gender;
    @Type(JsonType.class) Address address; // JSONB
    String phone, email;
    @Type(JsonType.class) List<InsuranceInfo> insuranceInfoList; // JSONB array

    // Business methods:
    // static register(TenantId, Mrn, Demographics, InsuranceInfo): Patient
    //   Comment: "Factory method on the aggregate root ensures an entity
    //   can only be created in a valid state. You can't create a Patient
    //   without the required fields — the constructor enforces this invariant."

    // updateDemographics(Demographics demographics): void
    //   Comment: "Deliberately named 'update' not 'set' — it's a business
    //   operation with meaning, not just a property mutation."

    // addInsurance(InsuranceInfo insurance): void
    // removeInsurance(String payerId): void
}

PatientId.java, Demographics.java, InsuranceInfo.java, Address.java (domain/value objects):
// Simple immutable records
// PatientId wraps UUID with validation (must not be null)
// Demographics: firstName, lastName, dateOfBirth, gender — validated
// InsuranceInfo: payerId, memberId, groupNumber, coverageType

PatientRepository.java (repository/):
// Spring Data JPA repository
// Custom queries:
// Optional<Patient> findByTenantIdAndMrn(String tenantId, String mrn)
//   Comment: "MRN (Medical Record Number) must be unique per tenant.
//   We check this in the service before creating to give a clear error,
//   rather than relying on the DB unique constraint for the user-facing message."
// Page<Patient> findAllByTenantId(String tenantId, Pageable pageable)
// Page<Patient> searchByName(String tenantId, String searchTerm, Pageable pageable)
//   Comment: "Search uses ILIKE for case-insensitive matching.
//   For large patient populations (>100K), a full-text search index would
//   be needed. This is documented in DATA-08 ADR as a future optimization."

PatientService.java (service/):
@Service @Transactional
@PhiAccess applied at class level (all methods touch PHI)
// getPatient(UUID id): Patient — @PhiAccess(entityType="Patient", action=READ)
// createPatient(CreatePatientCommand command): Patient
//   1. Validate MRN uniqueness for this tenant
//   2. Create Patient via factory method
//   3. Save and publish PatientRegisteredEvent
// updatePatient(UUID id, UpdatePatientCommand command): Patient
// listPatients(PatientFilter filter, Pageable pageable): Page<Patient>
// searchPatients(String searchTerm, Pageable pageable): Page<Patient>

PatientController.java (api/):
@RestController @RequestMapping("/v1/patients")
@Validated
// GET /v1/patients — list with cursor pagination
// GET /v1/patients/{id} — get by ID
// POST /v1/patients — create
// PUT /v1/patients/{id} — update
// All return PatientResponse DTO (not the entity)
// Cursor pagination: convert Spring Pageable to cursor-based response

DTOs (api/dto/):
CreatePatientRequest.java — Bean Validation annotations on all fields
PatientResponse.java — what the API returns (no SSN in response)
UpdatePatientRequest.java

PatientMapper.java (api/mapper/):
@Mapper(componentModel = "spring")
// Patient → PatientResponse (MapStruct interface)
// CreatePatientRequest → Patient (via service command object)
// Comment: "MapStruct generates type-safe mapping code at compile time.
// Alternative: ModelMapper (runtime reflection, slower, less type-safe).
// MapStruct catches mapping errors at compile time — preferred."

PatientRegisteredEvent.java (events/):
// Domain event published when a patient is registered
public class PatientRegisteredEvent extends DomainEvent {
    private final UUID patientId;
    private final String tenantId;
    // No PHI in domain events — just IDs for downstream listeners
    // Comment: "Domain events carry IDs, not PHI. Downstream consumers
    // fetch PHI separately if needed. This prevents PHI from flowing through
    // the application event bus which is not encrypted."
}

TESTS:
PatientTest.java (unit — tests domain logic, no Spring context)
PatientServiceTest.java (unit — mocked dependencies)
PatientControllerIntegrationTest.java (Testcontainers + real Postgres):
    - POST /v1/patients → 201 with patient body
    - GET /v1/patients/{id} → 200
    - GET /v1/patients/{otherId} (different tenant) → 404 (isolation verified)
    - POST /v1/patients (duplicate MRN) → 409

OUTPUT: ~12 files in rcm-core/registration/
Each: // FILE: full/path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-037: rcm-core eligibility bounded context
# ============================================================
# GOAL: Complete eligibility bounded context with Redis L2 cache
# DEPENDS ON: PROMPT-031 PROMPT-035
# OUTPUT: ~10 Java files in rcm-core/eligibility/
# ACCEPTANCE CRITERIA:
#   1. EligibilityService checks Redis before calling the mock payer client
#   2. Cache key format: {tenantId}:{patientId}:{payerId}:{serviceDate}
#   3. 270/271 EDI mock returns realistic response structure
#   4. Cache hit/miss metrics emitted to Prometheus
#   5. EligibilityResponse stored in Postgres for audit trail
# ============================================================

PROMPT-037 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the eligibility bounded context for rcm-core.
This handles eligibility verification (270/271 EDI transactions).

PACKAGE: com.rcm.eligibility

FLOW (from sequence diagram PROMPT-009):
1. Request arrives at EligibilityController
2. EligibilityService checks Redis L2 cache
3. Cache HIT → return cached response (increment cache hit counter)
4. Cache MISS → PayerEligibilityClient sends mock 270 request
5. Parse 271 response into EligibilityResponse domain object
6. Store EligibilityResponse in Postgres (audit trail)
7. Cache response in Redis with TTL 24h
8. Return response (increment cache miss counter)

EligibilityRequest.java (domain/):
// Value object representing a request to verify eligibility
// Fields: patientId, payerId, serviceDate
// Validation: serviceDate cannot be more than 1 year in the past or future
public record EligibilityRequest(UUID patientId, UUID payerId, LocalDate serviceDate) {
    // compact constructor with validation
}

EligibilityResponse.java (domain/):
// Rich domain object — NOT just a data bag
// Fields: all coverage details + metadata about the verification
// coverageActive, coverageStart, coverageEnd,
// deductibleCents, deductibleMetCents, outOfPocketMaxCents, outOfPocketMetCents,
// copayCents, coinsurancePct, memberId, groupNumber,
// verifiedAt, cachedAt (null if not from cache), payerResponseCode

// Business methods:
// isCurrentlyActive(): checks coverageActive AND date range
// isDeductibleMet(): deductibleMetCents >= deductibleCents
// hasMetOutOfPocketMax(): outOfPocketMetCents >= outOfPocketMaxCents

EligibilityResponseEntity.java (domain/):
// JPA entity for storing eligibility responses in Postgres
// Maps to rcm.eligibility_responses table
// Separate from the domain EligibilityResponse — entity is persistence concern
// @FilterDef + @Filter for tenant isolation

EligibilityResponseRepository.java:
// findTopByPatientIdAndPayerIdOrderByVerifiedAtDesc — for history
// findByPatientIdAndPayerIdAndServiceDate — for exact lookup

EligibilityCache.java (service/):
@Component
// Encapsulates Redis L2 cache for eligibility responses
// cacheKey(tenantId, patientId, payerId, serviceDate): String
//   Returns: "{tenantId}:{patientId}:{payerId}:{serviceDate}"
//   Comment: "Including serviceDate in the key because coverage can differ
//   by service date — a patient may have had coverage on a past date but
//   not currently. Date-specific caching prevents incorrect coverage results."

// get(String cacheKey): Optional<EligibilityResponse>
//   deserialize from Redis using ObjectMapper
//   increment cache hit/miss counter

// put(String cacheKey, EligibilityResponse response):
//   serialize to JSON, set with TTL from config (default 24h)
//   Comment: "24h TTL balances freshness with payer API call reduction.
//   Real-time eligibility changes (coverage termination) may not be reflected
//   until the cache expires. This is a documented business trade-off."

// evict(String cacheKey): for manual cache invalidation

PayerEligibilityClient.java (client/):
@Component
// Mock implementation of the 270/271 EDI eligibility check
// In production: would call the actual clearinghouse API
// Returns realistic 271 response for known payers in seed data
// Returns coverage-inactive response for unknown payer IDs

// verify(EligibilityRequest request): EligibilityResponse
//   Builds a realistic mock 271 response based on the payer
//   Log the 270 "transaction" with a generated transaction ID
//   Simulate 50-200ms latency (Thread.sleep) for realism
//   Comment: "Mock latency simulates real payer response time.
//   Real payers take 1-5 seconds for synchronous 271 responses.
//   Our mock is faster for dev but the circuit breaker timeout
//   is set to 5s to accommodate real payer latency in production."

EligibilityService.java (service/):
@Service @Transactional(readOnly = true)
// verifyEligibility(EligibilityRequest request): EligibilityResponse
//   Full flow as described above
//   @PhiAccess(entityType="Patient", action=READ) — reads patient coverage

// getEligibilityHistory(UUID patientId, UUID payerId, Pageable pageable):
//   Returns historical checks from Postgres

EligibilityController.java (api/):
@RestController @RequestMapping("/v1/eligibility")
// POST /v1/eligibility/verify
// GET /v1/eligibility/{patientId}/history

EligibilityCheckRequest.java, EligibilityCheckResponse.java (api/dto/)

TESTS:
EligibilityServiceTest.java — mock Redis, verify cache hit/miss logic
EligibilityControllerIntegrationTest.java — Testcontainers + Redis + Postgres
    - First call: cache miss → payer client called → response returned and cached
    - Second identical call: cache hit → payer client NOT called → same response
    - Different serviceDate: cache miss (new cache key)

OUTPUT: ~10 files. Each: // FILE: path // ===== END OF FILE =====
Full implementation with comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-038: rcm-core charge-capture bounded context
# ============================================================
# GOAL: Complete charge capture — encounters and charge items
# DEPENDS ON: PROMPT-031 PROMPT-035
# OUTPUT: ~10 Java files in rcm-core/charge-capture/
# ACCEPTANCE CRITERIA:
#   1. Encounter aggregate validates CPT codes against L1 cache
#   2. Total charge is computed from charge items (not stored separately)
#   3. ChargeItem is a value object embedded in Encounter
#   4. Place of service codes validated against CMS reference list
#   5. NCCI (National Correct Coding Initiative) edit check — basic version:
#      detect duplicate CPT codes on the same encounter
# ============================================================

PROMPT-038 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the charge capture bounded context for rcm-core.
This handles clinical encounter documentation and charge item recording.

PACKAGE: com.rcm.chargecapture

DOMAIN CONCEPTS:
- Encounter: a clinical event (office visit, procedure, etc.) — aggregate root
- ChargeItem: a billable service on the encounter — value object (embedded in Encounter)
- CptCode: wrapper around the CPT code string with validation — value object
- DiagnosisCode: wrapper around ICD-10 code with validation — value object

Encounter.java:
@Entity aggregate root
// Business invariants:
// - service_date cannot be in the future (can't bill for future services)
// - discharge_date >= service_date (or null for outpatient)
// - Must have at least one charge item to submit
// - Duplicate CPT codes on same encounter: generate a warning (NCCI concern)

// Business methods:
// static create(patientId, providerNpi, serviceDate, placeOfService): Encounter
// addCharge(CptCode, List<DiagnosisCode>, List<Modifier>, int units, Money charge): void
//   validates CPT code exists in L1 cache
//   validates ICD-10 codes exist in L1 cache
//   checks for duplicate CPT codes (basic NCCI edit)
// removeCharge(int lineNumber): void
// computeTotalCharge(): Money (sum of all charge items)
// submit(): void (marks as billed — no more changes allowed)

ChargeItem.java (value object — @Embeddable):
// Embedded in Encounter as @ElementCollection
// lineNumber, cptCode, icd10Codes (array), modifiers (array),
// units, chargeCents
// No ID — identity comes from (encounterId, lineNumber)

CptCode.java:
// Value object wrapping CPT code string
// Validates format: 5 digits or 4 digits + letter
// Comment: "CPT codes are either 5 numeric digits (Category I codes like 99213)
// or 4 numeric digits + a letter (Category III codes like 0042T).
// Validating format prevents malformed codes from entering the system."

DiagnosisCode.java:
// Value object wrapping ICD-10 code string
// Validates format: letter + 2 digits + optional decimal + more digits
// e.g. J18.9, E11.9, M17.11

ChargeService.java:
@Service @Transactional
// createEncounter(CreateEncounterCommand): Encounter
// addCharge(UUID encounterId, AddChargeCommand): Encounter
// submitEncounter(UUID encounterId): Encounter (marks encounter as billed)
// getEncounter(UUID id): Encounter

ChargeController.java:
@RestController @RequestMapping("/v1/encounters")
// POST /v1/encounters
// GET /v1/encounters/{id}
// POST /v1/encounters/{id}/charges
// POST /v1/encounters/{id}/submit

DTOs: CreateEncounterRequest, EncounterResponse, AddChargeRequest

TESTS:
ChargeServiceTest.java:
// - Creating encounter with invalid future service_date throws exception
// - Adding charge with invalid CPT code throws exception
// - Adding duplicate CPT code generates warning in result
// - computeTotalCharge() sums correctly in cents
// - Submit locks encounter against further changes

OUTPUT: ~10 files. Each: // FILE: path // ===== END OF FILE =====
Full implementation with comprehensive inline comments.
==========================================
