# BATCH C1 — Prompts 039–045
# rcm-core: claims (2 parts), payments, denials, AR, Dockerfile, integration tests
# GUIDED LATITUDE throughout.
# ============================================================

# ============================================================
# PROMPT-039: rcm-core claims bounded context — Part 1
# ============================================================
# GOAL: Claims domain objects + ClaimService + Edi837Builder + ClaimSummaryService
# DEPENDS ON: PROMPT-031 PROMPT-035 PROMPT-016 PROMPT-017
# OUTPUT: ~10 Java files — domain + service layer (no gRPC/Kafka yet)
# ACCEPTANCE CRITERIA:
#   1. Claim is an aggregate root with explicit state machine
#      (only valid transitions allowed via business methods)
#   2. Edi837Builder produces syntactically correct (though mocked) 837P
#      with real ISA/GS/ST/NM1/CLM/SV1/SE/GE/IEA segments
#   3. ClaimSummaryService uses Spring AI asynchronously —
#      claim creation doesn't wait for summary generation
#   4. Money value object used for all monetary amounts
#      (never Double or BigDecimal for money)
#   5. ClaimLine is a separate entity (not embedded) for queryability
# ============================================================

PROMPT-039 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the claims bounded context for rcm-core — Part 1.
This prompt covers: domain objects, Claim aggregate, ClaimLine entity,
ClaimService, Edi837Builder, and ClaimSummaryService.
Part 2 (PROMPT-040) covers: gRPC client, Kafka, CosmosDB, controller, tests.

PACKAGE: com.rcm.claims

DOMAIN ARCHITECTURE:
Claims is the most complex bounded context. The Claim aggregate root
enforces the state machine — transitions are only allowed in valid order.
A Claim starts as DRAFT, moves through scrubbing, submission, and
adjudication. Each transition is a business method with precondition checks.

Claim.java (aggregate root):
@Entity, @FilterDef, @Filter (tenant isolation)
// State machine enforced by business methods — no direct status setter
// DRAFT → SCRUBBING (submitForScrubbing)
// SCRUBBING → SCRUBBED (markScrubbed) or SCRUB_FAILED (markScrubFailed)
// SCRUB_FAILED → DRAFT (correct) or SCRUBBED (override with managerApproval)
// SCRUBBED → SUBMITTED (submit)
// SUBMITTED → ACKNOWLEDGED (acknowledge) or SCRUB_FAILED (ackWithError)
// ACKNOWLEDGED → PAID or DENIED (adjudicate)
// DENIED → APPEALED (fileAppeal)
// PAID / APPEALED / DENIED → CLOSED (close)

// Key business methods with precondition checks:
// submitForScrubbing(): throws if status != DRAFT, changes to SCRUBBING
// markScrubbed(ClaimScrubResult result): throws if status != SCRUBBING
// markScrubFailed(ClaimScrubResult result): throws if status != SCRUBBING
// submit(String edi837Raw): throws if status != SCRUBBED, stores EDI
// acknowledge(boolean success): throws if status != SUBMITTED
// adjudicate(Money allowedAmount, Money paidAmount): updates financials
// deny(DenialInfo info): records denial details
// fileAppeal(): changes status to APPEALED
// close(): final state

// Comment on state machine pattern:
// "Explicit state machine in the aggregate root prevents invalid transitions.
// Alternative: status field with no validation (common but dangerous —
// a bug could set a claim to PAID without going through adjudication).
// The explicit method approach makes illegal transitions a compile-time
// or explicit exception, not a silent data corruption."

// Computed methods:
// computePatientResponsibility(): paidAmount - allowedAmount (gap = patient pays)
// isSubmittable(): status == SCRUBBED
// isEditable(): status == DRAFT || status == SCRUB_FAILED

ClaimId.java — UUID wrapper value object
ClaimStatus.java — enum with all states + isTerminal() method
ClaimScrubResult.java — value object with passed, issues list, warnings list, scrubbedAt
ClaimLine.java — @Entity (separate table, not embedded, for queryability)
ClaimSummary.java — value object wrapping the Spring AI generated text
DenialInfo.java — value object with carcCode, rarcCode, denialDate, reason
Edi837.java — value object wrapping the raw EDI 837 string with metadata

Money.java (in common domain — referenced here):
// Already defined in common module. Imported here.
// Ensure: amountCents is int (not long — max claim in cents < Integer.MAX_VALUE)
// Operations: add, subtract, multiply — all return new Money (immutable)
// Formatting: toDollars() returns BigDecimal for display only

ClaimRepository.java, ClaimLineRepository.java:
// Custom queries:
// findByStatusAndTenantId(ClaimStatus, String, Pageable)
// findByPayerIdAndTenantId(UUID payerId, String tenantId, Pageable)
// findByPatientIdAndTenantId (for AR)
// findWithLines(UUID claimId) — @EntityGraph to avoid N+1

ClaimService.java:
@Service @Transactional
// createClaim(CreateClaimCommand): Claim
//   1. Validate encounter exists and belongs to tenant
//   2. Validate payer exists
//   3. Build Claim from encounter's charge items
//   4. Save Claim and ClaimLines
//   5. Async: trigger claim summary generation
//   6. Publish ClaimCreatedEvent (domain event)
// getClaim(UUID id): Claim
// listClaims(ClaimFilter, Pageable): Page<Claim>

Edi837Builder.java:
@Component
// Builds a syntactically correct EDI 837P transaction string
// from a Claim domain object.
//
// EDI 837P structure:
// ISA — Interchange Control Header (sender/receiver IDs, timestamp)
// GS  — Functional Group Header
// ST  — Transaction Set Header (transaction type 837)
// BPR — Beginning of Provider Information
// NM1 — Name segments (billing provider, patient, subscriber, payer)
// CLM — Claim Information (claim ID, total charge, place of service)
// DX  — Diagnosis codes
// SV1 — Professional Service (per claim line: CPT, charge, units)
// SE  — Transaction Set Trailer
// GE  — Functional Group Trailer
// IEA — Interchange Control Trailer
//
// Comment: "This produces a syntactically correct 837P for testing.
// A production implementation would use a certified EDI library (e.g., EDIFACT4J).
// The segment structure follows the X12 837P Implementation Guide.
// Key delimiters: * (element), : (composite), ~ (segment terminator)"

// build(Claim claim, PayerMetadata payer): String
//   Returns the full EDI 837P string with proper formatting

ClaimSummaryService.java:
@Service
// Uses Spring AI to generate a one-paragraph plain-English summary
// of what the claim is for. Called asynchronously on claim creation.

// @Async
// generateSummary(UUID claimId): void
//   1. Load claim with lines (fresh query — async context)
//   2. Build prompt: include CPT codes, diagnosis codes, provider, date
//      Comment: "We include only non-PHI claim data in the Spring AI prompt:
//      procedure codes, diagnosis codes, and service type. No patient name,
//      DOB, or other PHI. Spring AI calls Azure OpenAI directly — even with
//      a BAA, we minimize PHI as defense in depth."
//   3. Call chatClient.prompt().user(prompt).call().content()
//   4. Save summary to claim.summary field
//   5. If Spring AI fails: log warning, leave summary null
//      Comment: "Claim summarization is a convenience feature — its failure
//      must never block claim creation. The try/catch ensures the async
//      thread doesn't propagate the exception to the Async executor."

OUTPUT: ~10 files.
// FILE: rcm-core/claims/src/main/java/com/rcm/claims/domain/Claim.java
[etc.]
Each: // FILE: path // ===== END OF FILE =====
Full implementation. Comprehensive inline comments. State machine logic complete.
==========================================

# ============================================================
# PROMPT-040: rcm-core claims bounded context — Part 2
# ============================================================
# GOAL: ClaimScrubGrpcClient + ClaimSubmissionService + CosmosDB client
#       + ClaimController + all tests
# DEPENDS ON: PROMPT-039 PROMPT-016 PROMPT-022
# OUTPUT: ~10 Java files — infrastructure + API layer + tests
# ACCEPTANCE CRITERIA:
#   1. ClaimScrubGrpcClient wraps Resilience4j circuit breaker + time limiter
#   2. Circuit breaker fallback returns a safe default (pass with warning)
#      not a failure — explain the business reason
#   3. CosmosDB client writes event stream asynchronously
#   4. ClaimController handles SSE streaming for scrub progress (optional —
#      at minimum polling via GET /claims/{id}/scrub-status)
#   5. Integration test verifies the full claim creation → scrub → submit flow
# ============================================================

PROMPT-040 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the infrastructure and API layer for the claims
bounded context in rcm-core — Part 2.

PACKAGE: com.rcm.claims

ClaimScrubGrpcClient.java (grpc/):
@Component
// Calls rcm-rag's ClaimScrubbing gRPC service to scrub claims.
// Wrapped with Resilience4j circuit breaker for fault tolerance.

// Dependencies: ClaimScrubbingGrpc.ClaimScrubbingStub (injected from GrpcClientConfig)
//               CircuitBreaker (named 'ragScrubbing' from ResilienceConfig)
//               TimeLimiter (named 'ragScrubbing' — 3s timeout)

// scrub(Claim claim): ClaimScrubResult
//   1. Build ClaimScrubRequest protobuf from Claim entity
//      Comment: "We map from our domain Claim to the protobuf message.
//      The trace ID from OpenTelemetry is included in the request so
//      rcm-rag can continue the distributed trace."
//   2. Execute via Resilience4j:
//      CircuitBreaker.executeCallable(() ->
//        TimeLimiter.executeFutureSupplier(() ->
//          stub.withDeadlineAfter(3, TimeUnit.SECONDS).scrubClaim(request)
//        )
//      )
//   3. Map ClaimScrubResponse protobuf → ClaimScrubResult domain object
//   4. On CircuitBreakerOpenException → fallback: return scrub PASSED with warning
//      Comment: "CRITICAL DESIGN DECISION: When the circuit breaker is open
//      (rcm-rag is down), we allow the claim to proceed with a warning rather
//      than blocking submission. Rationale: denying all claims because the
//      AI scrubbing service is temporarily down is worse than submitting
//      without AI-enhanced scrubbing. The payer will still adjudicate correctly.
//      This is a business decision, not a technical one — validate with the
//      product team before implementing."
//   5. On TimeoutException → retry once, then fallback
//   6. Log circuit breaker state changes at WARN level

ClaimSubmissionService.java (kafka/):
@Component
// Handles claim submission: builds EDI 837P and publishes to Kafka.

// submit(Claim claim): void
//   1. Build EDI 837P via Edi837Builder
//      Comment: "The EDI 837P is built from the scrubbed claim data.
//      If the claim changes after scrubbing, the EDI is rebuilt — ensuring
//      the submitted claim always reflects the current state."
//   2. Publish claim.submitted Kafka event via KafkaTemplate
//      Key: claimId (string) — ensures ordering per claim
//      Value: ClaimSubmittedEvent (JSON) per schema in PROMPT-022
//      Comment: "Using claimId as the Kafka message key ensures all events
//      for a given claim go to the same partition, guaranteeing ordering.
//      This is important: we can't process a denial.received before the
//      corresponding claim.submitted."
//   3. On KafkaException: throw RcmException.serviceUnavailable
//      with the Kafka error as cause
//      Comment: "Don't swallow Kafka exceptions silently. A failed publish
//      means the clearinghouse won't receive the claim. Surface the error
//      so the caller can retry rather than thinking submission succeeded."

ClaimEventStreamClient.java (cosmosdb/):
@Component
// Writes claim lifecycle events to CosmosDB for the event stream.
// Used for analytics and Change Feed consumers.

// writeEvent(String claimId, String eventType, Object payload): CompletableFuture<Void>
//   1. Build CosmosDB document matching schema in DATA-03 ADR:
//      { id, claimId, tenantId, eventType, timestamp, payload, metadata }
//   2. Write asynchronously via asyncContainer.createItem()
//   3. Return CompletableFuture (don't block main thread)
//   4. On CosmosException: log ERROR and return failed future
//      Comment: "CosmosDB failures are logged but don't fail the main flow.
//      The event stream is for analytics/CDC — its failure should not
//      prevent the transactional claim operation from completing.
//      This is acceptable because the event stream is not the system of record
//      (Postgres is). Missing events can be reconstructed from Postgres state."

// Event types written at each claim lifecycle step:
// createClaim → 'claim_created'
// markScrubbed → 'scrub_passed'
// markScrubFailed → 'scrub_failed'
// submit → 'submitted_to_clearinghouse'
// acknowledge → 'acknowledgement_received'
// adjudicate → 'adjudicated'
// deny → 'denial_received'

ClaimController.java (api/):
@RestController @RequestMapping("/v1/claims")
// POST /v1/claims — create claim from encounter
// GET /v1/claims — list with cursor pagination and filters
// GET /v1/claims/{id} — get claim with full detail including scrub result
// POST /v1/claims/{id}/scrub — trigger scrubbing (synchronous, returns scrub result)
//   Calls ClaimScrubService which calls ClaimScrubGrpcClient
//   Returns immediately with scrub result (sync gRPC call)
// POST /v1/claims/{id}/submit — trigger submission (async, returns 202)
//   Validates claim is SCRUBBED, calls ClaimSubmissionService
//   Returns 202 Accepted with Location header to check status

// DTOs: CreateClaimRequest, ClaimResponse, ScrubResultResponse, SubmitClaimRequest
// All responses exclude PHI from patient — return patientId, not patient details

ClaimScrubService.java (service/ — thin orchestration):
@Service @Transactional
// Orchestrates the scrub flow:
// 1. Load claim, validate status == DRAFT or SCRUBBED
// 2. Mark as SCRUBBING
// 3. Call ClaimScrubGrpcClient.scrub()
// 4. Write CosmosDB event (async, don't wait)
// 5. If passed: markScrubbed, save
// 6. If failed: markScrubFailed, save
// 7. Return ClaimScrubResult

TESTS:
ClaimTest.java (unit — state machine tests):
// - Invalid transitions throw IllegalStateException
// - computePatientResponsibility() calculates correctly
// - Duplicate CPT codes on claim lines: business rule tested

ClaimScrubServiceTest.java (unit):
// - When gRPC returns PASS: claim status → SCRUBBED
// - When gRPC returns FAIL: claim status → SCRUB_FAILED
// - When circuit breaker OPEN: fallback applied, claim proceeds with warning
// - CosmosDB write called asynchronously (verify async call made)

ClaimScrubGrpcClientTest.java (unit + Resilience4j):
// - Happy path: builds request correctly, maps response correctly
// - Timeout: TimeLimiter fires, retry attempted, fallback returned
// - Circuit breaker: verify state transitions

ClaimControllerIntegrationTest.java (Testcontainers):
// - Full flow: POST /claims → POST /claims/{id}/scrub → POST /claims/{id}/submit
// - Mock gRPC server for rcm-rag (grpc-testing library)
// - Verify CosmosDB write attempted (mock CosmosDB client)
// - Verify Kafka message published (Testcontainers Kafka)

OUTPUT: ~10 files.
Each: // FILE: path // ===== END OF FILE =====
Full implementation. All Resilience4j wiring complete. Tests complete.
==========================================

# ============================================================
# PROMPT-041: rcm-core payments bounded context
# ============================================================
# GOAL: ERA processing, EDI 835 parsing, payment posting
# DEPENDS ON: PROMPT-031 PROMPT-035
# OUTPUT: ~10 Java files in rcm-core/payments/
# ACCEPTANCE CRITERIA:
#   1. Edi835Parser handles the key 835 segments: ISA, GS, BPR, CLP, SVC, CAS
#   2. PaymentPostingService creates Denial records for denied claim lines
#      by publishing denial.received to Kafka
#   3. ERA processing is idempotent — reprocessing same ERA doesn't
#      create duplicate payments
#   4. Payment amounts validated: paid + contractual adjustment should equal charged
# ============================================================

PROMPT-041 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the payments bounded context for rcm-core.
This handles ERA (Electronic Remittance Advice — 835 EDI) processing
and payment posting.

PACKAGE: com.rcm.payments

DOMAIN CONCEPTS:
ERA (835): electronic file from payer listing claim adjudication results.
  Contains: payer info, payment amounts, adjustments, denial reasons.
Payment: individual payment record for a claim.
CAS (Claim Adjustment Segment): explains adjustments (contractual, patient responsibility, denial).

Edi835Parser.java (domain/):
@Component
// Parses a raw 835 EDI string into structured domain objects.
// Handles the minimum viable subset of 835 segments needed for RCM.

// Key segments parsed:
// ISA — interchange control: sender/receiver IDs, interchange date
// GS  — functional group: functional ID (RA = remittance)
// ST  — transaction set: type 835
// BPR — financial information: total payment amount, payment method, check/EFT number
// CLP — claim payment: claim ID, claim status code, charged amount, paid amount
// SVC — service payment: line level CPT code and payment
// CAS — claim adjustment: adjustment group (CO/PR/OA), reason code, amount
//   CO = Contractual Obligation (writeoff), PR = Patient Responsibility, OA = Other
//   Reason code 45 = contractual adjustment (most common)
// NM1 — names: payer, payee
// SE  — transaction set trailer: segment count

// parse(String edi835Raw): EraParseResult
//   Returns: EraParseResult containing payer info, total payment, and list of ClaimPaymentInfo
//   ClaimPaymentInfo: claimId (external), status, chargedAmount, paidAmount,
//     adjustments (list of: group, reasonCode, amount), linePayments

// Comment: "The 835 segment delimiter is typically ~ for segments and * for elements.
// We read the actual delimiters from the ISA segment positions 103-106 to handle
// non-standard delimiters. A parser that assumes fixed delimiters fails on
// clearinghouses that use different delimiters — a real production issue."

Era.java (domain/):
@Entity — maps to rcm.eras table
// Fields: id, tenantId, payerId, eraDate, totalAmountCents, checkNumber,
//         eftTraceNumber, raw835Response (stored for audit), processedAt
// Constraint: once processedAt is set, the ERA is immutable
//   Comment: "Immutability after processing ensures idempotency.
//   If the same 835 is submitted twice, the second submission sees
//   processedAt != null and skips processing — preventing duplicate payments."

Payment.java (domain/):
@Entity — maps to rcm.payments table
// Fields: id, tenantId, claimId, eraId, paymentType, amountCents, paymentDate,
//         checkNumber, eftTraceNumber

PaymentPostingService.java (service/):
@Service @Transactional
// processEra(String edi835Raw, UUID payerId): EraProcessingResult
//   1. Parse EDI 835 via Edi835Parser
//   2. Create Era entity, check if already processed (idempotency check on checkNumber)
//   3. For each ClaimPaymentInfo:
//      a. Find matching Claim by external claim ID
//      b. If claim paid: create Payment record, call claim.adjudicate(allowedAmount, paidAmount)
//      c. If claim denied: call claim.deny(carcCode, rarcCode, denialReason)
//         Then: publish denial.received Kafka event (for rcm-rag to process)
//         Then: write CosmosDB event 'denial_received'
//      d. Create Payment record for the payment portion (even if $0)
//   4. Mark Era as processed (processedAt = now)
//   5. Return EraProcessingResult with counts: paid, denied, errors

// Comment on the publish-deny-CosmosDB sequence:
// "The order matters: 1) update Postgres (source of truth), 2) publish Kafka
// (triggers agent), 3) write CosmosDB (analytics). If Postgres fails, nothing
// else happens. If Kafka fails, the denial is recorded in Postgres but the
// agent isn't triggered — a human can manually trigger it. If CosmosDB fails,
// the analytics event is missed but the denial is still processed correctly."

PaymentController.java (api/):
// POST /v1/payments/eras — process ERA file
// GET /v1/payments/eras — list ERAs
// GET /v1/payments — list payments (filterable by claimId)

TESTS:
PaymentPostingServiceTest.java:
// - Paid claim line: Payment created, Claim status → PAID
// - Denied claim line: denial.received Kafka event published
// - Duplicate ERA: second processing skipped (idempotency)
// - ERA with mixed paid/denied lines: both handled correctly

OUTPUT: ~10 files. Each: // FILE: path // ===== END OF FILE =====
Full implementation with comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-042: rcm-core denials bounded context
# ============================================================
# GOAL: Denial management, Kafka consumers, appeal orchestration
# DEPENDS ON: PROMPT-031 PROMPT-035 PROMPT-022
# OUTPUT: ~12 Java files in rcm-core/denials/
# ACCEPTANCE CRITERIA:
#   1. DenialReceivedConsumer: idempotent (same denial message twice = no duplicate)
#   2. DenialExplainedConsumer: updates denial status when agent completes
#   3. AppealService: validates biller approval before resuming agent
#   4. DenialController: SSE endpoint for streaming denial status to UI
#   5. Appeal approval publishes denial.explained only after rcm-rag confirms
# ============================================================

PROMPT-042 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the denials bounded context for rcm-core.
This is the most complex bounded context — it spans Kafka consumers,
the LangGraph agent integration, and the human-in-the-loop approval flow.

PACKAGE: com.rcm.denials

FLOW (from sequence diagram PROMPT-010):
Phase A (rcm-core receives denial from payment processing):
1. PaymentPostingService publishes denial.received to Kafka
2. rcm-rag DenialExplanationFlow consumes it, runs agent
3. Agent reaches human_review INTERRUPT, saves state, notifies

Phase B (biller approves in UI):
4. Biller opens denial in rcm-ui, sees AI-drafted appeal
5. Biller edits and approves via DenialController
6. AppealService validates approval, saves approved text
7. rcm-core calls rcm-rag POST /v1/agent/resume/{runId}
8. rcm-rag agent finalizes, publishes denial.explained

Phase C (rcm-core receives completion):
9. DenialExplainedConsumer processes denial.explained
10. Updates denial status in Postgres

Denial.java (aggregate root — @Entity):
// State machine: RECEIVED → TRIAGED → AGENT_ANALYZING → APPEAL_DRAFTED
//                → HUMAN_REVIEW → APPEAL_SUBMITTED → RESOLVED | ESCALATED → CLOSED
// Business methods with precondition checks (same pattern as Claim)
// Key fields: claimId, carcCode, rarcCode, denialDate, status,
//             agentRunId (set when agent starts), explanation (set when agent completes)
// @FilterDef, @Filter for tenant isolation

AppealDraft.java (value object):
// Immutable record: draftText, approvedText, approvedBy, approvedAt
// Embedded in Denial entity

DenialRepository.java:
// findByClaimIdAndTenantId — for ERA processing
// findByStatusAndTenantId — for denial queue in UI
// findByAgentRunId — for agent completion lookup

AppealRepository.java:
// Separate entity for the appeal record (links to denial)
// Tracks: draftText, approvedText, approvedBy, submittedAt, outcome, usefulnessScore

DenialService.java:
@Service @Transactional
// getDenial(UUID id): Denial
// listDenials(DenialFilter, Pageable): Page<Denial>
// startAgentAnalysis(UUID denialId): Denial
//   Updates status to AGENT_ANALYZING, records agentRunId (generated UUID)
//   Comment: "We generate the agentRunId here in rcm-core and pass it to
//   rcm-rag. This gives us the run ID for resuming before rcm-rag processes it."

AppealService.java:
@Service @Transactional
// approveDraft(UUID denialId, String approvedText, UUID billerId): AppealDraft
//   1. Load denial, validate status == HUMAN_REVIEW
//      Comment: "Strict status check — only accept approval when in HUMAN_REVIEW.
//      If biller tries to approve a denial that's still AGENT_ANALYZING,
//      reject with 409 Conflict. Race conditions are handled: if the agent
//      is still running, status won't be HUMAN_REVIEW yet."
//   2. Update Appeal entity with approvedText, approvedBy, approvedAt
//   3. Update denial status to APPEAL_SUBMITTED
//   4. Call rcm-rag resume endpoint: POST /v1/agent/resume/{agentRunId}
//      Comment: "rcm-core calls rcm-rag synchronously here because we need
//      confirmation that the agent resumed before we return 200 to the biller.
//      Failure to resume is surfaced to the biller, not silently swallowed."
//   5. If rcm-rag call fails: rollback status change (transaction rollback)
//   6. Return updated AppealDraft

DenialReceivedConsumer.java (kafka/):
@Component @KafkaListener(topics = "denial.received", groupId = "rcm-core-denials")
// Idempotent: check if Denial already exists for this claimId + denialDate
// If exists: log and skip (don't create duplicate)
// If not: create Denial entity in RECEIVED status
// @KafkaHandler for DenialReceivedEvent schema
// Manual ack: ack.acknowledge() only after successful DB write
// Comment: "Manual acknowledgment ensures the message is only marked as
// processed after the Denial record is safely in Postgres. If the service
// crashes between consuming and Postgres write, the message is reprocessed
// on restart — hence the idempotency check at the start."

DenialExplainedConsumer.java (kafka/):
@Component @KafkaListener(topics = "denial.explained")
// Processes the completion notification from rcm-rag
// Updates denial status: APPEAL_SUBMITTED → RESOLVED or ESCALATED
// Records explanation text on the Denial entity
// Writes CosmosDB event 'appeal_submitted'

DenialController.java (api/):
@RestController @RequestMapping("/v1/denials")
// GET /v1/denials — list denial queue (paginated, filterable)
// GET /v1/denials/{id} — get denial with appeal draft
// POST /v1/denials/{id}/approve — approve appeal draft
//   Body: { approvedText: string }
//   Returns: 200 DenialResponse with updated status
//   Returns: 409 if not in HUMAN_REVIEW status
// POST /v1/agent/resume/{runId} — called internally by AppealService
//   (also exposed as REST for direct rcm-rag callback)

// SSE endpoint for denial status polling:
// GET /v1/denials/{id}/status-stream
//   SseEmitter that pushes status updates when denial status changes
//   Used by rcm-bff to stream progress to the biller's UI
//   Comment: "SSE rather than WebSocket because it's unidirectional:
//   server pushes updates to the client. WebSocket is bidirectional —
//   more complex for a one-way notification use case."

RagApiClient.java (service/ — REST client for rcm-rag):
@Component
// RestClient (Spring 6 RestClient, not deprecated RestTemplate) calling rcm-rag
// POST /v1/agent/resume/{runId}
// GET /v1/denial/{denialId}/status
// Resilience4j retry (2 attempts) for resume call

TESTS:
DenialTest.java — state machine tests
DenialServiceTest.java — unit tests with mocked deps
  // Verify idempotency: creating duplicate denial returns existing
DenialKafkaConsumerTest.java — Testcontainers Kafka integration test
  // Publish denial.received → verify Denial created in Postgres
  // Publish denial.received again (same payload) → verify no duplicate created

OUTPUT: ~12 files. Each: // FILE: path // ===== END OF FILE =====
Full implementation. Kafka consumers complete. Human-in-the-loop flow complete.
==========================================

# ============================================================
# PROMPT-043: rcm-core AR bounded context
# ============================================================
# GOAL: Accounts Receivable tracking and aging
# DEPENDS ON: PROMPT-031 PROMPT-035
# OUTPUT: ~8 Java files in rcm-core/ar/
# ACCEPTANCE CRITERIA:
#   1. AR aging reads from Postgres materialized view (not live query)
#   2. ArBalance updated whenever a claim changes status (via domain event)
#   3. Aging bucket calculated from service date, not claim creation date
#   4. ArController exposes aging report and balance list
# ============================================================

PROMPT-043 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the Accounts Receivable (AR) bounded context for rcm-core.

PACKAGE: com.rcm.ar

DOMAIN CONCEPTS:
AR tracks outstanding balances — what payers and patients owe the provider.
Aging: grouping balances by days outstanding (0-30, 31-60, 61-90, 91-120, 120+).
AR is a downstream concern — it reacts to claim status changes.

AgingBucket.java:
public enum AgingBucket {
    DAYS_0_30("0-30"), DAYS_31_60("31-60"), DAYS_61_90("61-90"),
    DAYS_91_120("91-120"), DAYS_120_PLUS("120+");
    // fromDays(long days): static factory from number of days outstanding
    // Comment: "Aging is calculated from the claim service date, not
    // the claim creation date or submission date. Service date is what
    // payers and auditors use as the starting point for aging calculations."
}

ArBalance.java (@Entity):
// Tracks outstanding balance per claim
// Updated via domain event listener when claim status changes
// Fields: id, tenantId, patientId, claimId, balanceCents, agingBucket,
//         lastFollowUpAt, createdAt, updatedAt
// @FilterDef, @Filter for tenant isolation

ArService.java:
@Service @Transactional(readOnly = true)
// getAgingReport(String tenantId, LocalDate asOf, UUID payerId): ArAgingReport
//   Reads from rcm.mv_ar_aging_buckets materialized view
//   Comment: "We read from the materialized view rather than the live table
//   because AR aging reports are complex aggregations. Running them on the
//   live transactional table would add significant load to the hot Postgres
//   instance. The materialized view is refreshed nightly — acceptable staleness
//   for an AR report used for billing operations."

// getArBalances(ArFilter, Pageable): Page<ArBalance>
// updateBalance(UUID claimId, int newBalanceCents): void
//   Called by domain event listeners when claims are paid or denied

@EventListener for ClaimPaidEvent:
//   Calculates patient responsibility, updates ArBalance
@EventListener for ClaimDeniedEvent:
//   Keeps balance at full charge amount, updates aging bucket

ArController.java:
@RestController @RequestMapping("/v1/ar")
// GET /v1/ar/aging — AR aging report (reads materialized view)
// GET /v1/ar/balances — list AR balances with filters

ArAgingReport.java (domain):
// Domain object (not entity): tenantId, asOf, buckets: Map<AgingBucket, BucketStats>
// BucketStats: claimCount, totalBalanceCents, avgBalanceCents, percentage

TESTS:
ArServiceTest.java:
// - Aging report reads from materialized view (mock JdbcTemplate)
// - Balance updated correctly on ClaimPaidEvent
// - AgingBucket.fromDays() calculates correctly for all ranges

OUTPUT: ~8 files. Each: // FILE: path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-044: rcm-core Dockerfile + logback config
# ============================================================
# GOAL: Production-grade Dockerfile + logback JSON configuration
# DEPENDS ON: PROMPT-031
# OUTPUT: rcm-core/Dockerfile
#         rcm-core/.dockerignore
#         rcm-core/app/src/main/resources/logback-spring.xml
# ACCEPTANCE CRITERIA:
#   1. Multi-stage Dockerfile: build stage (Gradle) + runtime stage (JRE only)
#   2. Runtime stage uses distroless or eclipse-temurin JRE 21 (not JDK)
#   3. JVM flags optimized for containers (heap sizing, GC, virtual threads)
#   4. logback-spring.xml outputs JSON in dev profile, structured JSON
#      with masking in prod profile
#   5. Log masking: SSN, phone numbers, email addresses replaced with [MASKED]
# ============================================================

PROMPT-044 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the Dockerfile and logging configuration for rcm-core.

Dockerfile (multi-stage):

Stage 1 — builder:
FROM gradle:8.9-jdk21 AS builder
WORKDIR /app
COPY build.gradle settings.gradle ./
COPY */build.gradle ./
# Copy each subproject's build.gradle in correct structure
# Copy source
COPY . .
# Generate protobuf before building
RUN gradle generateProto --no-daemon
# Build the fat JAR
RUN gradle :app:bootJar --no-daemon -x test
# Comment: "-x test skips tests during Docker build — tests run in CI
# before the Docker build step, so we don't need to run them again here.
# This keeps Docker build time fast."

Stage 2 — runtime:
FROM eclipse-temurin:21-jre-alpine AS runtime
# Comment: "JRE only (not JDK) — 3x smaller image, no compiler or tools
# that could be exploited in a compromised container. Alpine base is
# ~5MB vs ~200MB for full Debian. Trade-off: Alpine uses musl libc
# which can cause rare compatibility issues with native libraries."

WORKDIR /app

# Create non-root user for security
RUN addgroup -S rcm && adduser -S rcm -G rcm
# Comment: "Running as non-root is a security best practice. If the
# application is compromised, the attacker has limited system access.
# Kubernetes PSPs and OPA Gatekeeper policies often require non-root."

COPY --from=builder /app/app/build/libs/app-*.jar app.jar
USER rcm

# JVM flags for containerized deployment
# -XX:+UseContainerSupport: respect Docker CPU/memory limits (not host limits)
# -XX:MaxRAMPercentage=75.0: use 75% of container memory for heap
# -XX:+UseG1GC: G1 garbage collector (good balance of throughput and latency)
# -XX:+ExitOnOutOfMemoryError: crash and restart rather than degraded state
# --enable-preview: enable Java 21 preview features (virtual threads stabilized)
ENV JAVA_OPTS="-XX:+UseContainerSupport -XX:MaxRAMPercentage=75.0 \
    -XX:+UseG1GC -XX:+ExitOnOutOfMemoryError \
    -Djava.security.egd=file:/dev/./urandom"

EXPOSE 8090
HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
    CMD wget -q -O- http://localhost:8090/actuator/health || exit 1

ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]

.dockerignore:
.gradle/, build/, .git/, .gitignore, *.md, Dockerfile,
**/.dockerignore, **/node_modules

logback-spring.xml:
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <!-- Active profile determines log format:
         dev: human-readable with color (easier to read in terminal)
         prod: JSON (machine-parseable, shipped to Loki)
         test: minimal output -->

    <!-- PHI Masking Converter: replaces sensitive patterns with [MASKED]
         Patterns: SSN (###-##-####), phone (10+ digits), email
         Comment: "Masking in the logging layer ensures PHI never appears
         in log files even if a developer accidentally logs a patient object.
         This is defense in depth — the application code should never log PHI,
         but masking catches mistakes." -->

    <springProfile name="dev">
        <!-- Console appender with color and human-readable format -->
        <!-- Pattern: timestamp | level | traceId | tenantId | logger | message -->
        <!-- Include trace ID from OTel for correlating with Tempo -->
    </springProfile>

    <springProfile name="prod,default">
        <!-- JSON appender using logstash-logback-encoder -->
        <!-- Fields: timestamp, level, logger, message, tenantId (from MDC),
             traceId (from OTel MDC), spanId, requestId, exception -->
        <!-- PHI masking converter applied -->
        <!-- Async appender: buffer=512, neverBlock=true to prevent logging
             from blocking request processing -->
    </springProfile>

    <springProfile name="test">
        <!-- Minimal console output — less noise during test runs -->
        <root level="WARN">
            <appender-ref ref="CONSOLE"/>
        </root>
        <logger name="com.rcm" level="ERROR"/>
    </springProfile>

    <!-- MDC setup: automatically populated from TenantFilter and JwtAuthFilter:
         tenantId, userId, requestId, traceId, spanId -->
</configuration>

OUTPUT: 3 files.
// FILE: rcm-core/Dockerfile
// FILE: rcm-core/.dockerignore
// FILE: rcm-core/app/src/main/resources/logback-spring.xml
Each ends with // ===== END OF FILE =====
Full working Dockerfile. Complete logback configuration with masking.
==========================================

# ============================================================
# PROMPT-045: rcm-core Integration Tests + Pact Consumer Tests
# ============================================================
# GOAL: Testcontainers integration test suite + Pact consumer tests
# DEPENDS ON: PROMPT-036 through PROMPT-044
# OUTPUT: ~5 Java test files
# ACCEPTANCE CRITERIA:
#   1. RcmCoreApplicationTest: full Spring context smoke test
#   2. ClaimScrubFlowIntegrationTest: end-to-end with mock gRPC server
#   3. DenialKafkaFlowIntegrationTest: Kafka consumer + Postgres
#   4. EligibilityCacheFlowIntegrationTest: Redis cache hit/miss with Testcontainers
#   5. RcmCorePactConsumerTest: Pact contract for rcm-bff → rcm-core
# ============================================================

PROMPT-045 CONTEXT — paste this into DeepSeek:
==========================================
You are generating integration tests for rcm-core using Testcontainers
and Pact contract testing.

TESTING STRATEGY:
- Unit tests: in each bounded context module (already generated)
- Integration tests: in app module, use Testcontainers for real infrastructure
- Pact tests: consumer-driven contract tests for the rcm-bff → rcm-core boundary

SHARED TEST INFRASTRUCTURE (AbstractIntegrationTest.java):
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Testcontainers
@ActiveProfiles("test")
public abstract class AbstractIntegrationTest {
    // Shared Testcontainers (static = started once per test class JVM):
    @Container static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:16.4-alpine")
        .withInitScript("db/init-test.sql") // applies pgvector extension
    @Container static KafkaContainer kafka = new KafkaContainer(...)
    @Container static GenericContainer<?> redis = new GenericContainer<>("redis:7.2.5-alpine")
    @Container static MongoDBContainer mongo = new MongoDBContainer("mongo:7.0.14")

    // @DynamicPropertySource: override Spring config with container addresses
    // Comment: "DynamicPropertySource is Spring Boot 2.7+ way of injecting
    // Testcontainer connection URLs into Spring context. Replaces the older
    // @TestPropertySource approach which required knowing ports in advance."

    @Autowired WebTestClient webTestClient; // for REST calls in tests
    @Autowired JdbcTemplate jdbcTemplate;   // for test data setup/verification
}

RcmCoreApplicationTest.java:
@SpringBootTest
// Smoke test — does the application context load without errors?
// Comment: "Context load test catches configuration errors, circular
// dependencies, and missing beans. Should be the first test to run.
// Failing this test means no other tests will work."
@Test void contextLoads() {}

ClaimScrubFlowIntegrationTest.java:
// extends AbstractIntegrationTest
// Setup: seed tenant, payer, patient, encounter, claim in Postgres
// Mock gRPC server (grpc-testing InProcessServer) for rcm-rag

// @Test testScrubClaimHappyPath():
//   Given: claim in DRAFT status, mock gRPC returns PASS
//   When: POST /v1/claims/{id}/scrub
//   Then: 200 OK, response.passed == true
//         claim status in DB == SCRUBBED
//         CosmosDB event 'scrub_passed' written (mock CosmosDB client)

// @Test testScrubClaimWithCircuitBreakerOpen():
//   Given: gRPC server unavailable (InProcessServer not started)
//   When: POST /v1/claims/{id}/scrub (multiple times to open circuit)
//   Then: returns 200 with fallback result (passed=true, warning in issues)
//         circuit breaker state == OPEN
//         Prometheus metric resilience4j_circuitbreaker_state == OPEN

DenialKafkaFlowIntegrationTest.java:
// extends AbstractIntegrationTest
// Tests the Kafka consumer for denial.received topic

// @Test testDenialReceivedConsumer():
//   Given: claim exists in Postgres
//   When: publish denial.received event to Kafka
//   Then: DenialReceivedConsumer processes message
//         Denial record created in Postgres with status RECEIVED
//         Kafka offset committed (manual ack worked)

// @Test testDenialReceivedIdempotency():
//   Given: denial.received published twice for same claimId+denialDate
//   When: both messages consumed
//   Then: only ONE Denial record in Postgres (second message skipped)

EligibilityCacheFlowIntegrationTest.java:
// extends AbstractIntegrationTest (adds Redis container)
// Tests the Redis L2 cache for eligibility

// @Test testEligibilityCacheHitAndMiss():
//   Given: patient and payer in Postgres
//   When: POST /v1/eligibility/verify (first call — cache miss)
//   Then: response returned, EligibilityResponse stored in Postgres AND Redis
//   When: POST /v1/eligibility/verify (same request — cache hit)
//   Then: same response returned, NO additional Postgres row created
//         Redis hit counter incremented

RcmCorePactConsumerTest.java (in rcm-bff module — references rcm-core):
// Pact consumer test: rcm-bff is the consumer, rcm-core is the provider
// Generates pact files that rcm-core's provider test will verify

// @Pact(consumer = "rcm-bff", provider = "rcm-core")
// getPatientsContract(PactDslWithProvider builder): RequestResponsePact

// @Pact getClaimContract(...)
// @Pact scrubClaimContract(...)
// @Pact listDenialsContract(...)

// Comment: "Consumer-driven contracts: the consumer (rcm-bff) defines what
// it needs from the provider (rcm-core). The provider then proves it can
// satisfy those needs. This catches breaking API changes at contract test
// time — before they reach production. In a polyglot system (TypeScript BFF,
// Java provider), shared types don't exist — Pact is the only automated
// safety net."

OUTPUT: 5 test files.
// FILE: rcm-core/app/src/test/java/com/rcm/AbstractIntegrationTest.java
// FILE: rcm-core/app/src/test/java/com/rcm/RcmCoreApplicationTest.java
// FILE: rcm-core/app/src/test/java/com/rcm/ClaimScrubFlowIntegrationTest.java
// FILE: rcm-core/app/src/test/java/com/rcm/DenialKafkaFlowIntegrationTest.java
// FILE: rcm-core/app/src/test/java/com/rcm/EligibilityCacheFlowIntegrationTest.java
Each ends with // ===== END OF FILE =====
Complete test code. All assertions meaningful.
Testcontainers configuration correct (static containers for performance).
==========================================
