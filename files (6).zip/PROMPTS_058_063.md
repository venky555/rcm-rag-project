# BATCH C3 — Prompts 058–063
# rcm-notify (Express/Node.js) + rcm-bff (Apollo/GraphQL/Node.js)
# GUIDED LATITUDE throughout.
# Every non-trivial line must have an inline comment explaining intent.
# ============================================================

# ============================================================
# PROMPT-058: rcm-notify scaffold — package.json + entry point + common layer
# ============================================================
# GOAL: Full scaffold for the notification service
# DEPENDS ON: PROMPT-004 PROMPT-025
# OUTPUT: rcm-notify/package.json
#         rcm-notify/tsconfig.json
#         rcm-notify/src/index.ts
#         rcm-notify/src/config.ts
#         rcm-notify/src/common/auth.ts
#         rcm-notify/src/common/multitenancy.ts
#         rcm-notify/src/common/observability.ts
#         rcm-notify/src/common/errors.ts
# ACCEPTANCE CRITERIA:
#   1. package.json lists ALL deps from 03_PINNED_TECH_STACK.md exactly
#   2. index.ts starts both Express (health only) and KafkaJS consumer
#   3. Graceful shutdown: SIGTERM drains in-flight Kafka messages
#   4. pino JSON logging with tenant context
#   5. OTel auto-instrumentation for Express and KafkaJS
# ============================================================

PROMPT-058 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the scaffold for rcm-notify, the Node.js (TypeScript)
notification service. Its primary job is consuming Kafka events and
dispatching notifications via email, SMS, and webhook.

ARCHITECTURE CONTEXT:
rcm-notify is almost entirely Kafka-driven. The Express server exists only
for the health endpoint scraped by Prometheus and called by docker-compose
health checks. All business logic lives in Kafka consumers and notification channels.

PINNED VERSIONS (exact):
Node.js: 20.x LTS, TypeScript: 5.5.4, Express: 4.19.2,
KafkaJS: 2.2.4, Nodemailer: 6.9.14, Handlebars: 4.7.8,
pg: 8.12.0, @opentelemetry/sdk-node: 0.53.0,
@opentelemetry/auto-instrumentations-node: 0.49.1,
prom-client: 15.1.3, pino: 9.4.0, pino-pretty: 11.2.2,
jose: 5.6.3, zod: 3.23.8, tsx: 4.19.1, vitest: 2.0.5,
testcontainers: 10.10.4

package.json:
{
  "name": "rcm-notify",
  "version": "0.1.0",
  "engines": { "node": ">=20.0.0" },
  "scripts": {
    "start": "node dist/index.js",
    "dev": "tsx watch src/index.ts",
    "build": "tsc --project tsconfig.json",
    "test": "vitest run",
    "test:integration": "vitest run tests/integration",
    "lint": "eslint src --ext .ts",
    "typecheck": "tsc --noEmit"
  },
  // all dependencies with exact pinned versions
}

tsconfig.json:
{
  "compilerOptions": {
    "target": "ES2022",         // Node.js 20 supports ES2022 natively
    "module": "NodeNext",       // proper ESM/CJS interop for Node.js 20
    "moduleResolution": "NodeNext",
    "outDir": "dist",
    "rootDir": "src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "declaration": true
  }
}

config.ts:
// Configuration loaded from environment variables at startup.
// No secrets hardcoded — any missing required config causes immediate exit.

import { z } from 'zod';

// Comment: "Zod schema validation at startup ensures all required config
// is present before the service begins consuming Kafka messages.
// A missing SMTP config discovered on first notification attempt would
// cause silent failures — discovering it at startup is better."
const configSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  LOG_LEVEL: z.enum(['trace', 'debug', 'info', 'warn', 'error']).default('info'),
  HTTP_PORT: z.coerce.number().default(8092),

  // Kafka
  KAFKA_BOOTSTRAP_SERVERS: z.string(),
  KAFKA_GROUP_ID: z.string().default('rcm-notify'),

  // PostgreSQL (notification_log table)
  POSTGRES_URL: z.string(),

  // Email (SMTP)
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  SMTP_FROM: z.string().default('noreply@rcm-platform.example.com'),

  // SMS (Twilio stub)
  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  TWILIO_FROM_NUMBER: z.string().optional(),

  // Security
  KEYCLOAK_JWKS_URI: z.string(),

  // Observability
  OTLP_ENDPOINT: z.string().default('http://tempo:4317'),
});

const parsed = configSchema.safeParse(process.env);
if (!parsed.success) {
  console.error('Configuration validation failed:', parsed.error.format());
  process.exit(1);  // Fail fast on missing config
}
export const config = parsed.data;

src/index.ts:
import 'reflect-metadata';
// OTel must be initialized BEFORE any other imports
// Comment: "Auto-instrumentation patches Node.js built-ins and popular libraries
// (Express, http, pg, kafkajs) at import time. If OTel is initialized after
// these modules are imported, the patches don't apply and traces are lost.
// This is why OTel initialization must be the very first import."
import { initOtel } from './common/observability';
initOtel();

import express from 'express';
import { createServer } from 'http';
import { startKafkaConsumer, stopKafkaConsumer } from './kafka/consumer';
import { healthRouter } from './api/router';
import { logger } from './common/observability';

const app = express();
app.use(express.json());
app.use('/health', healthRouter);

const server = createServer(app);

async function main() {
  // Start Kafka consumer (primary function of this service)
  await startKafkaConsumer();
  logger.info({ port: config.HTTP_PORT }, 'rcm-notify started');

  // Start HTTP server (health endpoint only)
  server.listen(config.HTTP_PORT);
}

// Graceful shutdown — critical for Kafka consumers
// Comment: "SIGTERM is sent by Docker/Kubernetes when stopping a container.
// Without graceful shutdown, the Kafka consumer is stopped abruptly:
// in-flight messages may be reprocessed on restart (at-least-once delivery).
// Graceful shutdown ensures current message processing completes before exit."
async function shutdown(signal: string) {
  logger.info({ signal }, 'Shutting down gracefully');
  await stopKafkaConsumer();  // finish current message, stop polling
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
  // Force exit after 30s if graceful shutdown hangs
  setTimeout(() => process.exit(1), 30_000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
main().catch(err => { logger.error({ err }, 'Startup failed'); process.exit(1); });

common/observability.ts:
// OpenTelemetry and pino structured logging setup.

import { NodeSDK } from '@opentelemetry/sdk-node';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-grpc';
import pino from 'pino';
import { register as prometheusRegister } from 'prom-client';

export function initOtel(): void {
  const sdk = new NodeSDK({
    traceExporter: new OTLPTraceExporter({ url: config.OTLP_ENDPOINT }),
    instrumentations: [getNodeAutoInstrumentations({
      // Comment: "Disable fs instrumentation — it creates too much noise.
      // Every file read (templates, config) would generate a span, making
      // the trace unreadable. Keep HTTP, gRPC, pg, and kafkajs."
      '@opentelemetry/instrumentation-fs': { enabled: false },
    })],
  });
  sdk.start();
}

export const logger = pino({
  level: config.LOG_LEVEL,
  // JSON in prod, pretty in dev
  transport: config.NODE_ENV === 'development'
    ? { target: 'pino-pretty', options: { colorize: true } }
    : undefined,
});

// Prometheus metrics
export { prometheusRegister };
export const notificationsSentCounter = new (require('prom-client').Counter)({
  name: 'notifications_sent_total',
  help: 'Total notifications sent by channel and type',
  labelNames: ['channel', 'notification_type'],
});

common/auth.ts:
// JWT validation middleware for the health endpoint and any admin routes.
import { createRemoteJWKSet, jwtVerify } from 'jose';

export async function verifyJwt(token: string): Promise<Record<string, unknown>> {
  // Comment: "jose library handles RS256 JWT verification against Keycloak JWKS.
  // JWKS is fetched and cached automatically by createRemoteJWKSet.
  // We use jose (not jsonwebtoken) because it natively supports remote JWKS
  // and RS256 asymmetric verification without manual key management."
  const JWKS = createRemoteJWKSet(new URL(config.KEYCLOAK_JWKS_URI));
  const { payload } = await jwtVerify(token, JWKS, {
    issuer: config.KEYCLOAK_ISSUER,
  });
  return payload as Record<string, unknown>;
}

common/multitenancy.ts:
// Tenant context using AsyncLocalStorage (Node.js async context propagation).
import { AsyncLocalStorage } from 'async_hooks';

// Comment: "AsyncLocalStorage is Node.js's equivalent of Python's ContextVar
// and Java's ThreadLocal — but designed for async code. It propagates context
// through async callbacks, Promises, and async/await without explicit passing.
// Critical: Kafka message handlers run in async contexts — AsyncLocalStorage
// ensures tenant_id is available throughout the async call chain."
const tenantStorage = new AsyncLocalStorage<string>();

export const setTenant = (tenantId: string, fn: () => Promise<void>) =>
  tenantStorage.run(tenantId, fn);
// Comment: "We wrap the handler in the storage context rather than setting
// a global. This ensures concurrent Kafka message handlers (different tenants)
// don't interfere with each other's tenant context."

export const getTenant = (): string => {
  const id = tenantStorage.getStore();
  if (!id) throw new Error('Tenant context not set');
  return id;
};

common/errors.ts:
// Error types and handler for rcm-notify.
export class NotificationError extends Error {
  constructor(
    message: string,
    public readonly channel: string,
    public readonly retryable: boolean,
  ) { super(message); }
}

OUTPUT: 8 files.
// FILE: rcm-notify/package.json
// FILE: rcm-notify/tsconfig.json
// FILE: rcm-notify/src/index.ts
// FILE: rcm-notify/src/config.ts
// FILE: rcm-notify/src/common/auth.ts
// FILE: rcm-notify/src/common/multitenancy.ts
// FILE: rcm-notify/src/common/observability.ts
// FILE: rcm-notify/src/common/errors.ts
Each ends with // ===== END OF FILE =====
Full TypeScript implementation. Graceful shutdown complete.
==========================================

# ============================================================
# PROMPT-059: rcm-notify — Kafka consumer + handlers + channels + templates + tests
# ============================================================
# GOAL: Complete notification dispatch logic
# DEPENDS ON: PROMPT-058 PROMPT-022
# OUTPUT: ~15 files across kafka/, channels/, templates/, db/, api/, tests/
# ACCEPTANCE CRITERIA:
#   1. KafkaJS consumer uses eachMessage (not eachBatch) for per-message control
#   2. Each handler wraps in tenant context before any processing
#   3. EmailChannel uses Nodemailer with Handlebars templates
#   4. Failed notifications logged to notification_log with error status
#   5. Handlebars templates are realistic RCM notification content
# ============================================================

PROMPT-059 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the Kafka consumer, notification handlers, channels,
templates, and database layer for rcm-notify.

kafka/consumer.ts:
import { Kafka, Consumer, EachMessagePayload } from 'kafkajs';

let consumer: Consumer;

export async function startKafkaConsumer(): Promise<void> {
  const kafka = new Kafka({
    clientId: 'rcm-notify',
    brokers: config.KAFKA_BOOTSTRAP_SERVERS.split(','),
    // Comment: "retry configuration is critical for production Kafka clients.
    // Without retry, a transient broker unavailability would crash the consumer.
    // initialRetryTime=100ms, retries=8 gives exponential backoff up to ~25s."
    retry: { initialRetryTime: 100, retries: 8 },
  });

  consumer = kafka.consumer({
    groupId: config.KAFKA_GROUP_ID,
    // Comment: "sessionTimeout=30s means Kafka waits 30s before considering
    // this consumer dead and rebalancing. Should be > max message processing time.
    // heartbeatInterval=3s: how often we tell Kafka we're alive."
    sessionTimeout: 30_000,
    heartbeatInterval: 3_000,
  });

  await consumer.connect();
  await consumer.subscribe({
    topics: ['claim.submitted', 'denial.received', 'denial.explained'],
    fromBeginning: false,  // Don't reprocess old messages on restart
  });

  await consumer.run({
    // Comment: "eachMessage processes one message at a time with autoCommit.
    // autoCommit=false (set below) means we control offset commits.
    // We commit after successful processing — if processing fails,
    // the offset is not committed and the message is reprocessed on restart."
    autoCommit: false,
    eachMessage: async (payload: EachMessagePayload) => {
      await handleMessage(payload);
      // Manual commit after successful handling
      await consumer.commitOffsets([{
        topic: payload.topic,
        partition: payload.partition,
        offset: (BigInt(payload.message.offset) + 1n).toString(),
      }]);
    },
  });
}

async function handleMessage({ topic, message }: EachMessagePayload): Promise<void> {
  const event = JSON.parse(message.value?.toString() || '{}');
  const tenantId = event.tenantId || message.headers?.tenantId?.toString();

  // Wrap in tenant context
  await setTenant(tenantId, async () => {
    switch (topic) {
      case 'claim.submitted':
        await claimSubmittedHandler(event); break;
      case 'denial.received':
        await denialReceivedHandler(event); break;
      case 'denial.explained':
        await denialExplainedHandler(event); break;
    }
  });
}

export async function stopKafkaConsumer(): Promise<void> {
  await consumer?.disconnect();
}

kafka/handlers/claimSubmittedHandler.ts:
// Sends claim submission confirmation to the billing provider.
export async function claimSubmittedHandler(event: ClaimSubmittedEvent): Promise<void> {
  const notification = {
    type: 'claim_submitted' as const,
    recipientId: event.providerId,
    channel: 'email' as const,
    templateId: 'claim-submitted',
    templateData: {
      claimId: event.claimId,
      claimType: event.claimType,
      totalCharge: (event.totalChargeCents / 100).toFixed(2),
      submittedAt: event.submittedAt,
    },
  };
  await emailChannel.send(notification);
  await logNotification(notification, 'sent');
}

kafka/handlers/denialReceivedHandler.ts:
// Alerts biller when a claim is denied — prompts action.
export async function denialReceivedHandler(event: DenialReceivedEvent): Promise<void> {
  // Email to biller with denial details
  // Comment: "No PHI in the Kafka event (see PROMPT-022 design decision).
  // The email contains only claim ID and CARC code — the biller clicks
  // through to the application to see full details with PHI."
  ...

kafka/handlers/denialExplainedHandler.ts:
// Notifies biller when AI appeal draft is ready for review.
export async function denialExplainedHandler(event: DenialExplainedEvent): Promise<void> {
  if (event.outcomeType === 'appeal_drafted') {
    // Send "Appeal ready for review" notification
    // High priority — biller needs to act before payer deadline
    ...
  } else if (event.outcomeType === 'escalated') {
    // Send escalation alert to supervisor
    ...
  }
}

channels/email.ts:
import nodemailer from 'nodemailer';
import Handlebars from 'handlebars';
import { readFileSync } from 'fs';
import { join } from 'path';

const transporter = nodemailer.createTransport({
  host: config.SMTP_HOST,
  port: config.SMTP_PORT,
  auth: { user: config.SMTP_USER, pass: config.SMTP_PASS },
  // Comment: "secure=false + STARTTLS (port 587) is standard SMTP.
  // secure=true (port 465) uses SMTPS (older, less common).
  // In prod: always use TLS for email containing claim IDs."
  secure: false,
  requireTLS: true,
});

const templateCache = new Map<string, HandlebarsTemplateDelegate>();

function loadTemplate(name: string): HandlebarsTemplateDelegate {
  if (!templateCache.has(name)) {
    const path = join(__dirname, '../templates', `${name}.hbs`);
    const source = readFileSync(path, 'utf-8');
    templateCache.set(name, Handlebars.compile(source));
    // Comment: "Template caching: parse Handlebars template once at first use,
    // cache the compiled function. Subsequent sends use the cached function
    // without re-parsing. Handlebars compilation is CPU-intensive — caching
    // avoids re-parsing on every notification sent."
  }
  return templateCache.get(name)!;
}

export const emailChannel = {
  async send(notification: EmailNotification): Promise<void> {
    const template = loadTemplate(notification.templateId);
    const html = template(notification.templateData);
    await transporter.sendMail({
      from: config.SMTP_FROM,
      to: notification.recipientEmail,
      subject: notification.subject,
      html,
    });
    notificationsSentCounter.labels('email', notification.type).inc();
  }
};

channels/sms.ts:
// Twilio SMS stub — logs in dev, sends in prod with Twilio credentials.
export const smsChannel = {
  async send(notification: SmsNotification): Promise<void> {
    if (!config.TWILIO_ACCOUNT_SID) {
      logger.warn('SMS not configured — logging notification instead');
      logger.info({ notification }, 'SMS notification (stub)');
      return;
    }
    // Real Twilio call in prod
    // Comment: "Twilio REST API called directly without SDK to minimize
    // dependencies. The SDK is 15MB+ — using fetch() keeps the image lean."
    ...
  }
};

channels/webhook.ts:
// Outbound HTTP webhook delivery for EHR system integrations.
export const webhookChannel = {
  async send(notification: WebhookNotification): Promise<void> {
    // POST to configured webhook URL with HMAC-SHA256 signature
    // Comment: "HMAC signature allows the receiver to verify the webhook
    // came from us. The secret is shared during integration setup.
    // Without signature verification, anyone could spoof our webhooks."
    ...
  }
};

templates/claim-submitted.hbs:
<!-- Claim submission confirmation email template -->
<html>
<body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
  <h2 style="color: #2c5282;">Claim Submitted Successfully</h2>
  <p>Your claim has been submitted to the clearinghouse for processing.</p>
  <table style="width: 100%; border-collapse: collapse;">
    <tr><td style="padding: 8px; font-weight: bold;">Claim ID:</td>
        <td style="padding: 8px;">{{claimId}}</td></tr>
    <tr><td style="padding: 8px; font-weight: bold;">Claim Type:</td>
        <td style="padding: 8px;">{{claimType}}</td></tr>
    <tr><td style="padding: 8px; font-weight: bold;">Total Charge:</td>
        <td style="padding: 8px;">${{totalCharge}}</td></tr>
    <tr><td style="padding: 8px; font-weight: bold;">Submitted At:</td>
        <td style="padding: 8px;">{{submittedAt}}</td></tr>
  </table>
  <p style="color: #718096; font-size: 12px;">
    Log in to the RCM platform to track claim status.
    <br>This message does not contain patient information.
  </p>
</body>
</html>

templates/denial-received.hbs:
<!-- Denial alert email template -->
Realistic HTML email notifying biller of denial with CARC code and action required.
Include link placeholder to denial review screen.
Include urgency note about appeal deadlines (typically 90-180 days).

templates/appeal-ready-for-review.hbs:
<!-- Appeal ready for biller review -->
Realistic HTML email notifying biller that AI has drafted an appeal.
Include call-to-action button linking to denial review screen.
Include appeal deadline reminder.

db/postgres.ts:
// Postgres client for writing notification_log entries.
import { Pool } from 'pg';

const pool = new Pool({ connectionString: config.POSTGRES_URL });

// Create notification_log table if not exists (rcm-core creates it via Flyway,
// but rcm-notify needs it writable)
// Comment: "rcm-notify has its own Postgres connection for writing notification_log.
// We don't reuse rcm-core's connection pool — services have separate credentials
// with different permissions (write to notification_log only, not to rcm schema)."

export async function logNotification(
  notification: object, status: 'sent' | 'failed', error?: string
): Promise<void> {
  await pool.query(
    `INSERT INTO rcm.notification_log
     (id, tenant_id, notification_type, channel, recipient_id,
      status, error_message, sent_at, created_at)
     VALUES (gen_random_uuid(), $1, $2, $3, $4, $5, $6,
             NOW(), NOW())`,
    [getTenant(), notification.type, notification.channel,
     notification.recipientId, status, error || null]
  );
}

api/router.ts + api/health.ts:
// Health endpoint only — rcm-notify is primarily Kafka-driven
GET /health: returns { status: 'healthy', kafka: connected, smtp: configured }
GET /metrics: Prometheus metrics (mounted separately)

TESTS:
tests/unit/channels.test.ts:
// Mock nodemailer transporter
// Verify: template rendered correctly, sendMail called with correct args
// Verify: SMS stub logs when not configured
// Verify: webhook includes HMAC signature header

tests/unit/handlers.test.ts:
// Verify: claimSubmittedHandler calls emailChannel.send with correct data
// Verify: denialReceivedHandler formats CARC code correctly
// Verify: denialExplainedHandler sends correct template for each outcomeType
// Verify: notification logged to DB in all cases

tests/integration/kafka.integration.test.ts:
// Testcontainers Kafka
// Publish claim.submitted to topic
// Verify: consumer picks up, email attempted (mock nodemailer)
// Verify: notification_log entry written to DB

OUTPUT: ~15 files across rcm-notify/src/
Each: // FILE: path // ===== END OF FILE =====
Full TypeScript implementation. Handlebars templates realistic and complete.
==========================================

# ============================================================
# PROMPT-060: rcm-bff scaffold — package.json + Apollo Server + common layer
# ============================================================
# GOAL: Full scaffold for the BFF GraphQL service
# DEPENDS ON: PROMPT-004 PROMPT-018 PROMPT-025
# OUTPUT: 7 files — package.json + tsconfig + index.ts + config.ts + common layer
# ACCEPTANCE CRITERIA:
#   1. Apollo Server 4 configured with Express integration
#   2. DataLoader factory created per-request (not shared — prevents cross-request caching)
#   3. GraphQL context carries: tenant_id, user_id, dataloaders, datasources
#   4. Introspection disabled in production
#   5. Apollo Studio integration disabled (no telemetry to Apollo)
# ============================================================

PROMPT-060 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the scaffold for rcm-bff, the Node.js BFF service
using Apollo Server 4 with Express. This service aggregates data from
rcm-core and rcm-rag and exposes it via GraphQL to the Next.js UI.

ARCHITECTURE CONTEXT:
The BFF owns the GraphQL schema and resolvers. It calls rcm-core via REST
and rcm-rag via REST for status/polling endpoints. All data aggregation
happens here — the UI makes one GraphQL query instead of multiple REST calls.

PINNED VERSIONS (from 03_PINNED_TECH_STACK.md):
Express: 4.19.2, @apollo/server: 4.11.0, graphql: 16.9.0,
@graphql-tools/merge: 9.0.5, dataloader: 2.2.2, axios: 1.7.7,
pg: 8.12.0, pino: 9.4.0, jose: 5.6.3, zod: 3.23.8,
@pact-foundation/pact: 13.1.4, vitest: 2.0.5

src/index.ts:
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import express from 'express';
import { typeDefs } from './schema';
import { resolvers } from './resolvers';
import { createContext } from './common/context';

const app = express();
app.use(express.json());

const server = new ApolloServer({
  typeDefs,
  resolvers,
  // Comment: "introspection disabled in production prevents exposing the
  // full schema to potential attackers. The schema is a roadmap to all
  // available data — disable it in environments where it shouldn't be browsed."
  introspection: config.NODE_ENV !== 'production',

  // Comment: "Apollo Studio telemetry disabled — we don't want query shapes
  // and usage statistics sent to Apollo's servers. In a healthcare system,
  // even anonymized query patterns could reveal sensitive information."
  apollo: { key: undefined },

  // Custom error formatting — don't leak stack traces to clients
  formatError: (formattedError, error) => {
    logger.error({ error }, 'GraphQL error');
    // In prod: return generic message; in dev: include details
    if (config.NODE_ENV === 'production') {
      return { message: formattedError.message, extensions: { code: formattedError.extensions?.code } };
    }
    return formattedError;
  },
});

await server.start();

app.use('/graphql', expressMiddleware(server, {
  context: async ({ req }) => createContext(req),
  // Comment: "createContext runs on every request and builds the context object
  // passed to all resolvers. It validates the JWT, extracts tenant_id, and
  // creates fresh DataLoader instances (per-request, not shared)."
}));

// SSE endpoint (not via GraphQL — plain Express for streaming)
import { sseRouter } from './api/sse';
app.use('/sse', sseRouter);

common/context.ts:
// GraphQL context created per request.
import { DataLoader } from './common/dataloader';
import { RcmCoreApi } from './dataSources/RcmCoreApi';
import { RcmRagApi } from './dataSources/RcmRagApi';
import { verifyJwt } from './common/auth';
import { Pool } from 'pg';

export interface GraphQLContext {
  tenantId: string;
  userId: string;
  dataloaders: ReturnType<typeof createDataloaders>;
  rcmCore: RcmCoreApi;
  rcmRag: RcmRagApi;
  pgPool: Pool;
}

export async function createContext(req: express.Request): Promise<GraphQLContext> {
  // 1. Extract and validate JWT
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) throw new GraphQLError('Unauthorized', { extensions: { code: 'UNAUTHORIZED' }});
  const claims = await verifyJwt(token);

  const tenantId = claims.tenant_id as string;
  const userId = claims.sub as string;

  // 2. Create per-request DataLoaders
  // Comment: "DataLoaders MUST be created per-request, not shared across requests.
  // A shared DataLoader would cache data from one user's request and serve it
  // to another user's request — a data isolation failure.
  // Per-request DataLoaders are safe because they're discarded after the request."
  const dataloaders = createDataloaders(tenantId, new RcmCoreApi(tenantId, token));

  return {
    tenantId,
    userId,
    dataloaders,
    rcmCore: new RcmCoreApi(tenantId, token),
    rcmRag: new RcmRagApi(tenantId, token),
    pgPool: getPool(),
  };
}

common/dataloader.ts:
import DataLoader from 'dataloader';
import { RcmCoreApi } from '../dataSources/RcmCoreApi';

// Comment: "DataLoader batches and caches requests within a single GraphQL request.
// Without DataLoader, resolving a list of 20 claims where each claim needs payer data
// would make 20 separate REST calls to rcm-core (the N+1 problem).
// DataLoader batches those 20 calls into one batched request."

export function createDataloaders(tenantId: string, api: RcmCoreApi) {
  return {
    patientLoader: new DataLoader(async (patientIds: readonly string[]) => {
      // Batch fetch patients by IDs in a single API call
      const patients = await api.getPatientsByIds([...patientIds]);
      // Map back in order (DataLoader requires same-length same-order results)
      // Comment: "DataLoader requires the returned array to be the same length
      // and in the same order as the input keys. If a patient is not found,
      // we return null for that position. This is a subtle contract that's
      // easy to violate — a mismatch causes silent incorrect data."
      return patientIds.map(id => patients.find(p => p.id === id) || null);
    }),

    claimLoader: new DataLoader<string, Claim | null>(async (claimIds) => {
      const claims = await api.getClaimsByIds([...claimIds]);
      return claimIds.map(id => claims.find(c => c.id === id) || null);
    }),

    payerLoader: new DataLoader<string, Payer | null>(async (payerIds) => {
      const payers = await api.getPayersByIds([...payerIds]);
      return payerIds.map(id => payers.find(p => p.id === id) || null);
    }),
  };
}

OUTPUT: 7 files.
// FILE: rcm-bff/package.json
// FILE: rcm-bff/tsconfig.json
// FILE: rcm-bff/src/index.ts
// FILE: rcm-bff/src/config.ts
// FILE: rcm-bff/src/common/auth.ts
// FILE: rcm-bff/src/common/context.ts
// FILE: rcm-bff/src/common/dataloader.ts
Each ends with // ===== END OF FILE =====
Full TypeScript implementation. Apollo Server 4 wiring complete.
==========================================

# ============================================================
# PROMPT-061: rcm-bff — GraphQL schema + all resolvers
# ============================================================
# GOAL: All 6 GraphQL type definition files + schema index + all 6 resolvers
# DEPENDS ON: PROMPT-060 PROMPT-018
# OUTPUT: ~14 files
# ACCEPTANCE CRITERIA:
#   1. Schema files match the GraphQL SDL from PROMPT-018 exactly
#   2. All resolvers use DataLoader for nested entity fetching (no N+1)
#   3. Relay cursor-based pagination implemented consistently
#   4. Resolver error handling maps REST errors to GraphQL errors
#   5. All monetary fields return Int (cents) — no Float
# ============================================================

PROMPT-061 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the GraphQL schema and resolvers for rcm-bff.

SCHEMA FILES (rcm-bff/src/schema/typeDefs/):
Generate all 6 files from the GraphQL SDL defined in PROMPT-018:
patient.graphql, claim.graphql, denial.graphql,
payment.graphql, ar.graphql, agent.graphql

schema/index.ts:
// Merges all type definitions using @graphql-tools/merge
import { mergeTypeDefs } from '@graphql-tools/merge';
import { loadFilesSync } from '@graphql-tools/load-files';
import { join } from 'path';

const typesArray = loadFilesSync(join(__dirname, './typeDefs'), { extensions: ['graphql'] });
export const typeDefs = mergeTypeDefs(typesArray);

RESOLVERS:

resolvers/claim.resolver.ts:
// Most complex resolver — handles pagination, filtering, nested entities

import { GraphQLContext } from '../common/context';

export const claimResolvers = {
  Query: {
    claim: async (_: unknown, { id }: { id: string }, ctx: GraphQLContext) => {
      return ctx.rcmCore.getClaim(id);
    },

    claims: async (
      _: unknown,
      args: { first?: number; after?: string; status?: string; payerId?: string },
      ctx: GraphQLContext,
    ) => {
      // Convert Relay cursor args to REST pagination params
      // Comment: "Relay cursor pagination: 'after' is an opaque cursor (base64).
      // We decode it to get the page offset or last-seen ID for rcm-core.
      // This hides our internal pagination implementation from the client."
      const limit = Math.min(args.first || 20, 100);
      const cursor = args.after ? decodeCursor(args.after) : null;

      const response = await ctx.rcmCore.listClaims({
        limit, cursor, status: args.status, payerId: args.payerId
      });

      return {
        edges: response.data.map(claim => ({
          node: claim,
          cursor: encodeCursor(claim.id),
        })),
        pageInfo: {
          hasNextPage: response.pageInfo.hasNextPage,
          hasPreviousPage: !!cursor,
          startCursor: response.data[0] ? encodeCursor(response.data[0].id) : null,
          endCursor: response.data.at(-1) ? encodeCursor(response.data.at(-1)!.id) : null,
        },
      };
    },
  },

  Mutation: {
    scrubClaim: async (_: unknown, { claimId }: { claimId: string }, ctx: GraphQLContext) => {
      return ctx.rcmCore.scrubClaim(claimId);
    },
    submitClaim: async (_: unknown, { claimId }: { claimId: string }, ctx: GraphQLContext) => {
      return ctx.rcmCore.submitClaim(claimId);
    },
  },

  Claim: {
    // Nested resolver using DataLoader — prevents N+1
    payer: (claim: Claim, _: unknown, ctx: GraphQLContext) => {
      // Comment: "DataLoader batches all payer fetches for a list of claims
      // into a single API call. Without DataLoader, fetching 20 claims would
      // trigger 20 separate payer API calls (N+1 query problem)."
      return ctx.dataloaders.payerLoader.load(claim.payerId);
    },
    encounter: (claim: Claim, _: unknown, ctx: GraphQLContext) =>
      ctx.rcmCore.getEncounter(claim.encounterId),
  },
};

// Similar resolvers for patient, denial, payment, ar, agent
// Each follows the same pattern: Query/Mutation handlers + nested field resolvers using DataLoader

resolvers/denial.resolver.ts:
// Denial resolver — includes agentStatus nested field
export const denialResolvers = {
  Query: {
    denial: async (_: unknown, { id }: { id: string }, ctx: GraphQLContext) => {
      const [denial, agentStatus] = await Promise.all([
        ctx.rcmCore.getDenial(id),
        ctx.rcmRag.getDenialAgentStatus(id),
      ]);
      // Comment: "Parallel fetch: denial from rcm-core AND agent status from rcm-rag.
      // Promise.all runs both simultaneously — halves the latency compared to sequential."
      return { ...denial, agentStatus };
    },
    ...
  },
  Mutation: {
    approveAppeal: async (_: unknown, { denialId, approvedText }, ctx: GraphQLContext) => {
      return ctx.rcmCore.approveAppeal(denialId, approvedText, ctx.userId);
    },
  },
};

// resolvers/index.ts: merges all resolver objects
import { mergeResolvers } from '@graphql-tools/merge';
export const resolvers = mergeResolvers([
  claimResolvers, patientResolvers, denialResolvers,
  paymentResolvers, arResolvers, agentResolvers,
]);

Helper functions:
function encodeCursor(id: string): string {
  // Base64-encode the ID for opacity
  // Comment: "Opaque cursors: clients treat cursors as black boxes.
  // This lets us change the internal pagination mechanism without
  // breaking client code that stores cursors for pagination."
  return Buffer.from(id).toString('base64');
}

function decodeCursor(cursor: string): string {
  return Buffer.from(cursor, 'base64').toString('utf-8');
}

OUTPUT: ~14 files.
// FILE: rcm-bff/src/schema/typeDefs/patient.graphql [full SDL from PROMPT-018]
// FILE: rcm-bff/src/schema/typeDefs/claim.graphql
// FILE: rcm-bff/src/schema/typeDefs/denial.graphql
// FILE: rcm-bff/src/schema/typeDefs/payment.graphql
// FILE: rcm-bff/src/schema/typeDefs/ar.graphql
// FILE: rcm-bff/src/schema/typeDefs/agent.graphql
// FILE: rcm-bff/src/schema/index.ts
// FILE: rcm-bff/src/resolvers/claim.resolver.ts
// FILE: rcm-bff/src/resolvers/patient.resolver.ts
// FILE: rcm-bff/src/resolvers/denial.resolver.ts
// FILE: rcm-bff/src/resolvers/payment.resolver.ts
// FILE: rcm-bff/src/resolvers/ar.resolver.ts
// FILE: rcm-bff/src/resolvers/agent.resolver.ts
// FILE: rcm-bff/src/resolvers/index.ts
Each ends with // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-062: rcm-bff — data sources + SSE endpoint + API routes
# ============================================================
# GOAL: REST clients to rcm-core and rcm-rag + SSE streaming + health
# DEPENDS ON: PROMPT-060 PROMPT-061
# OUTPUT: 5 files
# ACCEPTANCE CRITERIA:
#   1. RcmCoreApi uses Axios with interceptors for auth headers and error mapping
#   2. SSE endpoint streams denial agent progress from rcm-rag
#   3. Error mapping: REST 404 → GraphQL NOT_FOUND, 503 → UPSTREAM_ERROR
#   4. RcmRagApi polls rcm-rag status endpoint and streams updates
# ============================================================

PROMPT-062 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the data sources and SSE endpoint for rcm-bff.

dataSources/RcmCoreApi.ts:
import axios, { AxiosInstance, AxiosError } from 'axios';

export class RcmCoreApi {
  private readonly client: AxiosInstance;

  constructor(tenantId: string, userToken: string) {
    this.client = axios.create({
      baseURL: config.RCM_CORE_URL,
      timeout: 10_000,
      headers: {
        Authorization: `Bearer ${serviceToken}`,
        // Comment: "Service token (client credentials) used for service-to-service auth.
        // User token passed in X-Internal-Context (signed header with userId, tenantId).
        // See SEC-02 ADR: we never propagate user tokens to internal services."
        'X-Internal-Context': buildInternalContextHeader(tenantId, userId),
      },
    });

    // Response interceptor: map REST errors to GraphQL errors
    this.client.interceptors.response.use(
      response => response,
      (error: AxiosError) => {
        if (error.response?.status === 404) {
          throw new GraphQLError('Not found', { extensions: { code: 'NOT_FOUND' } });
        }
        if (error.response?.status === 409) {
          throw new GraphQLError('Conflict', { extensions: { code: 'CONFLICT' } });
        }
        if (error.response?.status === 503) {
          throw new GraphQLError('Service unavailable', { extensions: { code: 'UPSTREAM_ERROR' } });
        }
        throw error;
      }
    );
  }

  // Methods matching OpenAPI spec from PROMPT-017:
  async getPatient(id: string): Promise<Patient> { ... }
  async getPatientsByIds(ids: string[]): Promise<Patient[]> { ... }
  async getClaim(id: string): Promise<Claim> { ... }
  async getClaimsByIds(ids: string[]): Promise<Claim[]> { ... }
  async listClaims(params: ClaimListParams): Promise<PaginatedResponse<Claim>> { ... }
  async scrubClaim(claimId: string): Promise<ScrubResult> { ... }
  async submitClaim(claimId: string): Promise<Claim> { ... }
  async getDenial(id: string): Promise<Denial> { ... }
  async listDenials(params: DenialListParams): Promise<PaginatedResponse<Denial>> { ... }
  async approveAppeal(denialId: string, approvedText: string, userId: string): Promise<Denial> { ... }
  async getArAgingReport(params: ArReportParams): Promise<ArAgingReport> { ... }
  async getEncounter(id: string): Promise<Encounter> { ... }
  async getPayersByIds(ids: string[]): Promise<Payer[]> { ... }
}

dataSources/RcmRagApi.ts:
// REST client to rcm-rag for status and agent endpoints
export class RcmRagApi {
  async getDenialAgentStatus(denialId: string): Promise<AgentStatus | null> { ... }
  async resumeAgent(runId: string, approvedText: string, feedback?: string): Promise<void> { ... }
}

db/postgres.ts:
// Read-only Postgres client for materialized view queries (reporting)
// Comment: "rcm-bff reads from PostgreSQL materialized views directly
// for reporting queries (AR aging, denial rate). This avoids adding
// reporting load to rcm-core's API. The bff has read-only credentials."
export async function getArAgingFromView(tenantId: string, asOf: string): Promise<any[]> {
  return pool.query(
    'SELECT * FROM rcm.mv_ar_aging_buckets WHERE tenant_id = $1',
    [tenantId]
  );
}

api/sse.ts:
// SSE endpoint streaming denial agent progress to the UI.
import { Router, Request, Response } from 'express';

export const sseRouter = Router();

sseRouter.get('/denial/:denialId', async (req: Request, res: Response) => {
  const { denialId } = req.params;
  // Validate JWT before establishing SSE connection
  const claims = await verifyJwt(req.headers.authorization?.replace('Bearer ', '') || '');
  const tenantId = claims.tenant_id as string;

  // Set SSE headers
  // Comment: "SSE requires these exact headers. Content-Type: text/event-stream
  // tells the browser this is an SSE stream. Cache-Control: no-cache prevents
  // proxies from buffering the stream (which would delay event delivery).
  // Connection: keep-alive prevents the server from closing after first write."
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');  // Disable nginx buffering
  res.flushHeaders();

  let previousNode = '';
  const pollInterval = setInterval(async () => {
    try {
      const ragApi = new RcmRagApi(tenantId, '');  // service token
      const status = await ragApi.getDenialAgentStatus(denialId);

      if (status && status.currentNode !== previousNode) {
        // SSE format: "data: {...}\n\n"
        res.write(`data: ${JSON.stringify(status)}\n\n`);
        previousNode = status.currentNode;
      }

      if (['finalize', 'error'].includes(status?.currentNode || '')) {
        res.write('event: done\ndata: {}\n\n');
        clearInterval(pollInterval);
        res.end();
      }
    } catch (err) {
      logger.error({ err, denialId }, 'SSE polling error');
    }
  }, 2_000);  // Poll every 2 seconds

  // Clean up on client disconnect
  req.on('close', () => {
    clearInterval(pollInterval);
    logger.info({ denialId }, 'SSE client disconnected');
  });
});

api/health.ts:
router.get('/', async (req, res) => {
  res.json({ status: 'healthy', version: config.APP_VERSION });
});

OUTPUT: 5 files.
// FILE: rcm-bff/src/dataSources/RcmCoreApi.ts
// FILE: rcm-bff/src/dataSources/RcmRagApi.ts
// FILE: rcm-bff/src/db/postgres.ts
// FILE: rcm-bff/src/api/sse.ts
// FILE: rcm-bff/src/api/health.ts
Each ends with // ===== END OF FILE =====
Full TypeScript implementation. SSE complete. Axios interceptors complete.
==========================================

# ============================================================
# PROMPT-063: rcm-bff + rcm-notify Dockerfiles + all tests
# ============================================================
# GOAL: Dockerfiles for both Node services + all tests for both
# DEPENDS ON: PROMPT-058 through PROMPT-062
# OUTPUT: ~8 files
# ACCEPTANCE CRITERIA:
#   1. Both Dockerfiles are multi-stage (build + runtime)
#   2. Runtime uses node:20-alpine (not full image)
#   3. Pact consumer test generates pact file to pacts/ directory
#   4. GraphQL integration test queries the full schema
#   5. Kafka integration test uses Testcontainers
# ============================================================

PROMPT-063 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Dockerfiles and tests for rcm-notify and rcm-bff.

rcm-notify/Dockerfile (multi-stage):
Stage 1 builder: node:20-alpine, npm ci, npm run build (tsc)
Stage 2 runtime: node:20-alpine
  - Copy only dist/ and node_modules/production
  - addgroup/adduser for non-root
  - Copy templates/ (Handlebars .hbs files)
  - EXPOSE 8092, HEALTHCHECK
  - CMD ["node", "dist/index.js"]

rcm-bff/Dockerfile (same pattern):
  - EXPOSE 8093
  - CMD ["node", "dist/index.js"]

rcm-notify/tests/unit/handlers.test.ts:
import { describe, it, expect, vi } from 'vitest';
// Mock email channel, Kafka consumer
// Test each handler with sample event payloads from PROMPT-022 schemas
// Verify correct template used, correct fields extracted

rcm-notify/tests/integration/kafka.integration.test.ts:
import { GenericContainer, KafkaContainer } from 'testcontainers';
// Start Kafka container
// Start Postgres container (for notification_log)
// Publish claim.submitted event to Kafka
// Verify: consumer picks it up, email attempted (mock nodemailer), log entry written

rcm-bff/tests/unit/resolvers.test.ts:
// Test claim resolver with mocked RcmCoreApi
// Verify: pagination cursor encoding/decoding
// Verify: DataLoader batches multiple payer fetches
// Verify: 404 from REST becomes GraphQL NOT_FOUND error

rcm-bff/tests/integration/graphql.integration.test.ts:
// Start Apollo Server in test mode with mock data sources
// Execute GraphQL queries via apollo-server-integration-testing
// Test: { claim(id: "...") { id status payer { name } } }
// Test: { denials(first: 5) { edges { node { id status } } pageInfo { hasNextPage } } }

rcm-bff/tests/pact/rcm-core.pact.test.ts:
import { Pact } from '@pact-foundation/pact';
// Consumer-driven contract test
// Defines what rcm-bff NEEDS from rcm-core
// Generates pact file that rcm-core's provider test verifies

// Pact 1: GET /v1/claims/{id}
//   Given: a claim with id X exists
//   When: rcm-bff requests GET /v1/claims/{id}
//   Then: response is 200 with ClaimResponse schema

// Pact 2: GET /v1/denials/{id}
//   Given: a denial with id X exists
//   When: rcm-bff requests GET /v1/denials/{id}
//   Then: response is 200 with DenialResponse schema

// Pact 3: POST /v1/denials/{id}/approve
//   Given: denial is in HUMAN_REVIEW status
//   When: rcm-bff POSTs approval
//   Then: response is 200 with updated denial

// Comment: "Consumer-driven: rcm-bff defines what it needs, not what rcm-core
// thinks it provides. This ensures rcm-core can't accidentally break rcm-bff
// by changing a field that rcm-bff depends on — the pact file is the contract."

OUTPUT: 8 files.
// FILE: rcm-notify/Dockerfile
// FILE: rcm-bff/Dockerfile
// FILE: rcm-notify/tests/unit/handlers.test.ts
// FILE: rcm-notify/tests/integration/kafka.integration.test.ts
// FILE: rcm-bff/tests/unit/resolvers.test.ts
// FILE: rcm-bff/tests/integration/graphql.integration.test.ts
// FILE: rcm-bff/tests/pact/rcm-core.pact.test.ts
// FILE: rcm-bff/src/common/errors.ts
Each ends with // ===== END OF FILE =====
==========================================
