# BATCH C4 — Prompts 064–067
# rcm-ui Next.js 14 — biller workbench UI
# GUIDED LATITUDE throughout.
# ============================================================

# ============================================================
# PROMPT-064: rcm-ui scaffold — package.json + Next.js config + lib layer + layout
# ============================================================
# GOAL: Full scaffold for the Next.js biller workbench
# DEPENDS ON: PROMPT-025 PROMPT-060
# OUTPUT: 8 files
# ACCEPTANCE CRITERIA:
#   1. Next.js 14 App Router, TypeScript, Tailwind CSS
#   2. NextAuth configured for Keycloak OIDC (Authorization Code + PKCE)
#   3. Apollo Client configured with auth link (attaches JWT to every request)
#   4. SSE hook (useSSE) for streaming denial agent progress
#   5. Root layout wraps in ApolloProvider and SessionProvider
# ============================================================

PROMPT-064 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the scaffold for rcm-ui, the Next.js 14 biller workbench.

PINNED VERSIONS: Next.js: 14.2.10, React: 18.3.1, TypeScript: 5.5.4,
Tailwind CSS: 3.4.10, @apollo/client: 3.11.4, next-auth: 4.24.7,
@tanstack/react-query: 5.56.2, zod: 3.23.8

package.json: all deps with pinned versions, scripts: dev/build/start/lint/test/e2e

next.config.ts:
import type { NextConfig } from 'next';
const config: NextConfig = {
  // Comment: "output: 'standalone' creates a self-contained build with
  // only the files needed to run the app. This produces a smaller Docker
  // image (no devDependencies) and is optimized for containerized deployment."
  output: 'standalone',
  // Rewrites: proxy /api/* and /graphql to backend services
  // Comment: "Rewrites avoid CORS: the browser talks to Next.js (same origin),
  // Next.js proxies to the backend. Without this, the browser would make
  // cross-origin requests to rcm-bff:8093 — requiring CORS configuration
  // on the backend and exposing backend URLs to the browser."
  async rewrites() {
    return [
      { source: '/graphql', destination: `${process.env.RCM_BFF_URL}/graphql` },
      { source: '/sse/:path*', destination: `${process.env.RCM_BFF_URL}/sse/:path*` },
    ];
  },
};
export default config;

lib/auth.ts:
// NextAuth configuration for Keycloak OIDC.
import NextAuth from 'next-auth';
import KeycloakProvider from 'next-auth/providers/keycloak';

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    KeycloakProvider({
      clientId: process.env.KEYCLOAK_CLIENT_ID!,
      clientSecret: process.env.KEYCLOAK_CLIENT_SECRET!,
      issuer: process.env.KEYCLOAK_ISSUER!,
    }),
  ],
  callbacks: {
    async jwt({ token, account }) {
      // Pass access token through to session for Apollo Client
      // Comment: "We store the Keycloak access_token in the JWT session token
      // so Apollo Client can attach it to GraphQL requests. The access_token
      // is what rcm-bff validates — the NextAuth session_token is just for
      // maintaining the browser session."
      if (account) { token.accessToken = account.access_token; }
      return token;
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken as string;
      return session;
    },
  },
});

lib/graphql-client.ts:
// Apollo Client configured with auth link for attaching JWT.
import { ApolloClient, InMemoryCache, createHttpLink, from } from '@apollo/client';
import { setContext } from '@apollo/client/link/context';
import { onError } from '@apollo/client/link/error';
import { getSession } from 'next-auth/react';

const httpLink = createHttpLink({ uri: '/graphql' });

const authLink = setContext(async (_, { headers }) => {
  const session = await getSession();
  return {
    headers: {
      ...headers,
      authorization: session?.accessToken ? `Bearer ${session.accessToken}` : '',
    },
  };
});

const errorLink = onError(({ graphQLErrors, networkError }) => {
  if (graphQLErrors) {
    graphQLErrors.forEach(({ message, extensions }) => {
      if (extensions?.code === 'UNAUTHORIZED') {
        // Redirect to login
        window.location.href = '/api/auth/signin';
      }
    });
  }
});

export const apolloClient = new ApolloClient({
  link: from([errorLink, authLink, httpLink]),
  cache: new InMemoryCache({
    // Comment: "Type policies define how Apollo Client normalizes and caches
    // GraphQL types. keyFields tells Apollo which field uniquely identifies
    // an object — it uses this to merge updates correctly in the cache."
    typePolicies: {
      Claim: { keyFields: ['id'] },
      Denial: { keyFields: ['id'] },
      Patient: { keyFields: ['id'] },
    },
  }),
});

lib/sse-client.ts:
// useSSE hook for consuming Server-Sent Events from rcm-bff.
'use client';
import { useEffect, useState, useRef } from 'react';

export function useSSE<T>(url: string | null) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [done, setDone] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!url) return;

    // Comment: "EventSource automatically reconnects on connection loss
    // (exponential backoff). We don't need to implement reconnection logic.
    // The server-side SSE stream picks up from where it left off because
    // it polls Postgres — the next connection gets the current state."
    const es = new EventSource(url, { withCredentials: true });
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      setData(JSON.parse(event.data) as T);
    };

    es.addEventListener('done', () => {
      setDone(true);
      es.close();
    });

    es.onerror = (err) => {
      setError(new Error('SSE connection error'));
      // EventSource will auto-reconnect — we just log the error
    };

    return () => { es.close(); };  // Cleanup on unmount
  }, [url]);

  return { data, error, done };
}

app/layout.tsx:
// Root layout wrapping all pages.
import { Providers } from './providers';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

// app/providers.tsx (client component):
'use client';
import { SessionProvider } from 'next-auth/react';
import { ApolloProvider } from '@apollo/client';
import { apolloClient } from '../lib/graphql-client';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <ApolloProvider client={apolloClient}>
        {children}
      </ApolloProvider>
    </SessionProvider>
  );
}

app/page.tsx:
// Root page: redirect to /claims (the main biller dashboard)
import { redirect } from 'next/navigation';
export default function Home() { redirect('/claims'); }

OUTPUT: 8 files.
// FILE: rcm-ui/package.json
// FILE: rcm-ui/tsconfig.json
// FILE: rcm-ui/next.config.ts
// FILE: rcm-ui/tailwind.config.ts
// FILE: rcm-ui/lib/auth.ts
// FILE: rcm-ui/lib/graphql-client.ts
// FILE: rcm-ui/lib/sse-client.ts
// FILE: rcm-ui/app/layout.tsx
Each ends with // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-065: rcm-ui claims screens — dashboard + detail
# ============================================================
# GOAL: Claims dashboard and claim detail screens with GraphQL queries
# DEPENDS ON: PROMPT-064 PROMPT-061
# OUTPUT: ~8 files
# ACCEPTANCE CRITERIA:
#   1. ClaimsDashboard uses server component for initial data fetch
#   2. ClaimStatusBadge uses Tailwind CSS with correct color per status
#   3. Pagination: Next/Previous buttons using Relay cursors
#   4. Currency displayed as dollars (divide cents by 100), never expose cents to user
#   5. Filter bar: status dropdown + payer search
# ============================================================

PROMPT-065 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the claims screens for rcm-ui.

GRAPHQL QUERIES (rcm-ui/queries/claims.graphql):
query GetClaims($first: Int, $after: String, $status: ClaimStatus, $payerId: ID) {
  claims(first: $first, after: $after, status: $status, payerId: $payerId) {
    edges {
      node {
        id status claimType totalChargeCents paidAmountCents
        payer { id name }
        encounter { serviceDate placeOfService }
        scrubResult { passed issues { severity description } }
        createdAt submittedAt
      }
      cursor
    }
    pageInfo { hasNextPage hasPreviousPage startCursor endCursor }
  }
}

query GetClaim($id: ID!) {
  claim(id: $id) {
    id status claimType totalChargeCents allowedAmountCents
    paidAmountCents patientResponsibilityCents
    payer { id name payerType }
    encounter { serviceDate dischargeDate placeOfService encounterType }
    lines { lineNumber cptCode icd10Codes modifiers units chargeCents }
    scrubResult { passed issues { issueCode severity description suggestedFix } warnings: issues }
    summary createdAt submittedAt adjudicatedAt
  }
}

mutation ScrubClaim($claimId: ID!) {
  scrubClaim(claimId: $claimId) { passed issues { severity description } }
}

mutation SubmitClaim($claimId: ID!) {
  submitClaim(claimId: $claimId) { id status submittedAt }
}

app/claims/page.tsx (Server Component):
// Claims dashboard — server component fetches initial data
import { auth } from '../../lib/auth';
import { ClaimsDashboard } from '../../components/claims/ClaimsDashboard';

export default async function ClaimsPage({ searchParams }) {
  const session = await auth();
  if (!session) redirect('/api/auth/signin');

  // Pass searchParams (status filter, page cursor) to dashboard component
  return <ClaimsDashboard initialStatus={searchParams.status} />;
}

components/claims/ClaimsDashboard.tsx (Client Component):
'use client';
import { useQuery } from '@apollo/client';
import { GET_CLAIMS } from '../../queries/claims.graphql';
import { ClaimCard } from './ClaimCard';
import { ClaimStatusBadge } from './ClaimStatusBadge';

// Status filter, pagination, claim list
// Tailwind grid layout
// Empty state: "No claims found. Create a claim to get started."
// Loading state: skeleton cards
// Error state: retry button

components/claims/ClaimCard.tsx:
// Summary card for each claim in the list
// Shows: claim ID (truncated), payer name, status badge, service date, total charge in dollars
// Click navigates to /claims/{id}
// Color-coded left border by status:
//   PAID: green, DENIED: red, SCRUB_FAILED: orange, SUBMITTED: blue, others: gray

components/claims/ClaimStatusBadge.tsx:
// Status badge component — pill-shaped with background color
// Tailwind classes per status:
//   PAID: 'bg-green-100 text-green-800'
//   DENIED: 'bg-red-100 text-red-800'
//   SCRUB_FAILED: 'bg-orange-100 text-orange-800'
//   SUBMITTED/ACKNOWLEDGED: 'bg-blue-100 text-blue-800'
//   DRAFT: 'bg-gray-100 text-gray-800'
//   etc.

app/claims/[claimId]/page.tsx (Server Component):
// Claim detail page
// Tabs: Overview, Claim Lines, Scrub Result, History
// Actions: Scrub Claim button (if DRAFT), Submit button (if SCRUBBED)

Shared components/shared/LoadingSpinner.tsx, ErrorBoundary.tsx, TenantHeader.tsx:
// TenantHeader: shows tenant name and user name in top right
// LoadingSpinner: centered Tailwind spinner
// ErrorBoundary: catches React errors, shows retry option

OUTPUT: ~8 files in rcm-ui/
Each: // FILE: path // ===== END OF FILE =====
Full React/TypeScript implementation. Tailwind classes complete.
==========================================

# ============================================================
# PROMPT-066: rcm-ui denial screens — review panel + appeal editor + agent timeline
# ============================================================
# GOAL: Denial queue + denial review with SSE streaming + appeal draft editor
# DEPENDS ON: PROMPT-064 PROMPT-065
# OUTPUT: ~8 files
# ACCEPTANCE CRITERIA:
#   1. DenialQueue shows denials awaiting action (HUMAN_REVIEW status) first
#   2. DenialReviewPanel shows AI explanation + agent reasoning steps
#   3. AppealDraftEditor is a rich textarea the biller can edit
#      before approving — shows AI draft, biller edits inline
#   4. SSE stream updates AgentStepsTimeline in real time
#   5. Approve button calls approveAppeal mutation with edited text
# ============================================================

PROMPT-066 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the denial review screens for rcm-ui.
This is the crown-jewel UX of the system — where AI meets human oversight.

GRAPHQL QUERIES (rcm-ui/queries/denials.graphql):
query GetDenials($first: Int, $after: String, $status: DenialStatus) {
  denials(first: $first, after: $after, status: $status) {
    edges {
      node {
        id status denialDate
        carcCode { code description }
        claim { id payer { name } encounter { serviceDate } totalChargeCents }
        agentStatus { currentNode interrupted stepsCompleted { nodeName success } }
      }
      cursor
    }
    pageInfo { hasNextPage endCursor }
  }
}

query GetDenial($id: ID!) {
  denial(id: $id) {
    id status denialDate
    carcCode { code description }
    rarcCode { code description }
    claim {
      id totalChargeCents
      payer { name }
      encounter { serviceDate }
      lines { cptCode icd10Codes chargeCents }
    }
    explanation
    appealDraft { draftText approvedText approvedAt }
    agentStatus {
      currentNode interrupted interruptedAt
      stepsCompleted { nodeName completedAt success outputSummary }
    }
  }
}

mutation ApproveAppeal($denialId: ID!, $approvedText: String!) {
  approveAppeal(denialId: $denialId, approvedText: $approvedText) {
    id status appealDraft { approvedText approvedAt }
  }
}

app/denials/page.tsx:
// Denial queue — defaults to showing HUMAN_REVIEW denials first
// Priority queue: HUMAN_REVIEW at top, then RECEIVED, then AGENT_ANALYZING
// Each denial card shows: CARC code, payer, service date, days since denial

app/denials/[denialId]/page.tsx (Client Component — needs SSE):
'use client';
// Main denial review page
// Layout: left panel (denial info + agent steps), right panel (appeal editor)
// SSE connection to /sse/denial/{denialId} via useSSE hook
// Updates AgentStepsTimeline in real time as agent progresses

components/denials/DenialQueue.tsx:
// Sortable, filterable list of denials
// Status filter tabs: All | Needs Review | In Progress | Resolved
// Each row: CARC code pill, payer, service date, amount, status, days outstanding
// Click navigates to /denials/{id}
// Color urgency: >90 days = red, >60 days = orange, >30 days = yellow

components/denials/DenialReviewPanel.tsx:
// Left panel of the denial review screen
// Sections:
// 1. Denial Details (CARC, RARC, payer, service date, amount)
// 2. AI Explanation (from denial.explanation field)
// 3. Claim Lines (CPT codes, diagnosis codes, charges)
// 4. AgentStepsTimeline (below)

components/denials/AgentStepsTimeline.tsx:
// Visual timeline showing LangGraph agent progress
// Each step: node name, status (complete/running/pending), time taken
// Running step: animated spinner
// Interrupted step: 🔔 "Awaiting your review"
// Completed: ✓ with timestamp
// Real-time updates via SSE (data prop updates from parent)

components/denials/AppealDraftEditor.tsx:
'use client';
// The most important component — where biller edits the AI draft
// Props: denialId, initialDraft, onApprove
// State: editedText (starts as initialDraft)
// UI:
//   Header: "AI-Drafted Appeal Letter" with badge "Draft" or "Edited"
//   Textarea: full-width, 20 rows, shows initialDraft, editable
//   Character count / word count
//   Diff indicator: if biller edited, show "X changes made"
//   Action row:
//     - "Approve as-is" button (if no edits)
//     - "Approve with edits" button (if edited)
//     - "Request new draft" button (calls agent to redraft — v2 feature, show as disabled)
//   On approve: calls approveAppeal mutation, shows success state
//   Success state: "Appeal submitted for review ✓"
//     Shows approved_at timestamp, locked textarea (no more editing)

// Comment: "AppealDraftEditor is a Client Component because it:
// 1. Uses useState for the edited text (client-side state)
// 2. Calls Apollo mutation (requires browser context)
// 3. Needs user interaction (typing in textarea)
// This is why it's 'use client' — not because it couldn't be SSR,
// but because it fundamentally needs interactivity."

OUTPUT: ~8 files.
// FILE: app/denials/page.tsx
// FILE: app/denials/[denialId]/page.tsx
// FILE: components/denials/DenialQueue.tsx
// FILE: components/denials/DenialReviewPanel.tsx
// FILE: components/denials/AgentStepsTimeline.tsx
// FILE: components/denials/AppealDraftEditor.tsx
// FILE: app/(auth)/login/page.tsx
// FILE: app/(auth)/callback/page.tsx
Each ends with // ===== END OF FILE =====
Full React/TypeScript implementation. SSE integration complete. Tailwind styling complete.
==========================================

# ============================================================
# PROMPT-067: rcm-ui auth pages + GraphQL queries + Dockerfile + E2E tests
# ============================================================
# GOAL: Auth flow pages + query files + containerization + Playwright tests
# DEPENDS ON: PROMPT-064 PROMPT-065 PROMPT-066
# OUTPUT: ~8 files
# ACCEPTANCE CRITERIA:
#   1. Login page redirects to Keycloak (no custom login form)
#   2. Playwright E2E test covers the claims dashboard flow
#   3. Playwright E2E test covers the denial approval flow
#   4. Dockerfile builds a production Next.js standalone image
#   5. Unit test for AppealDraftEditor verifies approve mutation called
# ============================================================

PROMPT-067 CONTEXT — paste this into DeepSeek:
==========================================
You are generating auth pages, query files, Dockerfile, and tests for rcm-ui.

Auth pages (simple redirects):
app/(auth)/login/page.tsx:
  // Redirect to NextAuth Keycloak sign-in
  import { signIn } from '../../lib/auth';
  export default function LoginPage() {
    return <button onClick={() => signIn('keycloak')}>Sign in with SSO</button>;
  }

app/(auth)/callback/page.tsx:
  // NextAuth handles the callback — this is just a loading page

queries/claims.graphql: [paste the full queries from PROMPT-065]
queries/denials.graphql: [paste the full queries from PROMPT-066]

rcm-ui/Dockerfile (multi-stage Next.js):
Stage 1 deps: node:20-alpine, npm ci (production + dev for build)
Stage 2 builder: npm run build (next build)
Stage 3 runtime: node:20-alpine
  COPY --from=builder /app/.next/standalone ./
  COPY --from=builder /app/.next/static ./.next/static
  COPY --from=builder /app/public ./public
  USER nextjs (non-root)
  EXPOSE 3000
  CMD ["node", "server.js"]
  # Comment: "Next.js standalone output includes a minimal server.js
  # that starts Next.js without needing the full framework installed.
  # The standalone build copies only necessary files — no node_modules
  # of devDependencies in the final image."

tests/e2e/playwright.config.ts:
import { defineConfig, devices } from '@playwright/test';
export default defineConfig({
  testDir: './tests/e2e',
  use: {
    baseURL: 'http://localhost:3000',
    // Store auth state — run login once, reuse across tests
    storageState: 'playwright/.auth/user.json',
  },
  projects: [
    // Global setup: authenticate once
    { name: 'setup', testMatch: '**/auth.setup.ts' },
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'], storageState: 'playwright/.auth/user.json' },
      dependencies: ['setup'],
    },
  ],
});

tests/e2e/claims-dashboard.spec.ts:
import { test, expect } from '@playwright/test';

test.describe('Claims Dashboard', () => {
  test('shows claim list with status badges', async ({ page }) => {
    await page.goto('/claims');
    await expect(page.getByRole('heading', { name: /claims/i })).toBeVisible();
    // Verify at least one claim card is visible (from seed data)
    await expect(page.locator('[data-testid="claim-card"]').first()).toBeVisible();
  });

  test('filters claims by status', async ({ page }) => {
    await page.goto('/claims');
    await page.selectOption('[data-testid="status-filter"]', 'DRAFT');
    await expect(page.locator('[data-testid="claim-status-badge"]'))
      .toContainText('DRAFT');
  });

  test('navigates to claim detail', async ({ page }) => {
    await page.goto('/claims');
    await page.locator('[data-testid="claim-card"]').first().click();
    await expect(page).toHaveURL(/\/claims\/.+/);
  });
});

tests/e2e/denial-review.spec.ts:
test.describe('Denial Review', () => {
  test('shows denial queue', async ({ page }) => {
    await page.goto('/denials');
    await expect(page.getByRole('heading', { name: /denials/i })).toBeVisible();
  });

  test('opens denial review panel', async ({ page }) => {
    await page.goto('/denials');
    // Click first denial in queue
    await page.locator('[data-testid="denial-row"]').first().click();
    // Verify review panel components
    await expect(page.locator('[data-testid="denial-review-panel"]')).toBeVisible();
    await expect(page.locator('[data-testid="appeal-draft-editor"]')).toBeVisible();
    await expect(page.locator('[data-testid="agent-steps-timeline"]')).toBeVisible();
  });

  test('biller can edit and approve appeal draft', async ({ page }) => {
    // Navigate to a denial in HUMAN_REVIEW status (seeded data)
    await page.goto('/denials?status=HUMAN_REVIEW');
    await page.locator('[data-testid="denial-row"]').first().click();

    // Edit the appeal draft
    const editor = page.locator('[data-testid="appeal-draft-editor"] textarea');
    await editor.fill('Edited appeal letter content for testing purposes.');

    // Approve
    await page.locator('[data-testid="approve-button"]').click();

    // Verify success state
    await expect(page.locator('[data-testid="approval-success"]')).toBeVisible();
  });
});

tests/unit/components/AppealDraftEditor.test.tsx:
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MockedProvider } from '@apollo/client/testing';
import { AppealDraftEditor } from '../../../components/denials/AppealDraftEditor';

const mocks = [
  {
    request: { query: APPROVE_APPEAL, variables: { denialId: 'test-id', approvedText: 'test' } },
    result: { data: { approveAppeal: { id: 'test-id', status: 'APPEAL_SUBMITTED' } } },
  },
];

test('calls approveAppeal mutation when approved', async () => {
  render(
    <MockedProvider mocks={mocks} addTypename={false}>
      <AppealDraftEditor denialId="test-id" initialDraft="AI draft text" />
    </MockedProvider>
  );

  const textarea = screen.getByRole('textbox');
  fireEvent.change(textarea, { target: { value: 'test' } });
  fireEvent.click(screen.getByText(/approve/i));

  await waitFor(() => {
    expect(screen.getByTestId('approval-success')).toBeInTheDocument();
  });
});

OUTPUT: 8 files.
// FILE: rcm-ui/app/(auth)/login/page.tsx
// FILE: rcm-ui/app/(auth)/callback/page.tsx
// FILE: rcm-ui/queries/claims.graphql
// FILE: rcm-ui/queries/denials.graphql
// FILE: rcm-ui/Dockerfile
// FILE: rcm-ui/tests/e2e/playwright.config.ts
// FILE: rcm-ui/tests/e2e/claims-dashboard.spec.ts
// FILE: rcm-ui/tests/e2e/denial-review.spec.ts
Each ends with // ===== END OF FILE =====
==========================================

# ==========================================================
# BATCH D — Prompts 068–075
# Tests, Observability, Process, Interview Prep, README
# MAX RIGIDITY for process/config files; GUIDED for prep docs
# ==========================================================

# ============================================================
# PROMPT-068: Pact contract tests — full cross-service verification
# ============================================================
# GOAL: rcm-core Pact provider verification + rcm-rag provider verification
# DEPENDS ON: PROMPT-045 PROMPT-057 PROMPT-063
# OUTPUT: 4 test files
# ============================================================

PROMPT-068 CONTEXT — paste this into DeepSeek:
==========================================
You are generating Pact provider verification tests that prove the
backend services satisfy the contracts defined by rcm-bff consumers.

PACT FLOW RECAP:
1. rcm-bff (consumer) generates pacts in PROMPT-063 tests
2. rcm-core (provider) verifies those pacts here
3. rcm-rag (provider) verifies pacts here too
4. CI runs contract-tests.yml workflow after each service CI passes

rcm-core provider verification (Java):
File: rcm-core/app/src/test/java/com/rcm/pact/RcmCorePactProviderTest.java

@Provider("rcm-core")
@Consumer("rcm-bff")
@PactFolder("pacts/")  // pacts generated by rcm-bff tests are committed here
@SpringBootTest(webEnvironment = RANDOM_PORT)
@Testcontainers
public class RcmCorePactProviderTest {
  // Provider states: set up DB state matching the "Given" clauses in pacts
  @State("a claim with id X exists")
  public void claimExists() { /* seed claim to Postgres via JDBC */ }

  @State("a denial is in HUMAN_REVIEW status")
  public void denialInHumanReview() { /* seed denial */ }

  // Pact verification runs automatically against the seeded state
  // Comment: "Provider states ensure the provider is in the correct state
  // to satisfy the pact. Without this, the pact might request a claim that
  // doesn't exist — the verification would fail for the wrong reason."
}

rcm-rag provider verification (Python):
File: rcm-rag/tests/pact/test_pact_provider.py

# Uses pact-python to verify pacts from rcm-bff
from pact import Verifier

def test_pact_with_rcm_bff():
    verifier = Verifier(
        provider='rcm-rag',
        provider_base_url='http://localhost:8091',
    )
    output, _ = verifier.verify_pacts(
        './pacts/',
        provider_states_setup_url='http://localhost:8091/pact/provider-states',
    )
    assert output == 0, "Pact verification failed"

# Provider state setup endpoint (in rcm_rag/api/):
@router.post("/pact/provider-states")
async def setup_provider_state(body: dict):
    state = body.get("state")
    if state == "a denial agent status exists":
        # Seed agent_states table in test DB
        ...

OUTPUT: 4 files.
// FILE: rcm-core/app/src/test/java/com/rcm/pact/RcmCorePactProviderTest.java
// FILE: rcm-rag/tests/pact/test_pact_provider.py
// FILE: rcm-rag/rcm_rag/api/pact_states.py (provider state setup endpoint)
// FILE: docs/process/pact-workflow.md (explains the full pact flow with diagram)
Each ends with // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-069 + PROMPT-070: Additional integration tests
# ============================================================
# These are combined since they're focused verification tests

PROMPT-069 CONTEXT — paste this into DeepSeek:
==========================================
You are generating additional Testcontainers integration tests for rcm-core.

File 1: rcm-core/app/src/test/java/com/rcm/ClaimFullLifecycleIntegrationTest.java
// Full claim lifecycle: create → scrub → submit → deny → appeal → approve
// Uses mock gRPC server for rcm-rag
// Uses Testcontainers Kafka for event verification
// Verifies CosmosDB events written at each stage (mock)
// Verifies all state transitions in correct order

File 2: rcm-core/app/src/test/java/com/rcm/EligibilityWithCacheIntegrationTest.java
// Verifies cache HIT/MISS metrics are incremented correctly
// Verifies Redis key TTL is set to 24h
// Verifies Postgres row created on cache miss
// Verifies no Postgres row on cache hit (payer client not called)

File 3: rcm-core/app/src/test/java/com/rcm/MultiTenantSecurityIntegrationTest.java
// Verifies tenant A cannot read tenant B's claims
// Verifies tenant A cannot approve tenant B's appeal
// Verifies that all endpoints return 403 without valid JWT
// This is the most important security test in the system

OUTPUT: 3 Java test files.
Each: // FILE: path // ===== END OF FILE =====
==========================================

PROMPT-070 CONTEXT — paste this into DeepSeek:
==========================================
You are generating additional Testcontainers integration tests for rcm-rag.

File 1: rcm-rag/tests/integration/test_full_rag_pipeline.py
# End-to-end: ingest payer policy → retrieve for claim → build prompt → validate output
# Uses real Postgres (Testcontainers) with pgvector
# Verifies retrieval quality: retrieved chunk contains relevant keywords

File 2: rcm-rag/tests/integration/test_agent_interrupt_resume.py
# LangGraph agent interrupt → state persistence → resume flow
# Uses real Postgres (Testcontainers)
# Verifies: state saved before interrupt, state loadable, graph resumes at correct node

File 3: rcm-rag/tests/integration/test_phi_redaction_in_pipeline.py
# Verifies PHI never reaches mock LLM client
# Inject mock LLM that captures prompts
# Run claim scrubbing with patient name in context
# Assert: patient name NOT in any prompt sent to LLM
# Assert: [PATIENT_NAME_1] token appears in prompt
# Assert: rehydrated response contains original name

File 4: rcm-rag/tests/integration/test_semantic_cache_threshold.py
# Verifies semantic cache threshold behavior
# Store response for query A
# Query with semantically identical text → cache hit
# Query with related but different text → cache miss
# Query with very different text → cache miss

OUTPUT: 4 Python test files.
Each: // FILE: path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-071: Eval golden sets — 20 cases each, realistic RCM data
# ============================================================

PROMPT-071 CONTEXT — paste this into DeepSeek:
==========================================
You are generating evaluation golden sets for the rcm-rag eval harness.
These are the ground-truth test cases used to measure RAG quality.

File 1: rcm-rag/evals/golden_sets/denial_explanation_golden.json
20 test cases. Each:
{
  "case_id": "DE-001",
  "denial_context": {
    "carc_code": "197",
    "rarc_code": "N115",
    "cpt_code": "27447",
    "cpt_description": "Total knee arthroplasty",
    "payer_name": "Aetna",
    "service_date": "2024-03-15",
    "icd10_code": "M17.11"
  },
  "relevant_chunk_ids": [],  // empty — eval uses semantic relevance
  "expected_carc": "197",
  "reference_answer": "...",  // 2-3 sentence expected explanation
  "expected_disputable": true,
  "expected_appeal_likelihood": "HIGH"
}

Cover these CARC codes across 20 cases:
197 (prior auth x4), 50 (medical necessity x3), 29 (timely filing x2),
16 (billing error x2), 4 (not covered x2), 57 (auth absent x2),
119 (benefit max x1), 45 (contractual x1), 236 (NCCI edit x1), 58 (POS x1), 177 (eligibility x1)
Mix of payers: Aetna, Cigna, UHC, BCBS, Medicare
Reference answers should be 2-4 sentences, factually accurate RCM language.

File 2: rcm-rag/evals/golden_sets/claim_scrubbing_golden.json
20 test cases. Each:
{
  "case_id": "CS-001",
  "claim": {
    "claim_type": "837P",
    "cpt_codes": ["27447"],
    "icd10_codes": ["M17.11"],
    "modifiers": [],
    "place_of_service": "21",
    "service_date": "2024-03-15",
    "payer_id": "AETNA001",
    "total_charge_cents": 2500000
  },
  "expected_result": {
    "passed": false,
    "expected_issue_code": "PRIOR_AUTH_REQUIRED",
    "expected_severity": "BLOCKING"
  }
}
Mix: 10 should PASS, 6 BLOCKING failures, 4 WARNING only.
Realistic claim scenarios: missing prior auth, wrong POS for procedure,
NCCI bundle conflict, diagnosis not supporting procedure.

OUTPUT: 2 JSON files.
// FILE: rcm-rag/evals/golden_sets/denial_explanation_golden.json
// FILE: rcm-rag/evals/golden_sets/claim_scrubbing_golden.json
Each ends with // ===== END OF FILE =====
All 40 test cases must be realistic, clinically plausible, and varied.
==========================================

# ============================================================
# PROMPT-072: Grafana dashboards finalized + alerting rules
# ============================================================

PROMPT-072 CONTEXT — paste this into DeepSeek:
==========================================
You are finalizing the Grafana dashboards and adding alerting rules.

Update the 5 dashboard JSON files from PROMPT-027 with:
1. Correct metric names matching the actual Prometheus metric names
   defined in PROMPT-026 and PROMPT-053
2. Alert thresholds shown as colored thresholds on panels
3. Links between dashboards (click from service-overview → llm-cost)
4. Time range variable and auto-refresh in each dashboard
5. Annotations: mark deploys and incidents

New file: infrastructure/observability/prometheus/alerts.yml
Alert rules:
- HighDenialRate: denial_rate > 15% for 30 minutes → warning
- LlmBudgetExhausted: llm_budget_remaining == 0 → critical
- CircuitBreakerOpen: resilience4j_circuitbreaker_state == OPEN for 5 min → critical
- HighLlmLatency: llm_latency_seconds_p95 > 10s for 5 min → warning
- FaithfulnessRegression: eval_faithfulness_score < 0.75 → warning
- LowHitRate: eligibility cache hit rate < 50% for 1h → info

OUTPUT: 6 files (5 updated dashboard JSONs + 1 alerts file).
Each: // FILE: path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-073: Process docs — PR template, CONTRIBUTING, code review checklist
# ============================================================

PROMPT-073 CONTEXT — paste this into DeepSeek:
==========================================
You are generating process and contribution documentation for the RCM platform.

.github/PULL_REQUEST_TEMPLATE.md:
Sections:
## What does this PR do?
[description]

## Type of change
- [ ] Bug fix (non-breaking)
- [ ] New feature (non-breaking)
- [ ] Breaking change
- [ ] AI/Prompt change (requires eval gate to pass)
- [ ] Infrastructure change

## Checklist
- [ ] Tests added/updated
- [ ] Docs updated (ADR if architectural decision changed)
- [ ] No hardcoded secrets (gitleaks passes)
- [ ] PHI not present in any log statements
- [ ] Tenant isolation tested if new entity added
- [ ] If prompt changed: eval harness scores above thresholds
- [ ] If API changed: Pact tests updated

## Eval results (if prompt changed)
| Metric | Before | After | Threshold |
|--------|--------|-------|-----------|
| faithfulness | | | 0.85 |
| carc_accuracy | | | 0.80 |

CONTRIBUTING.md:
- Local setup guide (pointer to docs/local-dev-setup.md)
- Branch naming: feat/JIRA-123-short-description
- Commit format: feat(claims): add gRPC retry with Resilience4j
- PR process: fork → branch → PR → review → merge to main
- Testing requirements per service
- Prompt change process (eval gates explained)

docs/process/sprint-plan-template.md:
Sprint N (YYYY-MM-DD to YYYY-MM-DD)
Goals, User Stories (with acceptance criteria), Tech Debt, Definition of Done

docs/process/retro-template.md:
What went well / What didn't / Action items

docs/process/code-review-checklist.md:
Reviewer checklist organized by category:
- Security (PHI, auth, tenant isolation)
- AI/ML (prompt changes, eval scores, hallucination risk)
- Performance (N+1, missing indexes, cache correctness)
- Correctness (edge cases, error handling, idempotency)
- Observability (logging, metrics, traces)
- Documentation (ADR if needed)

.github/ISSUE_TEMPLATE/bug_report.md and feature_request.md
.github/CODEOWNERS:
  *.java @java-team
  rcm-rag/** @ai-team
  docs/adr/** @architecture-team

OUTPUT: 8 files.
Each: // FILE: path // ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-074: INTERVIEW_PREP.md — complete cross-reference guide
# ============================================================

PROMPT-074 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the complete INTERVIEW_PREP.md for a senior software
engineer interview focused on an RCM platform with RAG and AI components.

This document cross-references every architectural decision to:
1. The relevant ADR file
2. The relevant code file in the codebase
3. A crisp talking-point paragraph

Organize by likely interview question category:

SECTION 1: System Design Questions
Q: "Walk me through the architecture of this system."
→ Start with: C4 Level 1 context diagram (docs/diagrams/01-c4-system-context.md)
→ Key files: docs/architecture-overview.md, docs/diagrams/02-c4-containers.md
→ Talking point: [2-3 sentences on the 5-service polyglot design]

Q: "Why did you choose a modular monolith for the Java service instead of microservices?"
→ ADR: docs/adr/ARCH-02-modular-monolith.md
→ Code: rcm-core/settings.gradle (8 subprojects), rcm-core/common/
→ Talking point: [the module-vs-deployment-boundary distinction]

Q: "How does the system handle the async nature of claim adjudication?"
→ ADR: docs/adr/ARCH-04-kafka-async-flows.md
→ Code: rcm-core/claims/src/.../kafka/ClaimEventPublisher.java,
         rcm-core/denials/src/.../kafka/DenialReceivedConsumer.java
→ Talking point: [sync vs async decision criteria]

SECTION 2: AI/ML and RAG Questions
Q: "Explain how your RAG pipeline works end to end."
Q: "What's the difference between recall@k and faithfulness?"
Q: "How do you prevent hallucinations in a healthcare context?"
Q: "Why LangGraph instead of a simple ReAct loop?"
Q: "How do you handle PHI in LLM calls?"
Q: "What happens when the LLM provider goes down?"
Q: "How do you know your RAG system is working well?"
→ [Each with ADR reference, code file, talking point]

SECTION 3: Data Architecture Questions
Q: "Why pgvector instead of a dedicated vector database like Pinecone?"
Q: "When would you use CosmosDB vs Postgres?"
Q: "How does your caching strategy work?"
Q: "How do you handle database migrations safely?"
→ [Each with ADR reference, code file, talking point]

SECTION 4: Security and Compliance (HIPAA)
Q: "How do you ensure HIPAA compliance in this system?"
Q: "Walk me through how PHI is protected."
Q: "How does your multi-tenant isolation work? What prevents a bug from leaking data?"
Q: "How do you handle secrets?"
→ [Each with ADR reference, code file, talking point]

SECTION 5: Scalability
Q: "How would you scale this system to 10x current load?"
Q: "What would break first?"
Q: "How does your caching hierarchy help at scale?"
→ [Each with ADR reference, code file, talking point]

SECTION 6: Protocol Choices (REST vs GraphQL vs gRPC)
Q: "Why three different protocols? Isn't that over-engineered?"
Q: "When would you add WebSocket instead of SSE?"
→ ADR: docs/adr/ARCH-03-protocol-choices.md
→ Talking point: [the justification table from the locked decisions]

SECTION 7: Process and Agile
Q: "How did you approach prompt engineering in this system?"
Q: "How do you test AI features?"
Q: "What's your branching strategy?"
→ [Each with process doc reference and talking point]

QUICK REFERENCE TABLE at the end:
| "Tell me about X" | ADR | Code Location | 30-second answer |
|---|---|---|---|
| Multi-tenancy | ARCH-06 | TenantHibernateFilter.java | ... |
| RAG retrieval | DATA-02 | retriever.py | ... |
| Human-in-the-loop | ARCH-08, AI-02 | human_review.py | ... |
[20+ rows covering the most likely interview questions]

OUTPUT: 1 file: docs/INTERVIEW_PREP.md
// FILE: docs/INTERVIEW_PREP.md
Full comprehensive content. Every question has a concrete answer with file references.
// ===== END OF FILE =====
==========================================

# ============================================================
# PROMPT-075: README.md — complete project README
# ============================================================

PROMPT-075 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the final README.md for the RCM platform repository.
This README is what an interviewer or reviewer sees first.

README.md structure:

# RCM Platform — Production-Grade Revenue Cycle Management with AI

## Overview
3-4 sentences: what this is, what problem it solves, what makes it interesting.

## Architecture
[Embed the C4 L2 container diagram from docs/diagrams/02-c4-containers.md as an ASCII art block]
[Link to all architecture docs]

## Technology Stack
Table: service | language | framework | key dependencies | why this choice
5 rows (one per service) + infrastructure row

## Key Features
Bullet list of interesting capabilities:
- LangGraph denial resolution agent with human-in-the-loop
- Hybrid pgvector + SQL retrieval (not pure vector search)
- PHI redaction before any LLM call (Presidio)
- Four-layer RAG evaluation (retrieval, generation, domain, operational)
- Full distributed tracing across Java/Python/Node.js boundary
- Semantic LLM response cache (pgvector-based, 0.97 cosine threshold)
- Consumer-driven Pact contract tests across polyglot boundary
- etc.

## Quick Start (5 commands)
```powershell
git clone <repo>
cd rcm-platform
.\scaffold.ps1          # create project structure
cp infrastructure/.env.example infrastructure/.env  # fill in values
docker compose -f infrastructure/docker-compose.yml up --build
```
Then: open http://localhost:3000

## Project Structure
Tree showing top-level directories with one-line explanations

## Architecture Decision Records
Table of all ADRs with one-sentence summary and status

## Running Tests
```
make test          # all tests
make test-java     # rcm-core
make test-python   # rcm-rag (includes eval harness)
make test-node     # rcm-notify + rcm-bff + rcm-ui
make test-contracts # Pact verification
make eval          # RAG eval harness
```

## Interview Prep
Link to docs/INTERVIEW_PREP.md with one-sentence description

## Design Decisions
Link to docs/adr/ with explanation of ADR format

OUTPUT: 1 file: README.md
// FILE: README.md
Complete README. Architecture diagram embedded. All sections filled.
// ===== END OF FILE =====
==========================================
