# BATCH C2 — Prompts 052–057
# rcm-rag: LLM layer + middleware + LangGraph agent + flows + API routes + eval harness
# GUIDED LATITUDE throughout.
# ============================================================

# ============================================================
# PROMPT-052: rcm-rag LLM layer — client, Azure OpenAI, Ollama, structured output, token counter
# ============================================================
# GOAL: Provider-abstracted LLM client + concrete implementations + output validation
# DEPENDS ON: PROMPT-046 PROMPT-047 PROMPT-051
# OUTPUT: 5 Python files in rcm-rag/rcm_rag/llm/
# ACCEPTANCE CRITERIA:
#   1. LLMClient is an abstract base — concrete impls swap via config
#   2. AzureOpenAIClient handles structured output via function calling
#      with Pydantic schema → JSON Schema conversion
#   3. OllamaClient falls back gracefully when model not available
#   4. StructuredOutputValidator retries once with correction prompt on failure
#   5. TokenCounter uses tiktoken with correct encoding per model
# ============================================================

PROMPT-052 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the LLM client layer for rcm-rag.
All LLM calls go through this layer — never directly to provider SDKs.

PACKAGE: rcm_rag.llm

client.py:
# Abstract LLM client interface.
# All LLM calls in the system go through this interface.
# Concrete implementations swap via config — application code stays the same.

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pydantic import BaseModel
import structlog

logger = structlog.get_logger()

@dataclass
class LLMRequest:
    system_prompt: str
    user_prompt: str
    output_schema: type[BaseModel] | None  # None = free text response
    prompt_id: str
    prompt_version: str
    tenant_id: str
    max_tokens: int = 1000
    temperature: float = 0.1

@dataclass
class LLMResponse:
    content: str              # raw response text
    parsed_output: BaseModel | None  # validated Pydantic object
    model_used: str
    input_tokens: int
    output_tokens: int
    latency_ms: int
    llm_call_id: str          # UUID for audit logging and caching

class BaseLLMClient(ABC):
    @abstractmethod
    async def complete(self, request: LLMRequest) -> LLMResponse:
        # Comment: "Abstract method forces all implementations to handle
        # the full LLMRequest contract. New providers can't accidentally
        # ignore fields like output_schema or tenant_id."
        ...

    async def complete_with_retry(
        self,
        request: LLMRequest,
        max_retries: int = 1,
    ) -> LLMResponse:
        # Retry logic using Tenacity
        # Comment: "Tenacity provides retry with exponential backoff.
        # We retry on: provider rate limits (429), transient errors (503).
        # We do NOT retry on: validation errors (400), auth errors (401),
        # or structured output validation failures (those get a correction prompt)."
        from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
        import httpx

        @retry(
            stop=stop_after_attempt(max_retries + 1),
            wait=wait_exponential(multiplier=1, min=1, max=10),
            retry=retry_if_exception_type((httpx.HTTPStatusError,)),
            reraise=True,
        )
        async def _attempt():
            return await self.complete(request)

        return await _attempt()

def create_llm_client(settings) -> BaseLLMClient:
    # Factory — returns provider based on config
    # Comment: "Factory pattern centralizes provider selection.
    # In tests: mock this function to inject a test double.
    # In prod: azure_openai. In dev: ollama. In CI: recorded responses."
    if settings.llm_provider == "azure_openai":
        from rcm_rag.llm.azure_openai_client import AzureOpenAIClient
        return AzureOpenAIClient(settings)
    from rcm_rag.llm.ollama_client import OllamaClient
    return OllamaClient(settings)

azure_openai_client.py:
# Azure OpenAI client with structured output support.
# Uses the openai Python SDK configured for Azure.

from openai import AsyncAzureOpenAI
from openai.types.chat import ChatCompletion
import json
import uuid
import time

class AzureOpenAIClient(BaseLLMClient):
    def __init__(self, settings):
        self.client = AsyncAzureOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            api_key=settings.azure_openai_key,
            api_version="2024-08-01-preview",
            # Comment: "api_version must match the version that supports
            # structured outputs / function calling. 2024-08-01-preview
            # supports the response_format=json_schema parameter."
        )
        self.settings = settings

    async def complete(self, request: LLMRequest) -> LLMResponse:
        start_time = time.monotonic()
        llm_call_id = str(uuid.uuid4())

        # Build messages
        messages = [
            {"role": "system", "content": request.system_prompt},
            {"role": "user", "content": request.user_prompt},
        ]

        # Structured output configuration
        # Comment: "Azure OpenAI structured output ensures the model returns
        # JSON matching our Pydantic schema. We convert the Pydantic model to
        # JSON Schema and pass it as response_format. This is more reliable than
        # prompt-based JSON instructions because the model is constrained at
        # the token level — it cannot produce invalid JSON."
        kwargs = {
            "model": request.output_schema and self.settings.azure_openai_mini_deployment
                     or self.settings.azure_openai_deployment,
            "messages": messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
        }

        if request.output_schema:
            schema = request.output_schema.model_json_schema()
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": {
                    "name": request.output_schema.__name__,
                    "schema": schema,
                    "strict": True,
                    # Comment: "strict=True means the model MUST follow the schema.
                    # Without this, it 'tries' to follow the schema but may deviate.
                    # Strict mode uses constrained decoding — slower but guaranteed."
                },
            }

        response: ChatCompletion = await self.client.chat.completions.create(**kwargs)

        latency_ms = int((time.monotonic() - start_time) * 1000)
        content = response.choices[0].message.content or ""

        return LLMResponse(
            content=content,
            parsed_output=None,  # StructuredOutputValidator handles parsing
            model_used=response.model,
            input_tokens=response.usage.prompt_tokens,
            output_tokens=response.usage.completion_tokens,
            latency_ms=latency_ms,
            llm_call_id=llm_call_id,
        )

ollama_client.py:
# Ollama client for local development.
# Calls Ollama's OpenAI-compatible API.

import httpx
import json
import uuid
import time

class OllamaClient(BaseLLMClient):
    def __init__(self, settings):
        self.base_url = settings.ollama_base_url
        self.model = settings.ollama_model
        # Comment: "Using Ollama's OpenAI-compatible endpoint (/v1/chat/completions)
        # rather than the native Ollama API (/api/generate) because it supports
        # the same message format as Azure OpenAI — minimal code differences."

    async def complete(self, request: LLMRequest) -> LLMResponse:
        start_time = time.monotonic()

        # Ollama structured output: use format='json' + schema in system prompt
        # Comment: "Ollama doesn't support OpenAI's response_format=json_schema yet.
        # We include the JSON schema in the system prompt and set format='json'
        # which enables Ollama's grammar-based JSON enforcement (less strict
        # than Azure OpenAI's constrained decoding, but workable)."
        system_prompt = request.system_prompt
        if request.output_schema:
            schema = json.dumps(request.output_schema.model_json_schema(), indent=2)
            system_prompt += f"\n\nRESPOND WITH JSON MATCHING THIS SCHEMA:\n{schema}"

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{self.base_url}/v1/chat/completions",
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": request.user_prompt},
                    ],
                    "format": "json" if request.output_schema else None,
                    "options": {"temperature": request.temperature},
                },
            )
            response.raise_for_status()
            data = response.json()

        latency_ms = int((time.monotonic() - start_time) * 1000)
        content = data["choices"][0]["message"]["content"]

        return LLMResponse(
            content=content,
            parsed_output=None,
            model_used=f"ollama/{self.model}",
            input_tokens=data.get("usage", {}).get("prompt_tokens", 0),
            output_tokens=data.get("usage", {}).get("completion_tokens", 0),
            latency_ms=latency_ms,
            llm_call_id=str(uuid.uuid4()),
        )

structured_output.py:
# Validates and parses LLM responses against Pydantic schemas.
# Retries once with a correction prompt if parsing fails.

from pydantic import BaseModel, ValidationError
import json

class StructuredOutputValidator:
    async def validate_and_parse(
        self,
        response: LLMResponse,
        schema: type[BaseModel],
        llm_client: BaseLLMClient,
        original_request: LLMRequest,
    ) -> BaseModel:
        # 1. Try parsing response.content as JSON + Pydantic validation
        try:
            raw_json = json.loads(response.content)
            return schema(**raw_json)
        except (json.JSONDecodeError, ValidationError) as first_error:
            # Comment: "First parse attempt failed. This happens when:
            # 1. Model adds markdown code blocks around JSON (json.JSONDecodeError)
            # 2. Model returns valid JSON but wrong structure (ValidationError)
            # 3. Model includes explanation text before/after JSON (JSONDecodeError)
            # We handle case 1 by stripping markdown, then retry the validation."

            # Try stripping markdown code blocks
            cleaned = response.content.strip()
            if cleaned.startswith("```"):
                cleaned = cleaned.split("```")[1]
                if cleaned.startswith("json"):
                    cleaned = cleaned[4:]
            try:
                raw_json = json.loads(cleaned)
                return schema(**raw_json)
            except (json.JSONDecodeError, ValidationError):
                pass

            # 2. Retry with correction prompt
            # Comment: "Correction prompt includes the original response and
            # the specific validation error. This gives the model exactly what
            # it needs to fix the output. We retry once — not in a loop —
            # because repeated retries on a fundamentally broken prompt won't help."
            correction_request = LLMRequest(
                system_prompt=original_request.system_prompt,
                user_prompt=(
                    f"{original_request.user_prompt}\n\n"
                    f"YOUR PREVIOUS RESPONSE WAS INVALID:\n{response.content}\n\n"
                    f"ERROR: {str(first_error)}\n\n"
                    f"Please respond ONLY with valid JSON matching the required schema. "
                    f"No markdown, no explanation — just the JSON object."
                ),
                output_schema=original_request.output_schema,
                prompt_id=original_request.prompt_id,
                prompt_version=original_request.prompt_version,
                tenant_id=original_request.tenant_id,
            )
            retry_response = await llm_client.complete(correction_request)

            try:
                raw_json = json.loads(retry_response.content)
                return schema(**raw_json)
            except (json.JSONDecodeError, ValidationError) as final_error:
                # Both attempts failed — raise typed error
                # Comment: "After two failures, we surface a typed error
                # rather than retrying infinitely. The caller (agent node or
                # flow) decides how to handle it — e.g., escalate to human,
                # return a structured error response, or log and continue."
                raise LLMValidationError(
                    f"Failed to parse LLM response after correction attempt",
                    original_error=str(first_error),
                    retry_error=str(final_error),
                    raw_response=retry_response.content,
                )

class LLMValidationError(Exception):
    def __init__(self, message, original_error, retry_error, raw_response):
        super().__init__(message)
        self.original_error = original_error
        self.retry_error = retry_error
        self.raw_response = raw_response

token_counter.py:
# Token counting using tiktoken — tracks usage for budget enforcement.

import tiktoken
from functools import lru_cache

@lru_cache(maxsize=10)
def _get_encoding(model_name: str):
    # Comment: "lru_cache prevents creating a new tiktoken encoder for
    # every token count call. Encoders are expensive to instantiate.
    # We cache by model name — different models use different encodings
    # (e.g., gpt-4o uses 'o200k_base', gpt-3.5-turbo uses 'cl100k_base')."
    try:
        return tiktoken.encoding_for_model(model_name)
    except KeyError:
        # Fallback for unknown/Ollama models
        return tiktoken.get_encoding("cl100k_base")

def count_tokens(text: str, model: str = "gpt-4o") -> int:
    encoding = _get_encoding(model)
    return len(encoding.encode(text))

def count_request_tokens(request: "LLMRequest") -> int:
    # Estimate tokens for a full request (system + user prompt)
    # Comment: "We estimate input tokens before the LLM call to check
    # budget. Post-call, we use the actual token counts from the response.
    # The pre-call estimate is deliberately slightly over-counted:
    # we add 10% buffer to account for message formatting overhead."
    model = request.output_schema and "gpt-4o-mini" or "gpt-4o"
    base_count = (
        count_tokens(request.system_prompt, model) +
        count_tokens(request.user_prompt, model)
    )
    return int(base_count * 1.1)  # 10% overhead buffer

OUTPUT: 5 files in rcm-rag/rcm_rag/llm/
Each: // FILE: path // ===== END OF FILE =====
Full async implementation. Comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-053: rcm-rag LLM middleware — budget, rate limit, token counting
# ============================================================
# GOAL: Three FastAPI middleware classes for LLM governance
# DEPENDS ON: PROMPT-046 PROMPT-047 PROMPT-052
# OUTPUT: 3 Python files in rcm-rag/rcm_rag/llm/middleware/
# ACCEPTANCE CRITERIA:
#   1. BudgetMiddleware checks AND increments Redis counter atomically
#   2. RateLimitMiddleware uses token bucket algorithm, not fixed window
#   3. TokenCountingMiddleware emits Prometheus metrics per-call
#   4. All middleware can be composed — they run in order as FastAPI dependencies
#   5. 429 responses include Retry-After header with reset timestamp
# ============================================================

PROMPT-053 CONTEXT — paste this into DeepSeek:
==========================================
You are generating LLM governance middleware for rcm-rag.
These are FastAPI dependencies injected into LLM-calling routes.

PACKAGE: rcm_rag.llm.middleware

budget_middleware.py:
# Per-tenant daily token budget enforcement.
# Prevents any single tenant from exhausting the system's LLM budget.

from fastapi import Depends, HTTPException
from rcm_rag.db.redis_client import get_redis
from rcm_rag.common.multitenancy import get_tenant
from datetime import datetime, timezone
import structlog
from prometheus_client import Counter, Gauge

logger = structlog.get_logger()

# Prometheus metrics
BUDGET_EXCEEDED_COUNTER = Counter(
    "llm_budget_exceeded_total",
    "Number of requests rejected due to budget exhaustion",
    ["tenant_id"],
)
BUDGET_REMAINING_GAUGE = Gauge(
    "llm_budget_remaining",
    "Remaining token budget for tenant (approximate)",
    ["tenant_id"],
)

class BudgetMiddleware:
    def __init__(self, settings):
        self.default_budget = settings.default_tenant_daily_token_budget
        # Comment: "Daily budget resets at midnight UTC. Redis key includes
        # the date so yesterday's key naturally expires. TTL of 25h gives
        # a small window for late-arriving requests without persisting stale data."

    async def check_and_reserve(
        self,
        estimated_tokens: int,
        tenant_id: str,
        redis,
    ) -> None:
        # Get current date for Redis key
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        budget_key = f"token_budget:{tenant_id}:{today}"

        # Atomic check-and-increment using Redis pipeline
        # Comment: "Pipeline makes INCR + GET atomic from our perspective —
        # no other client can increment between our check and our increment.
        # This prevents race conditions where two concurrent requests both
        # see 'budget available' but together would exceed the budget."
        async with redis.pipeline(transaction=True) as pipe:
            await pipe.incrby(budget_key, estimated_tokens)
            await pipe.expire(budget_key, 90_000)  # 25h in seconds
            results = await pipe.execute()

        current_usage = results[0]
        budget = await self._get_tenant_budget(tenant_id, redis)

        if current_usage > budget:
            # Rollback the increment — we're over budget
            # Comment: "We increment first, then check. If over budget, we
            # decrement back. Alternative: check-then-increment has a TOCTOU
            # race condition. Increment-then-check-then-rollback is safer."
            await redis.decrby(budget_key, estimated_tokens)
            BUDGET_EXCEEDED_COUNTER.labels(tenant_id=tenant_id).inc()

            reset_ts = int(
                datetime.now(timezone.utc).replace(
                    hour=23, minute=59, second=59
                ).timestamp()
            )
            raise HTTPException(
                status_code=429,
                detail={
                    "error": "token_budget_exceeded",
                    "used": current_usage - estimated_tokens,
                    "limit": budget,
                    "reset_at": datetime.fromtimestamp(reset_ts, tz=timezone.utc).isoformat(),
                },
                headers={"Retry-After": str(reset_ts)},
                # Comment: "Retry-After header tells clients exactly when to retry.
                # This is the correct HTTP 429 response format per RFC 6585."
            )

        BUDGET_REMAINING_GAUGE.labels(tenant_id=tenant_id).set(
            max(0, budget - current_usage)
        )

    async def _get_tenant_budget(self, tenant_id: str, redis) -> int:
        # Check for tenant-specific budget override in Redis
        # Fall back to default budget
        # Comment: "Per-tenant budget overrides allow premium tenants to have
        # higher limits. Stored in Redis as 'budget_limit:{tenant_id}':
        # set by admin API (not implemented in this version — documented for v2)."
        tenant_budget = await redis.cache_get(f"budget_limit:{tenant_id}")
        return int(tenant_budget) if tenant_budget else self.default_budget

rate_limit_middleware.py:
# Provider rate limit enforcement using token bucket algorithm.
# Prevents hitting Azure OpenAI's RPM (requests per minute) and
# TPM (tokens per minute) limits which would cause 429 errors from the provider.

import asyncio
import time
from prometheus_client import Counter, Gauge

RATE_LIMITED_COUNTER = Counter(
    "llm_rate_limit_rejected_total",
    "Requests rejected due to provider rate limits",
    ["provider"],
)
QUEUED_REQUESTS_GAUGE = Gauge(
    "llm_rate_limit_queued",
    "Requests currently queued waiting for rate limit",
    ["provider"],
)

class TokenBucketRateLimiter:
    # Token bucket algorithm for rate limiting.
    # Comment: "Token bucket chosen over fixed window because it allows
    # bursting up to the bucket capacity while maintaining the average rate.
    # Fixed window would reject all requests once the window limit is hit
    # even if the next window is seconds away — poor user experience.
    # Token bucket fills at a constant rate and allows burst consumption."

    def __init__(
        self,
        tokens_per_minute: int,      # Azure OpenAI TPM limit
        requests_per_minute: int,    # Azure OpenAI RPM limit
        max_queue_size: int = 10,
    ):
        self.tpm_limit = tokens_per_minute
        self.rpm_limit = requests_per_minute
        self.max_queue_size = max_queue_size

        # Token bucket state
        self._token_bucket = float(tokens_per_minute)
        self._request_bucket = float(requests_per_minute)
        self._last_refill = time.monotonic()
        self._queue_size = 0
        self._lock = asyncio.Lock()

    async def acquire(self, estimated_tokens: int, provider: str) -> None:
        # Check queue depth first (fail fast if queue is full)
        if self._queue_size >= self.max_queue_size:
            RATE_LIMITED_COUNTER.labels(provider=provider).inc()
            raise HTTPException(
                status_code=429,
                detail={"error": "provider_rate_limit", "provider": provider},
                headers={"Retry-After": "5"},
            )

        # Wait for token availability with exponential backoff
        max_wait_seconds = 30
        waited = 0
        while waited < max_wait_seconds:
            async with self._lock:
                self._refill()
                if (self._token_bucket >= estimated_tokens and
                    self._request_bucket >= 1):
                    self._token_bucket -= estimated_tokens
                    self._request_bucket -= 1
                    return  # acquired

            # Not enough tokens — wait
            self._queue_size += 1
            QUEUED_REQUESTS_GAUGE.labels(provider=provider).set(self._queue_size)
            # Comment: "Exponential backoff prevents thundering herd when
            # the rate limit is hit — all waiting coroutines don't retry
            # simultaneously. Start with 0.5s, double each time up to 4s."
            wait_time = min(0.5 * (2 ** (waited // 0.5)), 4.0)
            await asyncio.sleep(wait_time)
            waited += wait_time
            self._queue_size -= 1

        raise HTTPException(status_code=429, detail={"error": "rate_limit_timeout"})

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed_minutes = (now - self._last_refill) / 60
        self._token_bucket = min(
            self.tpm_limit,
            self._token_bucket + elapsed_minutes * self.tpm_limit
        )
        self._request_bucket = min(
            self.rpm_limit,
            self._request_bucket + elapsed_minutes * self.rpm_limit
        )
        self._last_refill = now

token_counting_middleware.py:
# Records actual token usage after each LLM call.
# Emits Prometheus metrics and updates Redis budget counter.

from prometheus_client import Counter, Histogram

TOKENS_USED_COUNTER = Counter(
    "llm_tokens_used_total",
    "Total tokens used in LLM calls",
    ["tenant_id", "model", "prompt_id"],
)
LLM_LATENCY_HISTOGRAM = Histogram(
    "llm_latency_seconds",
    "LLM call latency in seconds",
    ["model", "prompt_id"],
    buckets=[0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0],
)

class TokenCountingMiddleware:
    def __init__(self, redis_client):
        self.redis = redis_client

    async def record_usage(
        self,
        response: "LLMResponse",
        prompt_id: str,
        tenant_id: str,
    ) -> None:
        total_tokens = response.input_tokens + response.output_tokens

        # Prometheus metrics
        TOKENS_USED_COUNTER.labels(
            tenant_id=tenant_id,
            model=response.model_used,
            prompt_id=prompt_id,
        ).inc(total_tokens)

        LLM_LATENCY_HISTOGRAM.labels(
            model=response.model_used,
            prompt_id=prompt_id,
        ).observe(response.latency_ms / 1000)

        # Update Redis budget counter with actual tokens (not estimate)
        # Comment: "We estimated tokens for the budget check (pre-call).
        # Now we update with actual tokens. If actual < estimate (common),
        # the difference is automatically available for the next request
        # because the counter reflects cumulative actual usage."
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        budget_key = f"token_budget:{tenant_id}:{today}"
        actual_vs_estimate_delta = total_tokens  # add actual (estimate already added)
        await self.redis.incrby(budget_key, actual_vs_estimate_delta)

OUTPUT: 3 files in rcm-rag/rcm_rag/llm/middleware/
Each: // FILE: path // ===== END OF FILE =====
Full implementation. Token bucket algorithm complete. Prometheus metrics complete.
==========================================

# ============================================================
# PROMPT-054: rcm-rag LangGraph agent — state, graph, all 7 nodes, all 4 tools, persistence
# ============================================================
# GOAL: Complete LangGraph denial resolution agent
# DEPENDS ON: PROMPT-046 PROMPT-047 PROMPT-048 PROMPT-050 PROMPT-051 PROMPT-052
# OUTPUT: 14 Python files in rcm-rag/rcm_rag/agent/
# ACCEPTANCE CRITERIA:
#   1. AgentState is a TypedDict with all fields needed across all nodes
#   2. LangGraph graph is compiled with checkpointer for durable state
#   3. human_review node is a true LangGraph INTERRUPT (not simulated)
#   4. All 7 nodes update AgentState immutably (return updated copy)
#   5. All 4 tools have @tool decorator and type-annotated inputs/outputs
#   6. AgentStatePersistence saves/loads full state to/from Postgres
# ============================================================

PROMPT-054 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the LangGraph denial resolution agent for rcm-rag.
This is the most complex component in the system.

PACKAGE: rcm_rag.agent

AGENT FLOW (from PROMPT-010 sequence diagram):
triage → lookup_carc → fetch_payer_policy → check_medical_necessity
→ draft_appeal → human_review [INTERRUPT] → finalize
Conditional: triage → finalize (if escalate)
Retry: human_review → draft_appeal (if rejected)
Timeout: human_review → finalize (escalate after 48h)

state.py:
from typing import TypedDict, Annotated
from langgraph.graph.message import add_messages

class AgentState(TypedDict):
    # Core denial context
    denial_id: str
    tenant_id: str
    claim_id: str
    carc_code: str
    rarc_code: str | None
    payer_id: str
    cpt_codes: list[str]
    service_date: str
    payer_name: str

    # Retrieved data (accumulated as agent progresses)
    carc_definition: str | None     # from lookup_carc node
    rarc_definition: str | None
    retrieved_policies: list[dict] | None   # from fetch_payer_policy
    retrieved_medical_necessity: list[dict] | None  # from check_medical_necessity

    # Generated content
    denial_explanation: str | None  # from denial_explanation if run
    appeal_draft: str | None        # from draft_appeal
    approved_text: str | None       # from human_review (after biller edits)
    human_feedback: str | None      # biller's feedback on draft

    # Execution metadata
    current_node: str
    triage_classification: str | None  # "simple", "complex", "escalate"
    steps_completed: list[str]
    interrupted: bool
    interrupted_at: str | None      # ISO timestamp
    agent_run_id: str
    error: str | None               # set on node failure

    # LangGraph messages (for agent reasoning trace)
    messages: Annotated[list, add_messages]
    # Comment: "Annotated[list, add_messages] is LangGraph's way of declaring
    # that 'messages' should be accumulated (appended) rather than replaced
    # when nodes update the state. This is the LangGraph message accumulation pattern."

graph.py:
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

from rcm_rag.agent.state import AgentState
from rcm_rag.agent.nodes import (
    triage, lookup_carc, fetch_payer_policy,
    check_medical_necessity, draft_appeal, human_review, finalize
)

def build_denial_resolution_graph(checkpointer) -> "CompiledGraph":
    # Build the LangGraph state machine
    # Comment: "StateGraph is LangGraph's graph builder. Nodes are Python
    # functions that take AgentState and return updated state.
    # Edges define valid transitions. Conditional edges implement branching."

    builder = StateGraph(AgentState)

    # Add nodes
    builder.add_node("triage", triage.run)
    builder.add_node("lookup_carc", lookup_carc.run)
    builder.add_node("fetch_payer_policy", fetch_payer_policy.run)
    builder.add_node("check_medical_necessity", check_medical_necessity.run)
    builder.add_node("draft_appeal", draft_appeal.run)
    builder.add_node("human_review", human_review.run)
    builder.add_node("finalize", finalize.run)

    # Entry point
    builder.set_entry_point("triage")

    # Conditional edge from triage
    builder.add_conditional_edges(
        "triage",
        _route_after_triage,
        # Comment: "Conditional edges map routing function outputs to node names.
        # The routing function returns a string that matches a key in this dict.
        # This makes the control flow explicit and testable."
        {
            "lookup_carc": "lookup_carc",
            "finalize": "finalize",  # escalate path
        }
    )

    # Linear edges for the main path
    builder.add_edge("lookup_carc", "fetch_payer_policy")
    builder.add_edge("fetch_payer_policy", "check_medical_necessity")
    builder.add_edge("check_medical_necessity", "draft_appeal")
    builder.add_edge("draft_appeal", "human_review")

    # Conditional edge from human_review
    builder.add_conditional_edges(
        "human_review",
        _route_after_human_review,
        {
            "finalize": "finalize",       # approved
            "draft_appeal": "draft_appeal",  # rejected — re-draft
            END: END,                     # timeout/error
        }
    )

    builder.add_edge("finalize", END)

    # Compile with Postgres checkpointer for durable state
    # Comment: "The checkpointer persists agent state after each node completes.
    # This enables: 1) resuming after the human_review INTERRUPT,
    # 2) recovering from crashes mid-execution, 3) inspecting past runs.
    # AsyncPostgresSaver uses our existing Postgres connection pool."
    return builder.compile(
        checkpointer=checkpointer,
        interrupt_before=["human_review"],
        # Comment: "interrupt_before=['human_review'] tells LangGraph to
        # pause execution BEFORE entering human_review node and wait for
        # an external resume signal. This is the INTERRUPT mechanism.
        # The state is saved to Postgres and the coroutine returns —
        # execution resumes when .ainvoke() is called again with the same
        # thread_id and the same config."
    )

def _route_after_triage(state: AgentState) -> str:
    if state.get("triage_classification") == "escalate":
        return "finalize"
    return "lookup_carc"

def _route_after_human_review(state: AgentState) -> str:
    if state.get("interrupted"):
        return END  # Still waiting for human — shouldn't reach here
    if state.get("approved_text"):
        return "finalize"
    return "draft_appeal"  # Rejected — re-draft

NODE FILES (one per node):

nodes/triage.py:
async def run(state: AgentState) -> dict:
    # Classify denial as simple/complex/escalate based on CARC code
    # Simple: common codes with clear fix (16, 18, 29)
    # Complex: medical necessity, coding disputes (50, 57, 197)
    # Escalate: regulatory issues, fraud flags, >$10K claims
    # Comment: "Triage uses rule-based classification (no LLM) for speed
    # and predictability. The CARC code alone is usually sufficient to
    # determine the appropriate path. LLMs are expensive — don't use them
    # when rules suffice."
    carc = state["carc_code"]
    if carc in SIMPLE_DENIAL_CODES:
        classification = "simple"
    elif carc in ESCALATE_CODES:
        classification = "escalate"
    else:
        classification = "complex"

    return {
        "triage_classification": classification,
        "current_node": "triage",
        "steps_completed": state.get("steps_completed", []) + ["triage"],
    }

nodes/lookup_carc.py:
async def run(state: AgentState) -> dict:
    # Look up CARC and RARC code definitions from Postgres (L1 cached)
    # Uses CarcLookupTool
    ...

nodes/fetch_payer_policy.py:
async def run(state: AgentState) -> dict:
    # Retrieve payer policy chunks via pgvector
    # Uses PayerPolicyTool with payer_id + cpt_code filters
    ...

nodes/check_medical_necessity.py:
async def run(state: AgentState) -> dict:
    # Retrieve medical necessity documentation via pgvector
    # Uses MedicalNecessityTool with cpt_code + icd10_code filters
    ...

nodes/draft_appeal.py:
async def run(state: AgentState) -> dict:
    # 1. Redact PHI from state using PhiRedactor
    # 2. Load appeal-drafting prompt from registry
    # 3. Check semantic cache
    # 4. Check budget middleware
    # 5. Call LLM via client
    # 6. Validate with StructuredOutputValidator
    # 7. Rehydrate PHI tokens
    # 8. Return draft appeal text
    # Comment: "PHI redaction before LLM call, rehydration after —
    # the entire LLM interaction is PHI-free. The appeal draft returned
    # to the biller has real patient names restored by rehydration."
    ...

nodes/human_review.py:
async def run(state: AgentState) -> dict:
    # This node is an INTERRUPT point — it doesn't do LLM work.
    # It prepares the state for suspension and returns.
    # LangGraph's interrupt_before=['human_review'] causes execution to
    # pause BEFORE this node runs — so this code only runs on RESUME.

    # On resume (approved_text provided in state):
    if state.get("approved_text"):
        return {
            "interrupted": False,
            "current_node": "human_review",
            "steps_completed": state["steps_completed"] + ["human_review"],
        }

    # This branch reached if somehow invoked without approved_text
    # (shouldn't happen — defensive)
    return {"error": "human_review reached without approved_text"}

nodes/finalize.py:
async def run(state: AgentState) -> dict:
    # 1. Determine outcome: approved, escalated, or error
    # 2. Publish denial.explained Kafka event
    # 3. Write CosmosDB event 'appeal_submitted' or 'escalated'
    # 4. Update denial status in Postgres via service call
    # 5. Return final state
    ...

TOOL FILES:

tools/carc_lookup_tool.py:
from langchain_core.tools import tool

@tool
async def lookup_carc_definition(carc_code: str) -> dict:
    """Look up the definition and category of a CARC denial reason code.
    Returns the code description and whether it's typically disputable."""
    # Query Postgres CARC table (L1 cached)
    ...

tools/payer_policy_tool.py:
@tool
async def fetch_payer_policies(
    payer_id: str, cpt_codes: list[str], service_date: str
) -> list[dict]:
    """Retrieve relevant payer policy excerpts for the given procedure codes.
    Returns top-5 most relevant policy chunks for claim review."""
    # Use HybridRetriever with payer_id filter
    ...

tools/medical_necessity_tool.py:
@tool
async def fetch_medical_necessity_docs(cpt_code: str, icd10_code: str) -> list[dict]:
    """Retrieve medical necessity criteria for a procedure-diagnosis combination."""
    # Use HybridRetriever with source_type='medical_necessity' filter
    ...

tools/appeal_draft_tool.py:
@tool
async def draft_appeal_letter(
    denial_context: dict,
    retrieved_policies: list[dict],
    medical_necessity_docs: list[dict],
) -> dict:
    """Draft an appeal letter for a denied claim using AI assistance.
    The draft must be reviewed and approved by a human biller before submission."""
    # Orchestrates: PHI redact → prompt load → cache check → LLM call → validate → rehydrate
    ...

persistence.py:
# Saves and loads LangGraph agent state to/from Postgres.
# LangGraph's built-in checkpointer handles this via AsyncPostgresSaver,
# but we also maintain our own agent_states table for direct querying.

class AgentStatePersistence:
    async def save_initial_state(self, state: AgentState) -> None:
        # Insert into rag.agent_states table
        ...

    async def update_state(self, run_id: str, state: AgentState) -> None:
        # Update current_node, interrupted_at on state change
        ...

    async def load_state(self, run_id: str) -> AgentState | None:
        # Load from rag.agent_states table
        ...

    async def mark_interrupted(self, run_id: str) -> None:
        # Set interrupted=True, interrupted_at=now()
        ...

OUTPUT: 14 files in rcm-rag/rcm_rag/agent/
Each: // FILE: full/path // ===== END OF FILE =====
Full LangGraph implementation. All nodes complete. Human-in-the-loop INTERRUPT correct.
==========================================

# ============================================================
# PROMPT-055: rcm-rag flows + gRPC servicer + Kafka consumer/producer
# ============================================================
# GOAL: ClaimScrubbingFlow (gRPC), DenialExplanationFlow (Kafka),
#       gRPC servicer implementation, Kafka consumer + producer
# DEPENDS ON: PROMPT-046 PROMPT-050 PROMPT-051 PROMPT-052 PROMPT-054
# OUTPUT: 6 Python files
# ACCEPTANCE CRITERIA:
#   1. gRPC servicer correctly maps proto messages to/from domain objects
#   2. ClaimScrubbingFlow orchestrates: retrieve → prompt → LLM → validate → respond
#      all within 3 second budget
#   3. DenialExplanationFlow triggers the LangGraph agent asynchronously
#   4. Kafka consumer uses aiokafka with manual commit
#   5. denial.explained producer publishes after agent completion
# ============================================================

PROMPT-055 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the flow orchestration, gRPC, and Kafka layers for rcm-rag.

PACKAGE: rcm_rag.flows, rcm_rag.grpc, rcm_rag.kafka

flows/claim_scrubbing.py:
# Orchestrates the claim scrubbing flow called via gRPC from rcm-core.
# Must complete within 3 seconds (Resilience4j timeout on Java side).

class ClaimScrubbingFlow:
    def __init__(self, retriever, prompt_registry, llm_client,
                 validator, phi_redactor, feature_flags, audit_service):
        ...

    async def scrub(
        self, request: "ClaimScrubRequest"  # proto-generated
    ) -> "ClaimScrubResponse":  # proto-generated
        tenant_id = request.tenant_id

        # 1. Check feature flag
        if not await self.feature_flags.is_enabled("rag.claim-scrubbing", tenant_id):
            # Return pass (no LLM scrubbing when flag is off)
            return self._build_response(request.claim_id, passed=True, issues=[])

        # 2. Build retrieval query from claim data
        query = RetrievalQuery(
            query_text=self._build_query_text(request),
            # Comment: "Query text combines CPT codes and diagnoses so the
            # vector search finds policies relevant to this specific procedure-
            # diagnosis combination, not just any policy for this payer."
            tenant_id=tenant_id,
            payer_id=request.payer_id,
            effective_date=request.service_date,
            source_type="payer_policy",
            top_k=5,
        )

        # 3. Retrieve policies
        chunks = await self.retriever.retrieve(query)

        if not chunks:
            # No relevant policies found — pass without LLM
            # Comment: "If no payer policies are indexed for this payer/CPT combination,
            # we can't do AI-enhanced scrubbing. Return PASS with a warning note.
            # This is better than blocking the claim submission because of a missing
            # corpus document — a human reviewer can check manually."
            return self._build_response(request.claim_id, passed=True, issues=[
                self._warning("NO_POLICY_FOUND",
                    "No payer policy documents found for this procedure. "
                    "Manual review recommended.")
            ])

        # 4. PHI redaction (claim data has provider NPIs but not patient PHI —
        #    NPIs are redacted as they could identify providers)
        # 5. Build prompt and call LLM
        # 6. Validate structured output
        # 7. Map to proto response
        # 8. Audit log
        ...

flows/denial_explanation.py:
# Triggered by Kafka consumer when denial.received event is consumed.
# Creates and runs the LangGraph denial resolution agent.

class DenialExplanationFlow:
    def __init__(self, agent_graph, agent_persistence, kafka_producer,
                 audit_service, session_factory):
        ...

    async def process_denial(self, event: dict) -> None:
        # Build initial AgentState from Kafka event
        initial_state: AgentState = {
            "denial_id": event["denialId"],
            "tenant_id": event["tenantId"],
            "claim_id": event["claimId"],
            "carc_code": event["carcCode"],
            "rarc_code": event.get("rarcCode"),
            "payer_id": event["payerId"],
            "cpt_codes": [],  # fetched from Postgres if needed
            "service_date": event["denialDate"],
            "payer_name": "",  # fetched from Postgres
            "agent_run_id": str(uuid.uuid4()),
            "current_node": "start",
            "steps_completed": [],
            "interrupted": False,
            "messages": [],
        }

        # Persist initial state
        await self.agent_persistence.save_initial_state(initial_state)

        # Run the graph (will interrupt at human_review)
        # Comment: "thread_id is the LangGraph session identifier.
        # We use denial_id as the thread_id — ensuring the same denial
        # always maps to the same LangGraph session for resumption."
        config = {"configurable": {"thread_id": initial_state["denial_id"]}}

        try:
            await self.agent_graph.ainvoke(initial_state, config=config)
            # If we reach here: agent either completed or interrupted
            final_state = await self.agent_graph.aget_state(config)
            await self.agent_persistence.update_state(
                initial_state["agent_run_id"], final_state.values
            )
        except Exception as e:
            # Agent failed — mark as escalated
            await self.agent_persistence.update_state(
                initial_state["agent_run_id"],
                {**initial_state, "error": str(e), "triage_classification": "escalate"}
            )

grpc/claim_scrub_servicer.py:
# gRPC server implementation — receives calls from rcm-core.

import grpc
import asyncio
from rcm.v1 import claim_scrubbing_pb2, claim_scrubbing_pb2_grpc

class ClaimScrubServicer(claim_scrubbing_pb2_grpc.ClaimScrubServiceServicer):
    def __init__(self, scrubbing_flow: ClaimScrubbingFlow):
        self.flow = scrubbing_flow

    async def ScrubClaim(
        self,
        request: claim_scrubbing_pb2.ClaimScrubRequest,
        context: grpc.aio.ServicerContext,
    ) -> claim_scrubbing_pb2.ClaimScrubResponse:
        # Comment: "gRPC ServicerContext carries the deadline set by the client.
        # The Java client sets a 3-second deadline via Resilience4j TimeLimiter.
        # We check the deadline before starting expensive operations."
        if context.time_remaining() < 0.5:
            await context.abort(
                grpc.StatusCode.DEADLINE_EXCEEDED,
                "Insufficient time remaining to process scrub request"
            )
            return

        # Set tenant context from gRPC metadata
        metadata = dict(context.invocation_metadata())
        tenant_id = request.tenant_id
        set_tenant(tenant_id)

        try:
            return await self.flow.scrub(request)
        except Exception as e:
            await context.abort(grpc.StatusCode.INTERNAL, str(e))

async def start_grpc_server() -> None:
    server = grpc.aio.server()
    # Add servicer (dependencies injected via app.state)
    # Add insecure port (mTLS in prod — documented in SEC-03 ADR)
    server.add_insecure_port(f"0.0.0.0:{settings.grpc_port}")
    await server.start()
    await server.wait_for_termination()

kafka/consumer.py:
# Async Kafka consumer for denial.received topic.

from aiokafka import AIOKafkaConsumer
import json

async def start_kafka_consumer() -> None:
    consumer = AIOKafkaConsumer(
        "denial.received",
        bootstrap_servers=settings.kafka_bootstrap_servers,
        group_id=settings.kafka_group_id,
        # Comment: "enable_auto_commit=False requires manual offset commits.
        # We commit only after successfully processing the message (creating
        # the Denial record and triggering the agent). If processing fails,
        # the message is reprocessed on restart — idempotency check in
        # DenialExplanationFlow prevents duplicate processing."
        enable_auto_commit=False,
        auto_offset_reset="earliest",
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
    )

    await consumer.start()
    try:
        async for msg in consumer:
            try:
                # Process denial event
                from rcm_rag.flows.denial_explanation import DenialExplanationFlow
                flow = DenialExplanationFlow(...)  # from app.state
                await flow.process_denial(msg.value)
                # Manual commit after successful processing
                await consumer.commit()
            except Exception as e:
                logger.error("denial_processing_failed",
                    error=str(e), message=msg.value)
                # Don't commit — message will be reprocessed
                # Comment: "Not committing on failure means Kafka will
                # redeliver the message. Combined with idempotency checking,
                # this ensures at-least-once processing: we may process twice,
                # but never zero times."
    finally:
        await consumer.stop()

kafka/producer.py:
# Kafka producer for denial.explained events.

from aiokafka import AIOKafkaProducer
import json

_producer: AIOKafkaProducer | None = None

async def init_producer() -> None:
    global _producer
    _producer = AIOKafkaProducer(
        bootstrap_servers=settings.kafka_bootstrap_servers,
        acks="all",  # Wait for all replicas — durability
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        key_serializer=lambda v: v.encode("utf-8") if v else None,
    )
    await _producer.start()

async def publish_denial_explained(denial_id: str, event: dict) -> None:
    # Key = denial_id for ordering (all events for a denial → same partition)
    await _producer.send_and_wait(
        "denial.explained",
        key=denial_id,
        value=event,
    )

OUTPUT: 6 files.
// FILE: rcm-rag/rcm_rag/flows/claim_scrubbing.py
// FILE: rcm-rag/rcm_rag/flows/denial_explanation.py
// FILE: rcm-rag/rcm_rag/grpc/claim_scrub_servicer.py
// FILE: rcm-rag/rcm_rag/kafka/consumer.py
// FILE: rcm-rag/rcm_rag/kafka/producer.py
// FILE: rcm-rag/rcm_rag/grpc/__init__.py
Each: // FILE: path // ===== END OF FILE =====
Full async implementation. gRPC servicer complete. Kafka consumer with manual commit.
==========================================

# ============================================================
# PROMPT-056: rcm-rag API routes + Pydantic schemas
# ============================================================
# GOAL: All FastAPI routers + all Pydantic output schemas
# DEPENDS ON: PROMPT-046 PROMPT-051 PROMPT-054 PROMPT-055
# OUTPUT: 9 Python files
# ACCEPTANCE CRITERIA:
#   1. All schemas match the OpenAPI spec from PROMPT-018
#   2. health.py returns detailed health including FAISS index loaded status
#   3. denial.py has SSE endpoint streaming agent progress
#   4. eval.py triggers eval harness and returns job ID
#   5. All routes use FastAPI dependencies for auth, tenant, audit
# ============================================================

PROMPT-056 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the FastAPI API routes and Pydantic schemas for rcm-rag.

SCHEMAS (rcm_rag/schemas/):

scrub_result.py:
class ScrubIssue(BaseModel):
    issue_code: str
    severity: Literal["BLOCKING", "WARNING"]
    description: str
    affected_field: str | None = None
    policy_reference: str | None = None
    suggested_fix: str | None = None

class ScrubResult(BaseModel):
    passed: bool
    issues: list[ScrubIssue] = []
    retrieved_policy_count: int = 0
    llm_model_used: str | None = None
    llm_called: bool = False
    processing_time_ms: int = 0

denial_explanation.py:
class DenialExplanation(BaseModel):
    plain_english_reason: str  # why denied, in clear language
    is_disputable: bool        # is this denial worth appealing?
    supporting_documentation: list[str]  # what to gather for appeal
    appeal_likelihood: Literal["HIGH", "MEDIUM", "LOW"]
    appeal_likelihood_reasoning: str

appeal_draft.py:
class AppealDraft(BaseModel):
    letter_text: str           # the full appeal letter with [TOKEN] placeholders
    key_arguments: list[str]   # summary of arguments made
    documentation_required: list[str]  # what to attach to the appeal

agent_state.py:
class AgentStepResponse(BaseModel):
    node_name: str
    completed_at: str
    success: bool

class AgentStatusResponse(BaseModel):
    denial_id: str
    agent_run_id: str
    current_node: str
    interrupted: bool
    interrupted_at: str | None
    steps_completed: list[AgentStepResponse]
    estimated_completion: str | None

medical_necessity.py:
class MedicalNecessityAssessment(BaseModel):
    likely_meets_criteria: bool
    met_criteria: list[str]
    unmet_criteria: list[str]
    documentation_gaps: list[str]
    confidence: Literal["HIGH", "MEDIUM", "LOW"]

API ROUTES (rcm_rag/api/):

router.py:
# Main router that includes all sub-routers
from fastapi import APIRouter
from rcm_rag.api import health, ingestion, retrieval, denial, eval

api_router = APIRouter()
api_router.include_router(health.router, tags=["health"])
api_router.include_router(ingestion.router, prefix="/ingestion", tags=["ingestion"])
api_router.include_router(retrieval.router, prefix="/retrieval", tags=["retrieval"])
api_router.include_router(denial.router, prefix="/denial", tags=["denial"])
api_router.include_router(eval.router, prefix="/eval", tags=["eval"])

health.py:
@router.get("/health")
async def health_check(request: Request) -> dict:
    return {
        "status": "healthy",
        "version": settings.app_version,
        "faiss_index_loaded": hasattr(request.app.state, "faiss_cache"),
        "pgvector_connected": await _check_pgvector(),
        "kafka_connected": await _check_kafka(),
    }

ingestion.py:
@router.post("/ingest", status_code=202)
async def ingest_documents(
    request: IngestRequest,
    tenant_id: str = Depends(get_current_tenant),
    session: AsyncSession = Depends(get_session),
) -> dict:
    # Trigger async ingestion, return job ID
    ...

@router.get("/status/{job_id}")
async def get_ingestion_status(job_id: str) -> dict: ...

retrieval.py (admin/debug endpoint):
@router.post("/search")
async def search_chunks(
    request: SearchRequest,
    tenant_id: str = Depends(get_current_tenant),
) -> dict:
    # Debug endpoint — search pgvector and return chunks with scores
    # Requires admin role
    ...

denial.py:
@router.get("/{denial_id}/status")
async def get_denial_status(
    denial_id: str,
    tenant_id: str = Depends(get_current_tenant),
    session: AsyncSession = Depends(get_session),
) -> AgentStatusResponse: ...

@router.post("/agent/resume/{run_id}")
async def resume_agent(
    run_id: str,
    body: ResumeRequest,  # {approved_text, reviewer_id, feedback}
    tenant_id: str = Depends(get_current_tenant),
) -> AgentStatusResponse:
    # Resume LangGraph agent after human approval
    # Load state from Postgres, update with approved_text, invoke graph
    ...

# SSE endpoint — streams agent progress to rcm-bff
@router.get("/{denial_id}/stream")
async def stream_denial_status(
    denial_id: str,
    request: Request,
    tenant_id: str = Depends(get_current_tenant),
) -> EventSourceResponse:
    # Comment: "SSE (Server-Sent Events) over HTTP for streaming agent progress.
    # The BFF maintains one SSE connection per open denial review screen.
    # We poll Postgres for status changes and push updates.
    # Alternative: WebSocket (bidirectional, more complex for one-way streaming)."
    from sse_starlette.sse import EventSourceResponse

    async def event_generator():
        previous_node = None
        while True:
            status = await _get_agent_status(denial_id, tenant_id, session)
            if status.current_node != previous_node:
                yield {"data": status.model_dump_json()}
                previous_node = status.current_node
            if status.current_node in ("finalize", "error"):
                break
            await asyncio.sleep(2)

    return EventSourceResponse(event_generator())

eval.py:
@router.post("/run", status_code=202)
async def trigger_eval(request: EvalRunRequest) -> dict:
    # Trigger eval harness in background task
    ...

@router.get("/results/{job_id}")
async def get_eval_results(job_id: str) -> dict: ...

OUTPUT: 9 files (5 schemas + 1 router + 5 route files — health/ingestion/retrieval/denial/eval share 1 router file, eval.py is separate).
Each: // FILE: path // ===== END OF FILE =====
Full FastAPI implementation. All deps injected. SSE endpoint complete.
==========================================

# ============================================================
# PROMPT-057: rcm-rag eval harness + all tests
# ============================================================
# GOAL: Complete eval harness + golden sets + all unit/integration/pact tests
# DEPENDS ON: PROMPT-046 through PROMPT-056
# OUTPUT: ~15 files in rcm-rag/evals/ and rcm-rag/tests/
# ACCEPTANCE CRITERIA:
#   1. runner.py runs all 4 metric layers and writes results to Postgres
#   2. retrieval_metrics.py implements recall@k, precision@k, MRR, NDCG from scratch
#   3. generation_metrics.py wraps RAGAS + HuggingFace evaluate
#   4. golden sets have 20 realistic test cases each with expected outputs
#   5. CI mode: exits with code 1 if any metric below threshold
# ============================================================

PROMPT-057 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the evaluation harness and test suite for rcm-rag.

PACKAGE: rcm_rag.evals

evals/runner.py:
# Main eval runner — orchestrates all metric layers.

import asyncio
import json
import argparse
from pathlib import Path
import structlog

logger = structlog.get_logger()

class EvalRunner:
    def __init__(self, retriever, llm_client, session_factory, settings):
        ...

    async def run(
        self,
        eval_set: str,          # "claim_scrubbing" or "denial_explanation"
        prompt_id: str | None,  # None = test all prompts
        ci_mode: bool = False,  # True = exit 1 on threshold failure
    ) -> dict:
        # Load golden set
        golden_path = Path(__file__).parent / "golden_sets" / f"{eval_set}_golden.json"
        with open(golden_path) as f:
            golden_cases = json.load(f)

        results = {
            "eval_set": eval_set,
            "total_cases": len(golden_cases),
            "layer1_retrieval": {},
            "layer2_generation": {},
            "layer3_domain": {},
            "layer4_operational": {},
            "passed_thresholds": True,
            "failed_metrics": [],
        }

        # Layer 1: Retrieval metrics
        from rcm_rag.evals.metrics.retrieval_metrics import RetrievalMetrics
        retrieval_results = await RetrievalMetrics(self.retriever).evaluate(golden_cases)
        results["layer1_retrieval"] = retrieval_results

        # Layer 2: Generation metrics (requires LLM judge for RAGAS)
        from rcm_rag.evals.metrics.generation_metrics import GenerationMetrics
        generation_results = await GenerationMetrics(self.llm_client).evaluate(golden_cases)
        results["layer2_generation"] = generation_results

        # Layer 3: Domain metrics
        from rcm_rag.evals.metrics.domain_metrics import DomainMetrics
        domain_results = DomainMetrics().evaluate(golden_cases)
        results["layer3_domain"] = domain_results

        # Check thresholds
        thresholds = self._load_thresholds()
        for metric, value in {**retrieval_results, **generation_results, **domain_results}.items():
            if metric in thresholds and value < thresholds[metric]:
                results["passed_thresholds"] = False
                results["failed_metrics"].append({
                    "metric": metric,
                    "value": value,
                    "threshold": thresholds[metric],
                })

        # Save results to Postgres
        await self._save_results(results, prompt_id or "all")

        if ci_mode and not results["passed_thresholds"]:
            logger.error("eval_thresholds_failed", failed=results["failed_metrics"])
            raise SystemExit(1)

        return results

evals/metrics/retrieval_metrics.py:
# Custom implementations of information retrieval metrics.
# No external library — these are standard metrics worth implementing from scratch
# because understanding them is important for interviews.

class RetrievalMetrics:
    async def evaluate(self, cases: list[dict]) -> dict:
        # For each case: run retrieval, compare against relevant_chunk_ids in golden set
        # Compute: recall@1, recall@3, recall@5, recall@10,
        #          precision@5, MRR, NDCG@5, hit_rate@5
        ...

    def recall_at_k(self, relevant: set[str], retrieved: list[str], k: int) -> float:
        # Comment: "Recall@k = |relevant ∩ retrieved[:k]| / |relevant|
        # Measures: of all relevant chunks, what fraction did we retrieve in top k?
        # This is the PRIMARY retrieval metric for RAG systems.
        # Low recall@k means the LLM doesn't have the information it needs —
        # even a perfect LLM can't answer correctly from incomplete context."
        if not relevant:
            return 1.0  # No relevant chunks → vacuously perfect
        retrieved_k = set(retrieved[:k])
        return len(relevant & retrieved_k) / len(relevant)

    def precision_at_k(self, relevant: set[str], retrieved: list[str], k: int) -> float:
        # Comment: "Precision@k = |relevant ∩ retrieved[:k]| / k
        # Measures: of the k chunks retrieved, what fraction are relevant?
        # High precision = few irrelevant chunks in LLM context.
        # Irrelevant chunks waste context tokens and can distract the LLM."
        retrieved_k = retrieved[:k]
        return sum(1 for r in retrieved_k if r in relevant) / k

    def mrr(self, relevant: set[str], retrieved: list[str]) -> float:
        # Comment: "MRR (Mean Reciprocal Rank): 1 / rank_of_first_relevant_chunk
        # MRR=1.0: first result is relevant. MRR=0.5: second result is first relevant.
        # Important for single-answer retrieval where only one chunk is authoritative."
        for rank, chunk_id in enumerate(retrieved, 1):
            if chunk_id in relevant:
                return 1.0 / rank
        return 0.0

    def ndcg_at_k(self, relevant: set[str], retrieved: list[str], k: int) -> float:
        # Comment: "NDCG (Normalized Discounted Cumulative Gain): weighted ranking quality.
        # Penalizes relevant chunks that appear lower in the ranking.
        # The discount function is log2(rank+1) — higher rank = less penalty.
        # Normalized: divided by ideal DCG (all relevant chunks at top).
        # Best when relevance is graded (here we use binary: relevant=1, not=0)."
        import math
        dcg = sum(
            1 / math.log2(rank + 2)
            for rank, chunk_id in enumerate(retrieved[:k])
            if chunk_id in relevant
        )
        ideal_dcg = sum(
            1 / math.log2(rank + 2)
            for rank in range(min(len(relevant), k))
        )
        return dcg / ideal_dcg if ideal_dcg > 0 else 0.0

evals/metrics/generation_metrics.py:
# RAGAS + HuggingFace evaluate for generation quality metrics.

from ragas import evaluate as ragas_evaluate
from ragas.metrics import faithfulness, answer_relevancy, context_relevancy
from datasets import Dataset
import evaluate as hf_evaluate

class GenerationMetrics:
    async def evaluate(self, cases: list[dict]) -> dict:
        # Build RAGAS Dataset from golden cases
        # Run RAGAS metrics: faithfulness, answer_relevancy, context_relevancy
        # Run HuggingFace: BLEU-4, ROUGE-L, BERTScore
        ...

evals/metrics/domain_metrics.py:
# RCM-specific evaluation metrics.

class DomainMetrics:
    def evaluate(self, cases: list[dict]) -> dict:
        carc_accuracy = self._compute_carc_accuracy(cases)
        return {"carc_accuracy": carc_accuracy}

    def _compute_carc_accuracy(self, cases: list[dict]) -> float:
        # Comment: "CARC accuracy: does the generated response correctly
        # identify the CARC code that caused the denial?
        # We check if the expected CARC code appears in the generated response.
        # This is a binary check — the code either appears or it doesn't.
        # A more sophisticated version would check semantic equivalence
        # (e.g., 'prior authorization required' = CARC 197)."
        correct = sum(
            1 for case in cases
            if case.get("expected_carc") in case.get("generated_response", "")
        )
        return correct / len(cases) if cases else 0.0

evals/thresholds.yaml:
# Minimum acceptable scores for each metric.
# CI fails if any metric falls below its threshold.
recall_at_5: 0.75
precision_at_5: 0.60
mrr: 0.70
ndcg_at_5: 0.65
faithfulness: 0.85     # Most important — hallucination prevention
answer_relevance: 0.80
context_relevance: 0.70
carc_accuracy: 0.80
bleu4: 0.30
rouge_l: 0.50
cosine_similarity: 0.75

GOLDEN SET FILES (realistic synthetic test cases):

evals/golden_sets/denial_explanation_golden.json:
20 test cases. Each case:
{
  "case_id": "DE-001",
  "denial_context": {
    "carc_code": "197",
    "rarc_code": "N115",
    "cpt_code": "27447",
    "payer_name": "Aetna",
    "service_date": "2024-03-15"
  },
  "relevant_chunk_ids": ["chunk-uuid-1", "chunk-uuid-2"],  # from seed corpus
  "expected_carc": "197",  # for carc_accuracy metric
  "reference_answer": "This claim was denied because prior authorization was not obtained before the knee replacement surgery. CARC code 197 indicates precertification was absent. To appeal, the provider must submit documentation showing medical necessity and, if applicable, evidence that prior auth was requested but not processed.",
  "expected_pass": false,
  "notes": "Common denial — prior auth for elective surgery"
}
Generate 20 varied cases covering: CARC 197, 50, 29, 16, 4, 57, 119, 45, 236, 58
and various payers.

evals/golden_sets/claim_scrubbing_golden.json:
20 test cases for claim scrubbing eval.
Each case: claim fields + expected scrub result (pass/fail + expected issues).
Mix of: should pass (10), should fail with BLOCKING (6), should warn (4).

TESTS (rcm-rag/tests/):

tests/unit/test_phi_redactor.py:
# Verify: SSN redacted, patient name redacted, NPI redacted
# Verify: rehydration restores original values
# Verify: text without PHI passes through unchanged
# Verify: multiple instances of same type get unique tokens

tests/unit/test_chunker.py:
# Verify: chunks are semantically coherent (each chunk > 50 tokens)
# Verify: metadata from source document flows to chunks
# Verify: no empty chunks produced

tests/unit/test_retriever.py:
# Verify: SQL WHERE clause includes tenant_id filter
# Verify: payer_id filter applied when provided
# Verify: effective_date filter correct SQL
# Mock pgvector responses and verify RetrievedChunk mapping

tests/unit/test_structured_output.py:
# Verify: valid JSON response parsed correctly
# Verify: markdown-wrapped JSON stripped and parsed
# Verify: invalid JSON triggers retry with correction prompt
# Verify: two failures raises LLMValidationError

tests/unit/test_prompt_registry.py:
# Verify: all 4 prompts loaded at startup
# Verify: latest version returned when version omitted
# Verify: specific version returned when specified
# Verify: KeyError on unknown prompt_id
# Verify: format_user_prompt fills placeholders

tests/unit/test_token_counter.py:
# Verify: count_tokens returns > 0 for non-empty string
# Verify: count_request_tokens > count_tokens (includes overhead)

tests/unit/test_agent_graph.py:
# Verify: graph builds without error
# Verify: triage routes correctly based on CARC code
# Verify: AgentState TypedDict has all required fields

tests/integration/test_ingestion_pipeline.py:
# Testcontainers Postgres with pgvector
# Ingest one synthetic policy document
# Verify: document, chunks, embeddings all in DB
# Verify: idempotent re-ingestion updates not duplicates
# Verify: tenant isolation on retrieval

tests/integration/test_claim_scrubbing_grpc.py:
# Start gRPC server in-process
# Send ClaimScrubRequest
# Verify: response received, mapped correctly
# Verify: feature flag off → pass returned without LLM call

tests/integration/test_denial_kafka_flow.py:
# Testcontainers Kafka
# Publish denial.received event
# Verify: consumer processes, agent state created in Postgres

tests/integration/test_semantic_cache.py:
# Testcontainers Postgres + Redis
# Store LLM response in cache
# Query with same text → exact cache hit
# Query with similar text → semantic cache hit (if similarity > 0.97)
# Query with different text → miss

tests/pact/test_pact_provider.py:
# Verify pacts generated by rcm-bff consumer tests
# rcm-bff tests generate pacts for: GET /v1/denial/{id}/status,
#   POST /v1/agent/resume/{run_id}
# This file verifies rcm-rag satisfies those pacts

scripts/ingest_corpus.py:
# One-time script to ingest the seed data corpus into pgvector
# Run after: docker compose up postgres rcm-rag
# Processes: all 4 synthetic payer policy files + CARC definitions
# Logs progress: documents loaded, chunks created, embeddings generated

OUTPUT: ~15 files across evals/ and tests/ directories.
Each: // FILE: path // ===== END OF FILE =====
Full implementation. Metrics from scratch with commented formulas.
Golden sets are realistic RCM test cases — not toy examples.
==========================================
