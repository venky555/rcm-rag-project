# BATCH C2 — Prompts 046–051
# rcm-rag FastAPI: scaffold + common + DB clients + ingestion + retrieval + prompts
# GUIDED LATITUDE throughout.
# Every non-trivial line must have an inline comment explaining intent.
# ============================================================

# ============================================================
# PROMPT-046: rcm-rag Scaffold — pyproject.toml + main.py + config.py + Dockerfile
# ============================================================
# GOAL: FastAPI application entry point, configuration, and container setup
# DEPENDS ON: PROMPT-003 PROMPT-018
# OUTPUT: rcm-rag/pyproject.toml
#         rcm-rag/ruff.toml
#         rcm-rag/mypy.ini
#         rcm-rag/Dockerfile
#         rcm-rag/.dockerignore
#         rcm-rag/rcm_rag/__init__.py
#         rcm-rag/rcm_rag/main.py
#         rcm-rag/rcm_rag/config.py
# ACCEPTANCE CRITERIA:
#   1. pyproject.toml lists ALL deps from 03_PINNED_TECH_STACK.md exactly
#   2. main.py starts both FastAPI (HTTP) and gRPC servers concurrently
#      using asyncio — explain how in comments
#   3. config.py uses pydantic-settings with env var override — no secrets hardcoded
#   4. Dockerfile is multi-stage: builder installs deps, runtime is slim
#   5. Lifespan context manager handles startup (FAISS index load) and
#      shutdown (graceful) — not deprecated @app.on_event
# ============================================================

PROMPT-046 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the scaffold for rcm-rag, the Python 3.12 FastAPI
service handling RAG, embeddings, LLM orchestration, and the LangGraph
denial resolution agent.

ARCHITECTURE CONTEXT:
rcm-rag serves two protocols simultaneously:
1. HTTP/REST on port 8091 — management endpoints, denial status, eval
2. gRPC on port 50051 — claim scrubbing (called by rcm-core)
Both run in the same Python process using asyncio.

PINNED VERSIONS (exact — no deviations):
fastapi==0.115.0, uvicorn==0.30.6, pydantic==2.8.2,
pydantic-settings==2.4.0, sqlalchemy==2.0.35, asyncpg==0.29.0,
pgvector==0.3.2, llama-index==0.11.2,
llama-index-vector-stores-postgres==0.2.2,
langchain==0.3.1, langgraph==0.2.16, langchain-openai==0.2.1,
langchain-community==0.3.1, faiss-cpu==1.8.0,
sentence-transformers==3.1.1, presidio-analyzer==2.2.354,
presidio-anonymizer==2.2.354, aiokafka==0.11.0, motor==3.5.1,
azure-cosmos==4.7.0, redis[asyncio]==5.0.8, grpcio==1.66.1,
grpcio-tools==1.66.1, opentelemetry-sdk==1.27.0,
opentelemetry-instrumentation-fastapi==0.48b0,
prometheus-client==0.21.0, structlog==24.4.0, tiktoken==0.7.0,
ragas==0.1.21, evaluate==0.4.3, cachetools==5.5.0, tenacity==9.0.0,
python-jose==3.3.0, pytest==8.3.3, pytest-asyncio==0.24.0,
pytest-cov==5.0.0, testcontainers==4.8.1, pact-python==2.2.1,
httpx==0.27.2, ruff==0.6.5, mypy==1.11.2

pyproject.toml:
[build-system] hatchling
[project] name="rcm-rag", version="0.1.0", requires-python=">=3.12"
[project.dependencies] — list all pinned versions above
[project.optional-dependencies]
  dev = [pytest, pytest-asyncio, pytest-cov, testcontainers, pact-python,
         ruff, mypy, httpx]
[project.scripts] rcm-rag = "rcm_rag.main:start"
[tool.pytest.ini_options]
  asyncio_mode = "auto"
  testpaths = ["tests"]
  python_files = ["test_*.py"]
[tool.coverage.run] source = ["rcm_rag"]

ruff.toml:
line-length = 100
target-version = "py312"
[lint] select = ["E", "F", "I", "N", "W", "UP", "B", "C4", "SIM"]
[lint.isort] known-first-party = ["rcm_rag"]

mypy.ini:
[mypy] python_version = 3.12, strict = True, ignore_missing_imports = True
# Comment: "strict = True enables all mypy checks including --disallow-untyped-defs,
# --no-implicit-optional, --warn-return-any. This catches a category of bugs
# that unit tests often miss — type errors in untested code paths."

config.py:
# All configuration via environment variables.
# pydantic-settings automatically reads from environment and .env file.
# No secrets hardcoded — all sensitive values have no default or
# a clearly-wrong default that will fail fast if not overridden.

from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    # Application
    app_name: str = "rcm-rag"
    app_version: str = "0.1.0"
    environment: str = "dev"
    log_level: str = "INFO"

    # PostgreSQL (pgvector)
    postgres_url: str  # no default — must be set
    # Comment: "No default for postgres_url — if this is missing, the app
    # fails immediately at startup rather than running in a broken state.
    # This is the 'fail fast' principle: a missing config should be obvious,
    # not discovered when the first request hits the DB."

    # Redis
    redis_url: str
    redis_password: str = ""

    # MongoDB
    mongo_url: str
    mongo_db_name: str = "rcm_audit"

    # CosmosDB
    cosmos_endpoint: str
    cosmos_key: str
    cosmos_database: str = "rcm-events"
    cosmos_container: str = "claim-events"

    # Kafka
    kafka_bootstrap_servers: str
    kafka_group_id: str = "rcm-rag"

    # LLM Provider (config-driven swap between Azure OpenAI and Ollama)
    llm_provider: str = "ollama"  # "azure_openai" in prod
    azure_openai_endpoint: str = ""
    azure_openai_key: str = ""
    azure_openai_deployment: str = "gpt-4o"
    azure_openai_mini_deployment: str = "gpt-4o-mini"
    ollama_base_url: str = "http://ollama:11434"
    ollama_model: str = "llama3:8b"

    # Embedding Provider
    embedding_provider: str = "local"  # "azure_openai" in prod
    embedding_model_local: str = "BAAI/bge-small-en-v1.5"
    embedding_dimensions_local: int = 384
    azure_openai_embedding_deployment: str = "text-embedding-3-small"
    embedding_dimensions_azure: int = 1536

    # gRPC
    grpc_port: int = 50051

    # HTTP
    http_port: int = 8091

    # Security
    keycloak_jwks_uri: str
    internal_signing_key: str

    # Feature flags
    feature_flag_cache_ttl_seconds: int = 60

    # Token budgets
    default_tenant_daily_token_budget: int = 100_000

    # Observability
    otlp_endpoint: str = "http://tempo:4317"

    # Computed properties
    @property
    def embedding_dimensions(self) -> int:
        # Comment: "Dimensions differ by provider — this property abstracts
        # the selection so callers don't need to know which provider is active.
        # Critical: NEVER mix embeddings from different providers in the same
        # pgvector index — dimensionality mismatch causes silent retrieval failures."
        if self.embedding_provider == "azure_openai":
            return self.embedding_dimensions_azure
        return self.embedding_dimensions_local

# Singleton settings instance
settings = Settings()

main.py:
import asyncio
import grpc
import uvicorn
from contextlib import asynccontextmanager
from fastapi import FastAPI
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

# Lifespan context manager — runs startup/shutdown logic
# Comment: "@app.on_event is deprecated in FastAPI 0.95+. The lifespan
# context manager is the modern pattern — it uses Python's async context
# manager protocol, which is more composable and testable."
@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── STARTUP ──────────────────────────────────────────────────
    # 1. Initialize database connection pools
    # Comment: "Connection pools are initialized once at startup and shared
    # across all requests. Creating a new connection per request would be
    # prohibitively slow — especially for pgvector queries which need the
    # connection to be authenticated and the search_path to be set."
    from rcm_rag.db.postgres import init_postgres
    from rcm_rag.db.redis_client import init_redis
    from rcm_rag.db.mongo_client import init_mongo
    from rcm_rag.db.cosmosdb_client import init_cosmos
    await init_postgres()
    await init_redis()
    await init_mongo()
    await init_cosmos()

    # 2. Load FAISS hot cache from pgvector
    # Comment: "FAISS index is rebuilt from pgvector embeddings at startup.
    # This takes 5-30 seconds depending on corpus size. The service won't
    # accept gRPC traffic (claim scrubbing) until this is complete.
    # Health check returns 'starting' during this period."
    from rcm_rag.ingestion.faiss_cache import FaissCache
    app.state.faiss_cache = await FaissCache.build_from_pgvector()

    # 3. Load prompt registry
    from rcm_rag.prompts.registry import PromptRegistry
    app.state.prompt_registry = PromptRegistry.load_all()

    # 4. Start gRPC server concurrently
    # Comment: "gRPC server runs in the same asyncio event loop as FastAPI.
    # asyncio.create_task schedules it concurrently without blocking.
    # Both servers share the same process memory — this is intentional:
    # they share the FAISS index, DB connection pools, and prompt registry
    # without the overhead of inter-process communication."
    from rcm_rag.grpc.claim_scrub_servicer import start_grpc_server
    grpc_task = asyncio.create_task(start_grpc_server())
    app.state.grpc_task = grpc_task

    # 5. Start Kafka consumer
    from rcm_rag.kafka.consumer import start_kafka_consumer
    kafka_task = asyncio.create_task(start_kafka_consumer())
    app.state.kafka_task = kafka_task

    yield  # ── Application runs ──────────────────────────────────

    # ── SHUTDOWN ──────────────────────────────────────────────────
    # Comment: "Graceful shutdown: cancel background tasks, close connections.
    # Uvicorn sends SIGTERM on 'docker stop' — FastAPI's lifespan handles it.
    # The 30s default Docker stop timeout gives in-flight requests time to complete."
    grpc_task.cancel()
    kafka_task.cancel()
    await asyncio.gather(grpc_task, kafka_task, return_exceptions=True)

app = FastAPI(
    title="RCM RAG Service",
    version="0.1.0",
    lifespan=lifespan,
    # Disable docs in prod — security best practice
    docs_url="/docs" if settings.environment == "dev" else None,
    redoc_url=None,
)

# OTel instrumentation — must be done before routes are registered
FastAPIInstrumentor.instrument_app(app)

# Register routers
from rcm_rag.api.router import api_router
app.include_router(api_router, prefix="/v1")

# Metrics endpoint (Prometheus scrapes this)
from prometheus_client import make_asgi_app
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

def start():
    # Entry point for 'rcm-rag' CLI command
    uvicorn.run(
        "rcm_rag.main:app",
        host="0.0.0.0",
        port=settings.http_port,
        # Comment: "loop='none' lets uvicorn use the existing asyncio event loop.
        # This is required because we're creating additional asyncio tasks
        # (gRPC server, Kafka consumer) in the lifespan — they all share one loop."
        loop="none",
        log_config=None,  # We use structlog, not uvicorn's logging
        access_log=False,  # structlog handles access logging
    )

Dockerfile (multi-stage):
Stage 1 — builder:
FROM python:3.12-slim AS builder
# Install build dependencies for native packages (grpcio, faiss)
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential gcc g++ && rm -rf /var/lib/apt/lists/*
WORKDIR /app
COPY pyproject.toml .
# Install deps into /app/.venv (not system — cleaner separation)
RUN pip install hatchling && pip install --target=/app/.venv .

Stage 2 — runtime:
FROM python:3.12-slim AS runtime
# Comment: "python:3.12-slim rather than alpine because grpcio requires
# glibc. Alpine uses musl libc which is incompatible with grpcio's
# pre-built wheels — building from source adds 10+ minutes to Docker build."
WORKDIR /app
RUN addgroup --system rcm && adduser --system --group rcm
COPY --from=builder /app/.venv /app/.venv
COPY rcm_rag/ ./rcm_rag/
COPY prompts/ ./prompts/  # prompt YAML files
USER rcm
ENV PYTHONPATH=/app/.venv
EXPOSE 8091 50051
HEALTHCHECK --interval=30s --timeout=10s --start-period=90s --retries=3 \
    CMD python -c "import httpx; httpx.get('http://localhost:8091/health').raise_for_status()"
ENTRYPOINT ["python", "-m", "rcm_rag.main"]

OUTPUT: 8 files.
// FILE: rcm-rag/pyproject.toml
// FILE: rcm-rag/ruff.toml
// FILE: rcm-rag/mypy.ini
// FILE: rcm-rag/Dockerfile
// FILE: rcm-rag/.dockerignore
// FILE: rcm-rag/rcm_rag/__init__.py
// FILE: rcm-rag/rcm_rag/main.py
// FILE: rcm-rag/rcm_rag/config.py
Each ends with // ===== END OF FILE =====
Full implementation. Comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-047: rcm-rag common layer — auth, multitenancy, audit, PHI redactor,
#             observability, feature flags, exceptions
# ============================================================
# GOAL: All 7 cross-cutting concern modules in rcm_rag/common/
# DEPENDS ON: PROMPT-046
# OUTPUT: 7 Python files in rcm-rag/rcm_rag/common/
# ACCEPTANCE CRITERIA:
#   1. auth.py validates JWT RS256 tokens from Keycloak using JWKS
#   2. phi_redactor.py uses Presidio with custom RCM recognizers
#      (MRN format, NPI format) plus standard PII
#   3. Redaction is reversible — tokens map back to original values
#   4. audit.py writes to MongoDB asynchronously using Motor
#   5. observability.py sets up structlog with JSON output + OTel integration
# ============================================================

PROMPT-047 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the common cross-cutting concern modules for rcm-rag.

PACKAGE: rcm_rag.common
COMMENTING STANDARD: Every non-trivial line has an inline comment.

auth.py:
# JWT validation dependency for FastAPI routes.
# Validates Bearer tokens issued by Keycloak (RS256, JWKS endpoint).

from fastapi import Depends, HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
import httpx
from cachetools import TTLCache

# JWKS cache: avoid fetching public keys on every request
# Comment: "Keycloak's public keys rotate rarely (typically yearly).
# Caching with 1-hour TTL avoids a network round-trip to Keycloak JWKS
# on every authenticated request. TTL ensures we pick up key rotations
# within an acceptable window."
_jwks_cache: TTLCache = TTLCache(maxsize=1, ttl=3600)

async def get_jwks() -> dict:
    # Fetch and cache Keycloak JWKS
    # Comment: "JWKS (JSON Web Key Set) contains the public keys used to
    # verify JWT signatures. We fetch from Keycloak's well-known endpoint.
    # The keys are RSA public keys — only Keycloak has the private key,
    # so token forgery is cryptographically infeasible."
    ...

async def verify_token(
    credentials: HTTPAuthorizationCredentials = Security(HTTPBearer())
) -> dict:
    # Validate JWT, return decoded claims
    # Raises HTTPException 401 on failure
    # Comment: "We verify: signature (RS256), expiry (exp claim), issuer (iss claim).
    # We do NOT verify audience (aud) for internal services — only the BFF
    # and external callers need audience validation."
    ...

async def get_current_tenant(token_claims: dict = Depends(verify_token)) -> str:
    # Extract tenant_id from JWT claims
    # Raises 400 if tenant_id missing
    # Comment: "tenant_id is a custom claim added by Keycloak.
    # Its absence means the token was issued without tenant context —
    # this should never happen for valid tokens from our Keycloak realm."
    ...

multitenancy.py:
# Tenant context using Python contextvars (thread-safe for async code)
# Comment: "Threading.local() is for sync code. For async code with asyncio,
# we use contextvars.ContextVar which is coroutine-safe — each coroutine
# gets its own context, preventing tenant ID from leaking across coroutines."

from contextvars import ContextVar
from typing import Optional

_tenant_id_var: ContextVar[Optional[str]] = ContextVar('tenant_id', default=None)

def set_tenant(tenant_id: str) -> None: ...
def get_tenant() -> str:
    # Comment: "Raises if tenant not set — fail loudly rather than
    # silently returning queries for the wrong tenant."
    ...
def clear_tenant() -> None: ...

# FastAPI middleware that sets tenant from JWT
class TenantMiddleware:
    # Extracts tenant_id from JWT claims (already validated by auth.py)
    # Sets ContextVar for the duration of the request
    # Clears on response (using starlette middleware pattern)
    ...

audit.py:
# HIPAA audit event writer — async MongoDB writes via Motor

from motor.motor_asyncio import AsyncIOMotorCollection
from rcm_rag.common.multitenancy import get_tenant
import structlog
from opentelemetry import trace

logger = structlog.get_logger()

class AuditService:
    def __init__(self, collection: AsyncIOMotorCollection): ...

    async def write_phi_access(
        self,
        actor_id: str,
        actor_type: str,  # "user", "service", "agent"
        action: str,      # "READ", "WRITE"
        entity_type: str,
        entity_id: str,
        outcome: str = "SUCCESS",
        llm_call_id: str | None = None,
        agent_run_id: str | None = None,
    ) -> None:
        # Build audit document
        # Include trace_id from OpenTelemetry current span
        # Comment: "trace_id links the audit event to the full distributed
        # trace in Tempo. When investigating a HIPAA incident, you can find
        # the audit event and immediately jump to the full trace showing
        # exactly what happened and in what order."

        # Write async — don't block the main flow
        # Comment: "Motor's insert_one is a coroutine — we await it but
        # don't let its failure block the main request. PHI access audit
        # failures are logged at ERROR level and trigger a Prometheus alert,
        # but they don't fail the request. The trade-off: perfect audit
        # compliance vs service availability. Our policy: log the failure
        # and alert — a human reviews the gap."
        ...

# FastAPI dependency for audit logging
async def audit_phi_access(
    entity_type: str,
    action: str = "READ",
):
    # Returns a callable that logs PHI access for a specific entity type
    # Usage: Depends(audit_phi_access("Patient", "READ"))
    ...

phi_redactor.py:
# PHI redaction using Microsoft Presidio with custom RCM recognizers.
# Removes PHI from text before sending to LLM providers.
# Replaces PHI with typed tokens that can be rehydrated after LLM response.

from presidio_analyzer import AnalyzerEngine, RecognizerRegistry
from presidio_anonymizer import AnonymizerEngine
from presidio_anonymizer.entities import OperatorConfig
from typing import NamedTuple

class RedactionResult(NamedTuple):
    redacted_text: str
    token_map: dict[str, str]  # {token: original_value}
    # Comment: "token_map enables rehydration — replacing [PATIENT_NAME_1]
    # with 'John Smith' in the LLM response. Stored in memory only (never logged).
    # The token format [TYPE_INDEX] allows multiple instances of the same type:
    # [PATIENT_NAME_1], [PATIENT_NAME_2] for claims with multiple patients."

class PhiRedactor:
    def __init__(self):
        # Initialize Presidio with custom recognizers for RCM domain

        # Standard recognizers: PERSON, PHONE_NUMBER, EMAIL_ADDRESS,
        #   US_SSN, US_DRIVER_LICENSE, LOCATION, DATE_TIME
        # Comment: "We enable DATE_TIME recognition because dates of birth
        # are PHI. This means some non-PHI dates (service dates, policy dates)
        # may also be redacted. This is intentional — we err on the side of
        # over-redaction. The LLM prompt is designed to work with date tokens."

        # Custom recognizer: MRN (Medical Record Number)
        # Pattern: MRN-\d{5} (our format from seed data)
        # Comment: "MRN format is provider-specific. Our MRN-XXXXX pattern
        # is defined in the registration module. A real system would configure
        # the MRN recognizer with the actual provider's MRN format."

        # Custom recognizer: NPI (National Provider Identifier)
        # Pattern: 10-digit number starting with 1 or 2
        # Comment: "NPI is a provider identifier, not patient PHI per se.
        # However, including it in prompts can link providers to specific claims
        # in ways that could re-identify patients. We redact it as a precaution."

    def redact(self, text: str) -> RedactionResult:
        # 1. Analyze text for PHI entities
        # 2. Sort by position (reverse order to preserve positions during replacement)
        # 3. Replace each entity with a typed token
        # 4. Build token_map for rehydration
        # Comment: "We process entities in reverse position order so that
        # replacing text at position 100 doesn't shift the position of
        # entities at position 50. This is a common text manipulation bug."
        ...

    def rehydrate(self, text: str, token_map: dict[str, str]) -> str:
        # Replace all tokens in text with original values
        # Comment: "Simple string replacement — tokens are unique enough
        # ([PATIENT_NAME_1]) that false positive matches in the LLM response
        # are extremely unlikely. If the LLM generates text that looks like
        # our token format, we'd incorrectly rehydrate it — acceptable risk
        # given the specificity of our token format."
        ...

observability.py:
# Structlog + OpenTelemetry setup for rcm-rag.

import structlog
import logging
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

def configure_observability(settings) -> None:
    # Configure structlog with JSON output
    # Comment: "structlog wraps Python's standard logging and adds:
    # 1. Structured key-value output (JSON in prod, colored in dev)
    # 2. Context variables (tenant_id, request_id) automatically included
    # 3. OTel trace/span IDs automatically included for log-trace correlation"
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,  # include ContextVar values
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.dev.ConsoleRenderer() if settings.environment == "dev"
            else structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, settings.log_level)
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
    )

    # Configure OpenTelemetry
    # Comment: "OTel SDK sends traces to Tempo via OTLP gRPC protocol.
    # BatchSpanProcessor buffers spans and sends in batches for efficiency.
    # Alternative: SimpleSpanProcessor sends immediately (better for debugging,
    # worse for performance)."
    provider = TracerProvider()
    exporter = OTLPSpanExporter(endpoint=settings.otlp_endpoint, insecure=True)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)

feature_flags.py:
# Feature flag client for rcm-rag — reads from Postgres, caches in TTLCache

from cachetools import TTLCache
from sqlalchemy.ext.asyncio import AsyncSession

class FeatureFlagClient:
    def __init__(self, session_factory, settings):
        # TTLCache: same 60-second TTL as Java side
        # Comment: "60s TTL ensures flag changes propagate within 1 minute.
        # Redis pub/sub invalidation (used in rcm-core) not implemented here
        # for simplicity — 60s TTL is sufficient for our use case."
        self._cache: TTLCache = TTLCache(maxsize=100, ttl=60)
        ...

    async def is_enabled(self, flag_name: str, tenant_id: str) -> bool:
        # Check cache, fall back to DB query
        # Query: SELECT enabled FROM rcm.feature_flags
        #        WHERE flag_name = ? AND (tenant_id = ? OR tenant_id IS NULL)
        #        ORDER BY tenant_id NULLS LAST LIMIT 1
        # Comment: "ORDER BY tenant_id NULLS LAST means tenant-specific flag
        # takes precedence over global flag — same logic as rcm-core."
        ...

exceptions.py:
# Custom exception hierarchy for rcm-rag

class RcmRagException(Exception):
    def __init__(self, message: str, error_code: str, status_code: int = 500): ...

class PhiRedactionError(RcmRagException): ...
class LlmProviderError(RcmRagException): ...
class RetrievalError(RcmRagException): ...
class AgentError(RcmRagException): ...
class TenantIsolationError(RcmRagException): ...

# FastAPI exception handler
async def rcm_rag_exception_handler(request, exc: RcmRagException):
    # Returns ErrorResponse matching the OpenAPI spec format
    # Includes trace_id from OTel for correlation
    ...

OUTPUT: 7 files in rcm-rag/rcm_rag/common/
Each: // FILE: rcm-rag/rcm_rag/common/filename.py // ===== END OF FILE =====
Full implementation. All classes complete. Comprehensive inline comments.
==========================================

# ============================================================
# PROMPT-048: rcm-rag database clients — postgres, redis, mongo, cosmosdb
# ============================================================
# GOAL: All 4 async database client modules
# DEPENDS ON: PROMPT-046 PROMPT-047
# OUTPUT: 4 Python files in rcm-rag/rcm_rag/db/
# ACCEPTANCE CRITERIA:
#   1. postgres.py uses SQLAlchemy async engine with connection pooling
#      and tenant filter injection on every query
#   2. redis_client.py uses redis[asyncio] with connection pool
#   3. mongo_client.py uses Motor (async MongoDB) for audit writes
#   4. cosmosdb_client.py uses azure-cosmos async client for event stream
#   5. All clients initialize lazily (not at import time) — called from lifespan
# ============================================================

PROMPT-048 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the database client modules for rcm-rag.
All clients are async and initialized once at startup via the lifespan.

PACKAGE: rcm_rag.db

postgres.py:
# Async SQLAlchemy engine for PostgreSQL + pgvector queries.
# Used by: retrieval layer (vector search), agent state persistence,
#           eval results, feature flags, semantic cache.

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import event, text
from rcm_rag.common.multitenancy import get_tenant

_engine = None
_session_factory = None

async def init_postgres() -> None:
    global _engine, _session_factory
    # Create async engine with connection pool
    # Comment: "pool_size=10 is appropriate for a service with concurrent
    # gRPC and HTTP requests. pool_pre_ping=True tests connections before
    # use — prevents errors from stale connections that were closed by
    # Postgres's idle connection timeout."
    _engine = create_async_engine(
        settings.postgres_url,
        pool_size=10,
        max_overflow=5,
        pool_pre_ping=True,
        echo=settings.environment == "dev",  # SQL logging in dev only
    )

    # Register tenant filter injection on every connection checkout
    # Comment: "The 'checkout' event fires when a connection is taken from
    # the pool. We use it to set the app.tenant_id Postgres session variable,
    # which is read by pgcrypto and our custom RLS policies.
    # This is the Python equivalent of Hibernate @Filter in rcm-core."
    @event.listens_for(_engine.sync_engine, "checkout")
    def set_tenant_on_checkout(dbapi_conn, connection_record, connection_proxy):
        tenant_id = get_tenant()
        if tenant_id:
            cursor = dbapi_conn.cursor()
            # SET LOCAL scopes the variable to the current transaction only
            cursor.execute(f"SET LOCAL app.tenant_id = '{tenant_id}'")
            cursor.close()

    _session_factory = async_sessionmaker(_engine, expire_on_commit=False)

async def get_session() -> AsyncSession:
    # FastAPI dependency: yields an async session
    # Comment: "expire_on_commit=False prevents SQLAlchemy from expiring
    # object attributes after commit, which would cause lazy loading attempts
    # on detached objects. In async code, lazy loading raises an error
    # (no async lazy loading in SQLAlchemy) — expire_on_commit=False avoids this."
    async with _session_factory() as session:
        yield session

# Tenant-filtered query helper
async def tenant_query(session: AsyncSession, model_class, **filters):
    # Always adds tenant_id filter from context
    # Comment: "Defense in depth: even though the Postgres session variable
    # is set, we also add explicit tenant_id WHERE clauses in application code.
    # Two independent mechanisms means a bug in either is caught by the other."
    tenant_id = get_tenant()
    return await session.execute(
        select(model_class).where(
            model_class.tenant_id == tenant_id,
            *[getattr(model_class, k) == v for k, v in filters.items()]
        )
    )

redis_client.py:
# Async Redis client using redis[asyncio] library.
# Used by: LLM response cache, eligibility cache (cross-service read),
#           rate limit counters, semantic cache key index.

import redis.asyncio as aioredis

_redis: aioredis.Redis | None = None

async def init_redis() -> None:
    global _redis
    _redis = aioredis.from_url(
        settings.redis_url,
        password=settings.redis_password or None,
        encoding="utf-8",
        decode_responses=True,
        # Comment: "max_connections=20 shared across all coroutines.
        # Redis is single-threaded — the bottleneck is rarely connections,
        # but having too few can cause connection wait under burst load."
        max_connections=20,
    )
    # Test connection at startup
    await _redis.ping()

async def get_redis() -> aioredis.Redis:
    # FastAPI dependency
    ...

# Typed helper methods for common operations
async def cache_get(key: str) -> str | None: ...
async def cache_set(key: str, value: str, ttl_seconds: int) -> None: ...
async def cache_delete(key: str) -> None: ...
async def increment_counter(key: str, ttl_seconds: int) -> int:
    # INCR + EXPIRE in a pipeline for atomicity
    # Comment: "INCR and EXPIRE are separate commands. Without a pipeline,
    # there's a race condition: INCR succeeds but the process crashes before
    # EXPIRE runs, leaving a counter without TTL that grows forever.
    # Redis pipeline executes both atomically."
    ...

mongo_client.py:
# Async MongoDB client using Motor for HIPAA audit log writes.

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

_client: AsyncIOMotorClient | None = None
_db: AsyncIOMotorDatabase | None = None

async def init_mongo() -> None:
    global _client, _db
    _client = AsyncIOMotorClient(settings.mongo_url)
    _db = _client[settings.mongo_db_name]

    # Ensure indexes exist (idempotent)
    # Comment: "create_index is idempotent — safe to call on every startup.
    # We create indexes here rather than in a migration because MongoDB
    # doesn't have a migration framework like Flyway. The application
    # is responsible for ensuring its own indexes exist."
    audit_collection = _db["audit_events"]
    await audit_collection.create_index([("tenantId", 1), ("timestamp", -1)])
    await audit_collection.create_index([("entityId", 1)])
    await audit_collection.create_index(
        [("timestamp", 1)],
        expireAfterSeconds=220_752_000,  # 7 years in seconds
        # Comment: "TTL index automatically deletes documents after 7 years.
        # This satisfies HIPAA's minimum 7-year audit log retention requirement.
        # MongoDB handles deletion in a background thread — no application code needed."
    )

async def get_audit_collection():
    return _db["audit_events"]

cosmosdb_client.py:
# Azure CosmosDB async client for claim processing event stream.
# Uses the NoSQL API (not MongoDB-compatible API).

from azure.cosmos.aio import CosmosClient
from azure.cosmos import PartitionKey

_client: CosmosClient | None = None
_container = None

async def init_cosmos() -> None:
    global _client, _container
    _client = CosmosClient(settings.cosmos_endpoint, credential=settings.cosmos_key)
    db = _client.get_database_client(settings.cosmos_database)

    # Create container if not exists (idempotent — for dev/emulator)
    # Comment: "In prod, the container is created by Terraform before deployment.
    # We call create_if_not_exists here for the dev emulator and first-time setup.
    # partition_key='/claimId' enables efficient queries by claim ID."
    _container = await db.create_container_if_not_exists(
        id=settings.cosmos_container,
        partition_key=PartitionKey(path="/claimId"),
        default_ttl=63_072_000,  # 2 years
    )

async def write_claim_event(
    claim_id: str,
    event_type: str,
    tenant_id: str,
    payload: dict,
) -> None:
    # Write event document to CosmosDB
    # Comment: "id must be unique per document. We use claim_id + event_type +
    # timestamp to ensure uniqueness. claimId is the partition key —
    # all events for a claim are co-located for efficient claim history queries."
    document = {
        "id": f"{claim_id}_{event_type}_{int(time.time() * 1000)}",
        "claimId": claim_id,
        "tenantId": tenant_id,
        "eventType": event_type,
        "timestamp": datetime.utcnow().isoformat(),
        "payload": payload,
        "metadata": {"serviceVersion": settings.app_version},
    }
    await _container.create_item(body=document)

OUTPUT: 4 files in rcm-rag/rcm_rag/db/
Each: // FILE: path // ===== END OF FILE =====
Full async implementation. Connection pooling complete. Inline comments comprehensive.
==========================================

# ============================================================
# PROMPT-049: rcm-rag ingestion pipeline — LlamaIndex
# ============================================================
# GOAL: Document loader, semantic chunker, embedder, pgvector store, FAISS cache,
#       and the orchestrating IngestionPipeline
# DEPENDS ON: PROMPT-046 PROMPT-047 PROMPT-048
# OUTPUT: 6 Python files in rcm-rag/rcm_rag/ingestion/
# ACCEPTANCE CRITERIA:
#   1. Embedder is provider-abstracted — swaps between Azure OpenAI and
#      sentence-transformers via config, not code changes
#   2. PgVectorStore upserts chunks + embeddings in a single transaction
#      (no orphaned chunks without embeddings)
#   3. FaissCache builds HNSW index from pgvector at startup with progress logging
#   4. SemanticChunker uses LlamaIndex's SemanticSplitterNodeParser
#      (not fixed-size chunks) — explain why in comments
#   5. IngestionPipeline is idempotent — re-ingesting same document
#      updates existing chunks rather than duplicating
# ============================================================

PROMPT-049 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the LlamaIndex ingestion pipeline for rcm-rag.
This pipeline loads payer policy documents and appeal templates into
pgvector for RAG retrieval.

PACKAGE: rcm_rag.ingestion

document_loader.py:
# Loads source documents for the RAG corpus.
# Source types: payer_policy (text files), appeal_template (text files),
#               carc_definition (from Postgres CARC table — already structured)

from llama_index.core import Document
from llama_index.core.readers.base import BaseReader
import structlog

logger = structlog.get_logger()

class PolicyDocumentLoader:
    # Loads payer policy text files and converts to LlamaIndex Documents
    # Adds metadata: source_type, source_name, payer_id, effective_date

    async def load_from_file(self, file_path: str, metadata: dict) -> Document:
        # Comment: "We use LlamaIndex Document (not raw text) because it
        # carries metadata that flows through the pipeline to the final
        # pgvector record. Metadata enables filtered retrieval:
        # 'find chunks from Aetna policies effective before 2024-01-01'
        # without embedding the date into the chunk text."
        ...

    async def load_carc_definitions(self, session) -> list[Document]:
        # Load CARC/RARC codes from Postgres as Documents for the RAG corpus
        # Each code becomes a Document with code + description + category
        # Comment: "Including CARC codes in the RAG corpus enables the agent's
        # lookup_carc node to use semantic search rather than exact lookup.
        # This handles cases where the denial reason is paraphrased, not
        # the exact CARC code — relevant for narrative denial descriptions."
        ...

chunker.py:
# Semantic chunking using LlamaIndex's SemanticSplitterNodeParser.
# Splits documents at semantic boundaries rather than fixed character counts.

from llama_index.core.node_parser import SemanticSplitterNodeParser
from llama_index.core.schema import TextNode

class SemanticChunker:
    def __init__(self, embed_model):
        # Comment: "SemanticSplitterNodeParser splits text at topic boundaries
        # detected by embedding similarity between adjacent sentences.
        # This is better than fixed-size chunking for payer policies because:
        # 1. Policy sections have variable lengths
        # 2. Fixed chunking may split a 'covered indications' paragraph
        #    across chunks, degrading retrieval quality
        # 3. Semantic chunks stay topically coherent — retrieval finds the
        #    complete relevant section, not an arbitrary slice of it.
        # Trade-off: semantic chunking is slower (requires embedding sentences
        # during indexing) and produces variable-size chunks."
        self.splitter = SemanticSplitterNodeParser(
            buffer_size=1,          # sentences of context around split points
            breakpoint_percentile_threshold=95,  # higher = fewer, larger chunks
            embed_model=embed_model,
        )

    def chunk(self, document) -> list[TextNode]:
        # Split document into semantic chunks
        # Annotate each chunk with: chunk_index, token_count, parent_doc_metadata
        ...

embedder.py:
# Provider-abstracted embedding model.
# Prod: Azure OpenAI text-embedding-3-small (1536 dims)
# Dev: BAAI/bge-small-en-v1.5 via sentence-transformers (384 dims)

from abc import ABC, abstractmethod
from sentence_transformers import SentenceTransformer
import numpy as np

class BaseEmbedder(ABC):
    @abstractmethod
    async def embed_texts(self, texts: list[str]) -> list[list[float]]: ...

    @abstractmethod
    def get_dimensions(self) -> int: ...

    @abstractmethod
    def get_model_version(self) -> str: ...

class LocalEmbedder(BaseEmbedder):
    # Uses sentence-transformers BAAI/bge-small-en-v1.5
    # Comment: "bge-small is chosen over bge-large because:
    # 1. 384 dims vs 1024 dims = 3x smaller pgvector index
    # 2. Comparable retrieval quality on domain-specific text
    # 3. Runs on CPU — no GPU needed in dev
    # 4. Fast enough for ingestion (the bottleneck is I/O, not embedding)
    # In prod: Azure OpenAI text-embedding-3-small provides better quality
    # and HIPAA compliance (data stays within Azure under BAA)."

    def __init__(self):
        # Comment: "SentenceTransformer downloads the model on first run
        # and caches in ~/.cache/huggingface. Docker builds use a pre-warmed
        # cache via COPY --from=builder to avoid download at startup."
        self.model = SentenceTransformer("BAAI/bge-small-en-v1.5")

    async def embed_texts(self, texts: list[str]) -> list[list[float]]:
        # Run in executor to avoid blocking asyncio event loop
        # Comment: "SentenceTransformer.encode() is CPU-bound (not async).
        # Running it in asyncio's default executor (ThreadPoolExecutor) allows
        # other coroutines to run while embedding is in progress.
        # For GPU inference: use a process pool executor instead."
        import asyncio
        loop = asyncio.get_event_loop()
        embeddings = await loop.run_in_executor(
            None, lambda: self.model.encode(texts, normalize_embeddings=True)
        )
        return embeddings.tolist()

class AzureOpenAIEmbedder(BaseEmbedder):
    # Uses Azure OpenAI text-embedding-3-small
    # Handles batching (Azure max 2048 texts per request)
    # Comment: "Azure OpenAI embedding API has a token limit per request.
    # We batch texts to stay within limits. The batch size of 100 texts
    # is conservative — actual limit depends on text lengths."
    ...

def create_embedder(settings) -> BaseEmbedder:
    # Factory function — returns appropriate embedder based on config
    # Comment: "Factory pattern allows config-driven provider selection
    # without if/else scattered throughout the codebase. Adding a new
    # embedding provider only requires adding a new class and one case here."
    if settings.embedding_provider == "azure_openai":
        return AzureOpenAIEmbedder(settings)
    return LocalEmbedder()

pgvector_store.py:
# Stores chunks and embeddings in PostgreSQL via pgvector.
# Implements idempotent upsert — re-ingesting same document updates in place.

class PgVectorStore:
    async def upsert_document(
        self,
        document_metadata: dict,
        chunks: list[TextNode],
        embeddings: list[list[float]],
        session: AsyncSession,
    ) -> str:  # returns document_id
        # All operations in a single transaction for consistency
        # Comment: "A transaction ensures we never have chunks without embeddings
        # or embeddings without chunks. If the embedding step fails midway,
        # the entire document ingestion rolls back. This prevents orphaned
        # records that would cause retrieval to fail."
        async with session.begin():
            # 1. Upsert document (ON CONFLICT on source_name + payer_id)
            # Comment: "ON CONFLICT DO UPDATE means re-ingesting the same policy
            # document updates the metadata (effective_date, content) rather than
            # creating a duplicate. The old chunks and embeddings are deleted and
            # recreated — ensuring stale chunks don't persist after a policy update."

            # 2. Delete existing chunks for this document (if re-ingesting)
            # 3. Insert new chunks
            # 4. Insert embeddings linked to chunks
            # 5. Return document_id
            ...

    async def get_embedding_count(self, tenant_id: str) -> int:
        # For FAISS index sizing and monitoring
        ...

faiss_cache.py:
# FAISS in-memory hot cache built from pgvector at startup.
# Provides faster retrieval for high-QPS scrubbing path.

import faiss
import numpy as np

class FaissCache:
    def __init__(self, index: faiss.Index, chunk_id_map: list[str]):
        # Comment: "chunk_id_map maps FAISS internal integer IDs to our UUID chunk IDs.
        # FAISS uses integer IDs internally — we maintain this mapping to fetch
        # the actual chunk content from Postgres after FAISS returns the IDs."
        self.index = index
        self.chunk_id_map = chunk_id_map

    @classmethod
    async def build_from_pgvector(cls) -> "FaissCache":
        # 1. Query all embeddings from Postgres
        #    Comment: "Loading all embeddings into memory is feasible for our
        #    corpus size (<10M vectors at 384 dims = ~15GB max, typically <1GB).
        #    For larger corpora: shard by payer or source_type, load on demand."

        # 2. Build FAISS HNSW index
        #    Comment: "HNSW index parameters:
        #    M=16: connections per node. Higher = better recall, more memory.
        #    efConstruction=64: search depth during build. Higher = better index quality.
        #    These match the pgvector HNSW index parameters for consistency."
        dimension = settings.embedding_dimensions
        index = faiss.IndexHNSWFlat(dimension, 16)  # M=16
        index.hnsw.efConstruction = 64

        # 3. Add vectors in batches (log progress every 10K)
        # 4. Return FaissCache with index + chunk_id_map
        ...

    async def search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        tenant_chunk_ids: list[str] | None = None,  # for tenant filtering
    ) -> list[tuple[str, float]]:  # [(chunk_id, score)]
        # Comment: "FAISS doesn't support WHERE clauses — it searches the entire
        # index. We implement tenant filtering by post-filtering FAISS results
        # to only include chunk IDs belonging to the current tenant.
        # Trade-off: we retrieve top_k * 5 from FAISS and filter down to top_k.
        # This is why pgvector (with WHERE clauses) is still the primary path —
        # FAISS is for the hot path where we've already verified the tenant's
        # chunks are the majority of the index (single-tenant deployments)."
        ...

ingestion_pipeline.py:
# Orchestrates the full ingestion flow:
# load → chunk → embed → store in pgvector

class IngestionPipeline:
    def __init__(self, loader, chunker, embedder, store):
        ...

    async def ingest(
        self,
        source_path: str,
        metadata: dict,
        session: AsyncSession,
    ) -> dict:  # ingestion stats
        # 1. Load document
        # 2. Chunk semantically
        # 3. Embed chunks (batched)
        # 4. Upsert to pgvector (transactional)
        # 5. Return stats: chunks_created, tokens_embedded, time_taken_ms
        ...

OUTPUT: 6 files in rcm-rag/rcm_rag/ingestion/
Each: // FILE: path // ===== END OF FILE =====
Full implementation. LlamaIndex imports correct. Async throughout.
==========================================

# ============================================================
# PROMPT-050: rcm-rag retrieval layer — hybrid retriever, semantic cache, reranker
# ============================================================
# GOAL: HybridRetriever (pgvector + SQL filters), SemanticCache, CrossEncoderReranker
# DEPENDS ON: PROMPT-046 PROMPT-048 PROMPT-049
# OUTPUT: 3 Python files in rcm-rag/rcm_rag/retrieval/
# ACCEPTANCE CRITERIA:
#   1. HybridRetriever executes: embed query → SQL WHERE filters → vector similarity
#      in a single pgvector query (not two separate queries)
#   2. SemanticCache checks pgvector for similar cached queries (0.97 threshold)
#      before hitting the LLM — stores embedding + response
#   3. CrossEncoderReranker is optional (feature-flagged) — re-ranks FAISS results
#      using a cross-encoder model for better precision
#   4. FAISS hot cache tried first, pgvector fallback — log which was used
# ============================================================

PROMPT-050 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the retrieval layer for rcm-rag.
This is the core of the RAG system — how we find relevant policy chunks.

PACKAGE: rcm_rag.retrieval

retriever.py:
# Hybrid retrieval: structured SQL filters + pgvector cosine similarity.
# This is what separates production RAG from toy demos.
# "Find top-5 Aetna policy chunks most relevant to CPT 27447
# effective before 2024-01-01" requires BOTH vector similarity AND SQL filters.

from dataclasses import dataclass
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

@dataclass
class RetrievalQuery:
    query_text: str
    query_embedding: list[float] | None  # computed if not provided
    tenant_id: str
    payer_id: str | None          # None = search across all payers
    effective_date: str | None    # ISO date — filter policies active on this date
    source_type: str | None       # "payer_policy", "appeal_template", etc.
    top_k: int = 5

@dataclass
class RetrievedChunk:
    chunk_id: str
    document_id: str
    content: str
    metadata: dict
    similarity_score: float
    source_type: str
    payer_id: str | None

class HybridRetriever:
    def __init__(self, embedder, faiss_cache, session_factory):
        ...

    async def retrieve(self, query: RetrievalQuery) -> list[RetrievedChunk]:
        # 1. Embed query text if embedding not provided
        query_embedding = query.query_embedding or (
            await self.embedder.embed_texts([query.query_text])
        )[0]

        # 2. Try FAISS hot cache first (for performance)
        # Comment: "FAISS doesn't support SQL filters. We try it first
        # because it's ~10x faster than pgvector for pure vector search.
        # Then we post-filter by payer_id and effective_date.
        # If post-filtering reduces results below top_k, fall back to pgvector."
        if self.faiss_cache:
            faiss_results = await self._retrieve_from_faiss(query, query_embedding)
            if len(faiss_results) >= query.top_k:
                # Fetch chunk content from Postgres (FAISS only has embeddings)
                return await self._hydrate_chunks(faiss_results, query)

        # 3. pgvector hybrid query (primary path)
        return await self._retrieve_from_pgvector(query, query_embedding)

    async def _retrieve_from_pgvector(
        self, query: RetrievalQuery, embedding: list[float]
    ) -> list[RetrievedChunk]:
        # Single SQL query combining WHERE filters + vector similarity
        # Comment: "The key insight: pgvector's <=> operator (cosine distance)
        # can be combined with standard SQL WHERE clauses in a single query.
        # This is a major advantage over dedicated vector databases that require
        # separate filter and search steps. The query planner uses the HNSW index
        # for the vector search while also applying the WHERE conditions."

        # Build dynamic WHERE clause based on query filters
        where_clauses = ["e.tenant_id = :tenant_id"]
        params: dict = {
            "tenant_id": query.tenant_id,
            "embedding": str(embedding),  # pgvector format
            "top_k": query.top_k,
        }

        if query.payer_id:
            where_clauses.append("(d.payer_id = :payer_id OR d.payer_id IS NULL)")
            params["payer_id"] = query.payer_id
            # Comment: "OR d.payer_id IS NULL includes payer-agnostic documents
            # (e.g., CARC definitions that apply to all payers) in results."

        if query.effective_date:
            where_clauses.append(
                "(d.effective_date IS NULL OR d.effective_date <= :effective_date)"
            )
            params["effective_date"] = query.effective_date

        if query.source_type:
            where_clauses.append("d.source_type = :source_type")
            params["source_type"] = query.source_type

        sql = text(f"""
            SELECT
                c.id as chunk_id,
                c.document_id,
                c.content,
                c.metadata,
                d.source_type,
                d.payer_id,
                1 - (e.embedding <=> :embedding::vector) as similarity_score
                -- Comment: "<=> is cosine distance (0=identical, 2=opposite).
                -- We convert to similarity score: 1 - distance
                -- (1=identical, -1=opposite, higher is better)."
            FROM rag.rag_embeddings e
            JOIN rag.rag_chunks c ON c.id = e.chunk_id
            JOIN rag.rag_documents d ON d.id = c.document_id
            WHERE {' AND '.join(where_clauses)}
            ORDER BY e.embedding <=> :embedding::vector
            LIMIT :top_k
        """)

        # Execute and map to RetrievedChunk objects
        ...

semantic_cache.py:
# Semantic LLM response cache using pgvector.
# Before making an LLM call, check if a semantically similar query was cached.
# Cache threshold: 0.97 cosine similarity.

class SemanticCache:
    def __init__(self, embedder, session_factory, redis_client):
        self.SIMILARITY_THRESHOLD = 0.97
        # Comment: "0.97 is deliberately conservative. At 0.95 we'd get more hits
        # but risk returning cached answers for questions that are semantically
        # close but have different correct answers (e.g., same payer, different CPT).
        # The threshold is tunable — adjust based on eval harness cache hit rate
        # vs faithfulness regression."
        ...

    async def get(
        self,
        query_text: str,
        prompt_version_id: str,
        tenant_id: str,
    ) -> str | None:
        # 1. Check Redis exact-match cache first (key = hash of query + prompt version)
        # Comment: "Exact-match before semantic: exact cache is O(1) Redis lookup
        # vs O(log n) pgvector search. Most cache hits are exact (same query text)."
        exact_key = self._hash_query(query_text, prompt_version_id)
        if cached := await self.redis_client.cache_get(exact_key):
            return cached

        # 2. Embed query for semantic search
        # 3. Search pgvector cached_llm_responses with 0.97 threshold
        # 4. If hit: update hit_count and last_hit_at, return cached response
        # 5. Return None on miss
        ...

    async def put(
        self,
        query_text: str,
        query_embedding: list[float],
        prompt_version_id: str,
        chunk_ids: list[str],
        response_text: str,
        tenant_id: str,
    ) -> None:
        # Store in both Redis (exact) and pgvector (semantic)
        ...

    def _hash_query(self, query_text: str, prompt_version_id: str) -> str:
        # SHA-256 of query_text + prompt_version_id
        # Comment: "Including prompt_version_id in the hash ensures that
        # changing the prompt invalidates all cached responses — a new prompt
        # version may produce different answers for identical queries."
        ...

reranker.py:
# Cross-encoder reranker for improving precision after initial retrieval.
# Optional — gated by feature flag 'rag.reranking'.

from sentence_transformers import CrossEncoder

class CrossEncoderReranker:
    def __init__(self):
        # Comment: "cross-encoder/ms-marco-MiniLM-L-6-v2 is a small but
        # effective cross-encoder. Unlike bi-encoders (which encode query and
        # document separately), cross-encoders process the pair together —
        # slower but more accurate. We use it for re-ranking (not initial retrieval)
        # because: 1) we only re-rank top-k=10 results (fast), 2) higher precision
        # means fewer irrelevant chunks in the LLM context (better faithfulness)."
        self.model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

    async def rerank(
        self, query: str, chunks: list[RetrievedChunk], top_k: int = 5
    ) -> list[RetrievedChunk]:
        # Score each (query, chunk) pair with cross-encoder
        # Return top_k by cross-encoder score
        # Comment: "We return fewer chunks (top_k=5) after reranking than
        # the initial retrieval (top_k=10). The reranker improves precision —
        # we keep only the most relevant chunks to stay within LLM context limits
        # and reduce noise that could distract the LLM."
        ...

OUTPUT: 3 files in rcm-rag/rcm_rag/retrieval/
Each: // FILE: path // ===== END OF FILE =====
Full implementation. SQL queries complete and correct. Async throughout.
==========================================

# ============================================================
# PROMPT-051: rcm-rag prompt registry — YAML loader + all 4 prompt files
# ============================================================
# GOAL: PromptRegistry class + 4 production-quality prompt YAML files
# DEPENDS ON: PROMPT-046
# OUTPUT: rcm-rag/rcm_rag/prompts/registry.py
#         rcm-rag/rcm_rag/prompts/claim-scrubbing-v1.0.0.yaml
#         rcm-rag/rcm_rag/prompts/denial-explanation-v1.0.0.yaml
#         rcm-rag/rcm_rag/prompts/appeal-drafting-v1.0.0.yaml
#         rcm-rag/rcm_rag/prompts/medical-necessity-v1.0.0.yaml
# ACCEPTANCE CRITERIA:
#   1. PromptRegistry loads all YAMLs at startup, validates schema
#   2. Resolution by id + version (semver) — latest if version omitted
#   3. Prompt templates use {placeholder} format compatible with
#      Python str.format() — no Jinja2 (keeps deps minimal)
#   4. Each YAML prompt is realistic and healthcare-appropriate —
#      not toy examples — designed to actually work for RCM
#   5. eval_scores section in each YAML (populated by eval harness)
# ============================================================

PROMPT-051 CONTEXT — paste this into DeepSeek:
==========================================
You are generating the prompt registry for rcm-rag.
The registry manages prompt versions, templates, and evaluation scores.

PACKAGE: rcm_rag.prompts

registry.py:
from dataclasses import dataclass
from pathlib import Path
import yaml
from pydantic import BaseModel
import semver
import structlog

logger = structlog.get_logger()

class EvalScores(BaseModel):
    # All optional — populated by eval harness after each run
    faithfulness: float | None = None
    answer_relevance: float | None = None
    context_relevance: float | None = None
    recall_at_5: float | None = None
    carc_accuracy: float | None = None
    bleu4: float | None = None
    rouge_l: float | None = None
    cosine_similarity: float | None = None
    usefulness_p50: float | None = None

class PromptDefinition(BaseModel):
    id: str
    version: str  # semver: "1.0.0"
    model: str    # "gpt-4o" or "gpt-4o-mini"
    system_prompt: str
    user_prompt_template: str  # uses {placeholder} format
    output_schema: str        # Python class name in rcm_rag.schemas
    metadata: dict
    eval_scores: EvalScores = EvalScores()

class PromptRegistry:
    def __init__(self, prompts: dict[str, list[PromptDefinition]]):
        # Key: prompt_id, Value: list of versions sorted by semver descending
        self._prompts = prompts

    @classmethod
    def load_all(cls) -> "PromptRegistry":
        # Load all YAML files from the prompts directory
        # Comment: "Loading at startup (not on demand) ensures:
        # 1. Fast response to first request (no YAML parse latency)
        # 2. Startup failure if any YAML is malformed (fail fast)
        # 3. Immutable prompt state during request serving"
        prompts_dir = Path(__file__).parent
        all_prompts: dict[str, list[PromptDefinition]] = {}

        for yaml_file in sorted(prompts_dir.glob("*.yaml")):
            with open(yaml_file) as f:
                data = yaml.safe_load(f)
            prompt = PromptDefinition(**data)
            if prompt.id not in all_prompts:
                all_prompts[prompt.id] = []
            all_prompts[prompt.id].append(prompt)

        # Sort each prompt's versions by semver descending
        for prompt_id in all_prompts:
            all_prompts[prompt_id].sort(
                key=lambda p: semver.Version.parse(p.version),
                reverse=True,
            )
            # Comment: "Sorting descending means index 0 is always the latest version.
            # get() with no version specified returns index 0 — latest."

        logger.info("prompt_registry_loaded", total_prompts=len(all_prompts))
        return cls(all_prompts)

    def get(self, prompt_id: str, version: str | None = None) -> PromptDefinition:
        if prompt_id not in self._prompts:
            raise KeyError(f"Prompt '{prompt_id}' not found in registry")

        versions = self._prompts[prompt_id]
        if version is None:
            return versions[0]  # latest

        for prompt in versions:
            if prompt.version == version:
                return prompt
        raise KeyError(f"Prompt '{prompt_id}' version '{version}' not found")

    def format_user_prompt(self, prompt: PromptDefinition, **kwargs) -> str:
        # Comment: "str.format_map is safer than str.format(**kwargs) because
        # it doesn't raise KeyError for missing keys — it uses a default dict
        # that returns the original placeholder for unknown keys.
        # This prevents prompt template errors from crashing the application
        # when optional placeholders are not provided."
        class DefaultDict(dict):
            def __missing__(self, key): return f"{{{key}}}"

        return prompt.user_prompt_template.format_map(DefaultDict(**kwargs))

    def list_all(self) -> list[dict]:
        # For the /v1/eval/results endpoint — lists all prompts with their scores
        ...

PROMPT YAML FILES:

claim-scrubbing-v1.0.0.yaml:
id: claim-scrubbing
version: "1.0.0"
model: gpt-4o-mini
# Comment: "gpt-4o-mini for scrubbing — lower cost, acceptable quality.
# Scrubbing is a classification task (PASS/WARN/FAIL) not generation.
# gpt-4o-mini is faster and 10x cheaper than gpt-4o for classification."
system_prompt: |
  You are an expert medical billing specialist reviewing claims for compliance
  with payer policies. Your role is to evaluate whether a claim meets the
  payer's coverage requirements based on the provided policy documentation.

  EVALUATION CRITERIA:
  - Evaluate ONLY against the provided policy excerpts — do not use general knowledge
  - Identify specific policy sections that are violated or at risk
  - Distinguish between BLOCKING issues (claim will be denied) and WARNINGS (claim may be denied)
  - Be specific: cite the policy text and the claim element that conflicts

  RESPONSE FORMAT:
  Respond only with valid JSON matching the ScrubResult schema.
  Do not include explanation outside the JSON structure.

user_prompt_template: |
  CLAIM INFORMATION:
  - Claim Type: {claim_type}
  - CPT Codes: {cpt_codes}
  - ICD-10 Diagnosis Codes: {icd10_codes}
  - Modifiers: {modifiers}
  - Place of Service: {place_of_service}
  - Service Date: {service_date}
  - Total Charge: ${total_charge_dollars}

  PAYER POLICY EXCERPTS (retrieved from payer policy database):
  {retrieved_policies}

  TASK:
  Review this claim against the payer policy excerpts above.
  Return a JSON object with:
  - "passed": boolean (true if no blocking issues)
  - "issues": array of objects, each with:
    - "issue_code": string (e.g., "PRIOR_AUTH_REQUIRED", "MEDICAL_NECESSITY_NOT_MET")
    - "severity": "BLOCKING" or "WARNING"
    - "description": string (clear explanation for the biller)
    - "policy_reference": string (quote the relevant policy text)
    - "suggested_fix": string (actionable recommendation)

  If no policy excerpts were provided or no issues found, return {"passed": true, "issues": []}

output_schema: ScrubResult
metadata:
  purpose: Evaluate claim compliance with payer policies
  author: rcm-team
  created: "2025-01-15"
  phi_in_prompt: false
  # Comment: "phi_in_prompt: false — this prompt contains NO patient PHI.
  # We include only procedure codes, diagnosis codes, and charges.
  # Patient name, DOB, and other PHI are excluded. This is intentional:
  # the policy evaluation doesn't require patient identity."
eval_scores:
  faithfulness: null
  carc_accuracy: null

denial-explanation-v1.0.0.yaml:
id: denial-explanation
version: "1.0.0"
model: gpt-4o
# Comment: "gpt-4o for denial explanation — this is a complex reasoning task.
# The agent must understand the CARC code, the payer policy, and provide
# a clear explanation to a non-clinical biller. Quality matters here."
system_prompt: |
  You are an expert in medical billing and healthcare revenue cycle management.
  You help medical billers understand why claims were denied and how to appeal them.

  Your explanations should be:
  - Clear and actionable (the biller is not a clinician)
  - Grounded in the provided payer policy documentation
  - Specific about what went wrong and what can be done
  - Professional in tone

  IMPORTANT: The patient information has been de-identified in this prompt.
  Respond using the same de-identified tokens — do not attempt to include
  real patient names or identifiers in your response.

user_prompt_template: |
  DENIAL INFORMATION:
  - CARC Code: {carc_code}
  - CARC Description: {carc_description}
  - RARC Code: {rarc_code}
  - RARC Description: {rarc_description}
  - Service Date: {service_date}
  - CPT Code: {cpt_code}
  - Payer: {payer_name}

  RELEVANT PAYER POLICY EXCERPTS:
  {retrieved_policies}

  TASK:
  Provide a clear explanation of:
  1. Why this claim was denied (in plain English)
  2. Whether this denial is likely correct based on the policy, or potentially incorrect
  3. What documentation or information would support an appeal
  4. The likelihood of a successful appeal (High/Medium/Low) with reasoning

output_schema: DenialExplanation
metadata:
  purpose: Explain denial reason to medical biller and assess appeal viability
  author: rcm-team
  created: "2025-01-15"
  phi_in_prompt: false
eval_scores:
  faithfulness: null
  carc_accuracy: null

appeal-drafting-v1.0.0.yaml:
id: appeal-drafting
version: "1.0.0"
model: gpt-4o
system_prompt: |
  You are an expert medical billing specialist drafting appeal letters for denied claims.
  Your letters are professional, evidence-based, and clearly argue for claim reconsideration.

  LETTER STANDARDS:
  - Professional, formal tone
  - Reference specific policy language from the provided excerpts
  - Cite supporting documentation that strengthens the appeal
  - Be concise but thorough — typically 3-5 paragraphs
  - Never make claims that aren't supported by the provided documentation
  - Use the de-identified patient tokens exactly as provided — do not modify them

user_prompt_template: |
  CLAIM AND DENIAL DETAILS:
  - Claim Number: {claim_id}
  - Patient: {patient_name_token}
  - Date of Service: {service_date}
  - CPT Code: {cpt_code}
  - Diagnosis: {icd10_code}
  - Denial Reason (CARC {carc_code}): {carc_description}
  - Payer: {payer_name}

  DENIAL ANALYSIS:
  {denial_explanation}

  PAYER POLICY EXCERPTS:
  {retrieved_policies}

  MEDICAL NECESSITY DOCUMENTATION:
  {medical_necessity_docs}

  TASK:
  Draft a professional appeal letter. Structure:
  1. Opening: State you are appealing denial of claim for the above service
  2. Clinical Justification: Why the service was medically necessary
     (based on provided documentation)
  3. Policy Compliance: How the service meets the payer's own policy criteria
     (cite specific policy excerpts)
  4. Supporting Documentation: List what is being submitted with the appeal
  5. Request: Request expedited review and reconsideration

  Use {patient_name_token} wherever the patient name would appear.
  The letter will be reviewed by a human biller before submission.

output_schema: AppealDraft
metadata:
  purpose: Draft appeal letter for denied claim for human biller review
  author: rcm-team
  created: "2025-01-15"
  phi_in_prompt: true
  phi_note: "Patient name is a de-identified token — rehydrated before display"
eval_scores:
  faithfulness: null
  carc_accuracy: null

medical-necessity-v1.0.0.yaml:
id: medical-necessity
version: "1.0.0"
model: gpt-4o-mini
system_prompt: |
  You are a medical billing expert evaluating whether clinical documentation
  supports the medical necessity of a procedure. You assess whether the
  provided documentation meets payer requirements for medical necessity coverage.

user_prompt_template: |
  PROCEDURE: CPT {cpt_code} — {cpt_description}
  DIAGNOSIS: ICD-10 {icd10_code}

  PAYER MEDICAL NECESSITY CRITERIA:
  {retrieved_medical_necessity_docs}

  TASK:
  Assess whether the above criteria are likely met for this service.
  Return JSON with:
  - "likely_meets_criteria": boolean
  - "met_criteria": list of strings (criteria that appear to be met)
  - "unmet_criteria": list of strings (criteria that may not be met)
  - "documentation_gaps": list of strings (what additional documentation would help)
  - "confidence": "HIGH" | "MEDIUM" | "LOW"

output_schema: MedicalNecessityAssessment
metadata:
  purpose: Assess medical necessity for claim or appeal support
  author: rcm-team
  created: "2025-01-15"
  phi_in_prompt: false
eval_scores:
  faithfulness: null
  carc_accuracy: null

OUTPUT: 5 files.
// FILE: rcm-rag/rcm_rag/prompts/registry.py
// FILE: rcm-rag/rcm_rag/prompts/claim-scrubbing-v1.0.0.yaml
// FILE: rcm-rag/rcm_rag/prompts/denial-explanation-v1.0.0.yaml
// FILE: rcm-rag/rcm_rag/prompts/appeal-drafting-v1.0.0.yaml
// FILE: rcm-rag/rcm_rag/prompts/medical-necessity-v1.0.0.yaml
Each ends with // ===== END OF FILE =====
Full implementation. Prompts are production-quality — not toy examples.
==========================================
